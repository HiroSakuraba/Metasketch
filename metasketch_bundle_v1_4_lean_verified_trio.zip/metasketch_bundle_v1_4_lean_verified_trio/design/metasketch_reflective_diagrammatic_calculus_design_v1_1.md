# Metasketch: A Reflective Diagrammatic Calculus
## Design document v1.1: Lean-verified F1 and closed fixture loop

**Status:** Finite-core release with machine-checked F1. The general metatheory beyond F1 remains open.

**Supersedes:** v1.0 for current implementation status. Earlier notes remain in
`design/` as the project lineage.

**Author:** Benjamin John Schulz
**Date:** July 1, 2026

## Executive summary

Metasketch is a finite prototype for a stratified diagrammatic calculus in which
structural diagrams, existential-conjunctive predicates, witness certificates,
and selected coherence cells are checked together and rendered as auditable SVG.

v1.1 does not broaden the logical fragment. It upgrades v1.0 in three ways:

1. **F1 is now a machine-checked theorem.** The v1.0 formalization handoff for
   directed monoid normalization is discharged: `formal/lean/MonoidNormalization.lean`
   proves `step_decreases`, `normal_rightComb`, `normalization_sound`,
   `normal_unique`, `exists_normal`, and `confluence` in Lean 4 (v4.31.0,
   core only, no mathlib, no `sorry`), over an arbitrary atom type. The axiom
   footprint is the three standard Lean foundations; see
   `formal/lean/VERIFICATION.txt`.
2. **The fixture loop is closed.** The shipped
   `formal/fixtures/finite_core_v1.json` is now re-parsed and independently
   replayed by the regression suite (`term_from_json`,
   `monoid_certificate_from_json`, `replay_fixture_bundle`), so the
   translation oracle cannot drift from the checker. The Lean file also
   contains `rfl` cross-checks against the fixture's pentagon and unit-tail
   instances.
3. **Kernel hygiene.** A latent annotation bug in `proofs.py` (undefined
   `Mapping` name, masked by deferred annotations) is fixed, dead locals and
   unused imports in the core modules are removed, and the test-runner
   docstring is brought current.

The full Python regression suite contains **144 checks**. The Lean development
proves the F1 statements at full generality; the Python suite remains the
executable evidence for everything else.

| Layer | Checks | Status |
|---|---:|---|
| Public API | 6 | checked construction and trusted-boundary exposure |
| Phase 1 | 35 | finite syntax, semantics, tiles, and reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting and confluence fillers |
| Phase 2.5 | 9 | monoid structure/logic coherence |
| Phase 3 | 14 | graph-pattern query transport |
| Phase 4 | 11 | relational witness proofs and normal forms |
| Phase 5 | 5 | stored-match certificate/match adequacy |
| Phase 6 | 13 | raw reconstruction from facts and hidden binders |
| Phase 7 | 11 | pointed boundary assignments |
| Phase 10 | 11 | finite certificates, fixture replay, boundary rendering |
| Coherence lift | 4 | reusable finite lifting schema |
| Program E audit | 5 | stratified quotation and absent bridge premises |
| Renderer | 10 | audited semantic SVG scenes |

## 1. Trusted boundary

Unchanged from v1.0. Use `metasketch0.api` for supported construction:

```text
checked_context, checked_term, checked_predicate
checked_diagram, checked_tile, checked_model, model_from_parts
BoundaryAssignmentProof, checked_raw_certificate
certify_monoid_normalization
certify_pointed_reconstruction
audit_finite_monoid_corpus
```

`metasketch0.unsafe_ast` remains explicitly experimental. Python cannot make
this capability-secure, so proof checking, rendering, quotation, and certificate
replay revalidate their inputs.

## 2. Proof-carrying finite core

### 2.1 Directed monoid certificates and the F1 theorem

The directed rules

\[
(xy)z\to x(yz),\qquad ex\to x,\qquad xe\to x
\]

admit right-associated unit-free word normal forms. In v1.0 this had a
conventional proof note and an instance-level Python checker. In v1.1 the
general statement is machine-checked. The Lean development proves, for ground
terms over any atom type:

\[
s\Rightarrow^* n\ \wedge\ \operatorname{Normal}(n)\ \Longrightarrow\
n=\operatorname{rightComb}(\operatorname{flatten}(s)),
\]

together with strict descent of the polynomial interpretation, normality of
every right comb, progress, existence of normal forms, uniqueness, and
confluence. The proof route follows the v1.0 plan: `flatten` is a step
invariant and normal terms are exactly the right combs of their own leaf
words, so no critical-pair or Newman's-lemma library is needed.

The runnable Python certificate checker is unchanged in role: it verifies one
concrete trace at a time,

\[
\operatorname{cert}(s)=
(s,\;s\Rightarrow^*n,\;\operatorname{flatten}(s),\;n,\;I\text{-descent}),
\]

with the target checked independently against
\(n=\operatorname{rightComb}(\operatorname{flatten}(s))\). The bounded
exhaustive corpus of all 147 depth-two terms over \(e,a,b\) still replays.

### 2.2 Pointed reconstruction certificates

Unchanged in scope. A raw certificate has no stored semantic match. It combines
fact leaves, an outer hidden-witness binder spine, and typed boundary
assignments for visible variables absent from relation atoms. The replay
checker recomputes both the reconstructed mapping and the full finite set of
semantic matches realizing all evidence. For every accepted instance \(\rho\):

\[
\exists!m\in\operatorname{Match}_M(P)\;m\models\rho.
\]

This remains an instance-level finite result. F2, the same statement quantified
over every finite relation-only model and accepted raw certificate, is the next
formalization target and is not yet machine-checked.

### 2.3 Closed fixture loop

v1.0 shipped `formal/fixtures/finite_core_v1.json` as a write-only translation
oracle. v1.1 adds the reverse direction: `metasketch0.formal_fixtures` now
parses fixture JSON back into kernel terms and rebuilds
`MonoidNormalizationCertificate` objects, and the Phase 10 suite replays the
shipped file and rejects a tampered normal form. Pointed-reconstruction fixture
entries serialize mappings and evidence but not the finite model, so they are
checked structurally rather than replayed; this asymmetry is recorded in the
replay function's contract.

## 3. Visual status

Unchanged from v1.0. The renderer remains a one-way projection from checked
proof objects with five showcases:

```text
directed_pentagon.svg
relational_witness.svg
transport_coherence.svg
quoted_proof_membrane.svg
pointed_boundary.svg
```

`pointed_boundary.svg` renders external boundary evidence as a typed input
outside every witness scope. Ordinary wires cannot cross quotation membranes;
all SVGs embed a canonical semantic manifest and SHA-256 audit hash, and the
regeneration script reproduces every artifact byte for byte.

## 4. Program E status

Unchanged from v1.0. Program E is a constraint and audit program, not a
completed no-go theorem. The implementation has no total universal evaluator,
no representation-complete same-level predicate class, and no semantic truth
operator. The active escape routes are:

\[
\boxed{\text{stratification} + \text{representation incompleteness}.}
\]

Bounded evaluation statuses remain implementation diagnostics; they are not
semantic divergence claims. The F1 verification does not change any Program E
claim.

## 5. Formalization status

The v1.0 release could not install a prover. The v1.1 build environment could,
and F1 is now discharged:

```text
formal/lean/MonoidNormalization.lean   the proof (Lean 4 core, no mathlib)
formal/lean/lean-toolchain             pinned toolchain (v4.31.0)
formal/lean/verify.sh                  one-command recheck with axiom report
formal/lean/VERIFICATION.txt           theorem list and axiom footprint
```

The remaining formalization order is:

1. F2: unique pointed raw-certificate reconstruction; then
2. typed reflection-interface safety, before any Lawvere-style bridge attempt.

`formal/fixtures/finite_core_v1.json` remains the language-neutral translation
oracle for a future F2 port, now replay-checked from Python on every suite run.

## 6. What remains open

- Formal verification of F2 and reflection-interface type safety.
- Equality in relational patterns.
- A general coherence-lifting theorem for arbitrary polygraphs.
- Relative completeness beyond the finite relation-only conjunctive fragment.
- A semantic account of partial evaluation.
- A non-tautological universal-evaluator bridge to weak point-surjectivity.
- A two-way visual editor.

## 7. Next decision

With F1 verified, the gate stated in v1.0 section 7 is half met. The options
are: (a) formalize F2 next, completing the declared finite-core theorem pair
before any fragment growth; or (b) begin **equality in relational patterns**
now, accepting that F2 verification will then target the enlarged fragment.
Recommendation: (a). F2's finite quantifier structure is exactly what the
fixture oracle was built to translate, and verifying it against the current
fragment gives equality a stable, machine-checked baseline to extend.
