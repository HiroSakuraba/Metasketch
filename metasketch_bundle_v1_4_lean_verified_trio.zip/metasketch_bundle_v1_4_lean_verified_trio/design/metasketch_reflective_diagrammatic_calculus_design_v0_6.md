# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.6: Witness-normalized relational tiles

**Status:** Design document plus finite executable prototype. Metasketch is not
a completed foundation, proof assistant, or theorem about all mathematics. The
implemented kernel now has five finite phases and a narrow proof-normalization
layer.

**Supersedes:** v0.5. Earlier design documents remain archived with the bundle.
This version adds Phase 4 and updates the next decision point.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

---

## 0. What v0.6 adds

Metasketch began with a structural diagram language, regular-logic predicates,
preservation tiles, higher rewriting coherence, and stratified reflection
safeguards. v0.5 showed that graph homomorphisms transport finite
existential-conjunctive pattern witnesses.

v0.6 adds a proof layer over that result.

1. Graph patterns generalize to arbitrary **finite many-sorted relational
   signatures** with no operation symbols in this phase.
2. A finite pattern compiles into a typed existential-conjunctive query.
3. Concrete witnesses now carry explicit proof terms for atom facts,
   conjunction introduction, and existential witness introduction.
4. Proof certificates normalize to a canonical witness form that ignores
   alpha-renamed display binders and conjunction order/bracketing.
5. A relational homomorphism transports a witness proof. Two successive
   transports compose, and a stored 3-cell verifies that direct and sequential
   transport normalize to the same net trace.

The full suite now has **79 checks**:

| Phase | Checks | What it establishes computationally |
|---|---:|---|
| 1 | 35 | finite structural and regular-logic kernel; reflection interface safeguards |
| 2 | 10 | directed monoid rewriting, critical-pair fillers, directed pentagon |
| 2.5 | 9 | coherence between monoid rewriting and predicate transport |
| 3 | 14 | graph-pattern query transport and witness-level coherence |
| 4 | 11 | relational witness certificates, normal forms, finite tile evidence |

All 79 checks pass in the delivered bundle.

---

## 1. The project spine

Metasketch aims for one visual and compositional language in which adjacent cell
levels represent:

\[
\begin{array}{rcl}
\text{structure diagrams} &:& \text{operations, relations, and presentations},\\
\text{map diagrams} &:& \text{homomorphisms, substitutions, and interpretations},\\
\text{predicate diagrams} &:& \text{statements in a regular-logic fragment},\\
\text{proof tiles} &:& \text{preservation and entailment certificates},\\
\text{coherence cells} &:& \text{proofs that parallel proof paths agree},\\
\text{quotation membranes} &:& \text{typed code for lower-level diagrams and proofs}.
\end{array}
\]

The intended unity is not an untyped identification of a structure with every
statement about it. It is one typed higher-dimensional calculus in which
structural maps and logical proof objects compose and interact visibly.

Program E remains the boundary condition: quotation and checking are stratified,
partial where necessary, and never supply a same-level total,
representation-complete semantic truth predicate.

---

## 2. Existing kernel

### 2.1 Structural and logical core

A structural diagram

\[
d:\Gamma\to\Delta
\]

is implemented as a target-indexed substitution. A predicate is built from

\[
\top,\qquad =,\qquad R(\bar x),\qquad \land,\qquad \exists.
\]

Reindexing is capture-avoiding substitution:

\[
d^*Q=Q[d].
\]

The preservation tile

\[
P\vdash d^*Q
\]

has two readings:

- every source environment satisfying \(P\) is mapped by \(d\) to one satisfying
  \(Q\);
- \(P\) entails the substitution of \(Q\) along \(d\).

### 2.2 Structural rewriting and coherence

For the monoid presentation, the directed rules

\[
(ab)c\to a(bc),\qquad ex\to x,\qquad xe\to x
\]

have a terminating polynomial interpretation. Critical branchings are enumerated
and stored as confluence fillers. The familiar associator-pentagon shape appears
as a directed rewrite-theoretic 3-cell; it is not claimed to be full Mac Lane
coherence with invertible associators.

### 2.3 Controlled reflection

Quotation raises a level. Checked code, model-relative satisfaction, and bounded
partial evaluation are represented above the object level. Same-level total,
representation-complete Boolean truth is rejected by a membrane policy and a
finite diagonal demonstration. Those checks are finite instances, not general
Tarski or Lawvere theorems.

---

## 3. Phase 4: finite relational patterns

### 3.1 Why expand from graphs

Graphs are one binary-relation signature. A serious regular-logic core must work
with relation symbols of different arities and sorts. Phase 4 therefore uses a
finite relation-only signature

\[
\Sigma=\{R_i:S_{i1}\times\cdots\times S_{in_i}\}.
\]

Operation symbols are deferred. They interact with substitution and rewriting in
a way already exercised by the monoid phases; this phase isolates relational
proof normalization first.

### 3.2 Patterns and queries

A relational pattern \(P\) has typed variables \(V_P\), visible variables
\(\bar x\), hidden variables \(\bar z\), and atoms \(R_i(\bar v_i)\). It compiles
to

\[
Q_P(\bar x)=\exists\bar z.\bigwedge_iR_i(\bar v_i).
\]

A finite match is a sort-preserving assignment \(w:V_P\to M\) satisfying every
atom. The implementation enumerates all finite matches and checks that their
visible assignments equal the extension of the compiled query.

### 3.3 Proof objects

The new proof grammar contains:

```text
TruthProof                 empty conjunction
AtomFactProof              one concrete relation fact
AndIntroProof              conjunction introduction
ExistsWitnessProof         one explicit existential witness
WitnessTransportProof      reindex / transport along a checked homomorphism
TileCompositionProof       composition of pointed transport proofs
WitnessTransportCoherenceCell3
                           direct versus sequential transport
```

A `PatternWitnessProof` is accepted only when every required relation atom and
hidden witness agrees with one finite match.

### 3.4 Normal form

The canonical witness normal form records:

```text
pattern identity
all variable assignments in pattern order
visible assignments
hidden witness assignments
sorted relation facts
```

It ignores display binder names and conjunction bracketing/order. This supports
a modest but useful normalization result for the implemented certificate grammar:

\[
\pi_1\text{ and }\pi_2\text{ normalize identically}
\]

when they certify the same finite match but differ only in alpha-renaming or
conjunction assembly.

### 3.5 Homomorphism transport

A `RelationalHomomorphism` is a total sortwise map that preserves every source
relation tuple. It transports each pattern match. A finite relational tile proof
then enumerates every source witness for one pattern/model pair and stores its
transport certificate.

For a composable pair

\[
M\xrightarrow{h}N\xrightarrow{k}L,
\]

Metasketch stores a 3-cell between direct transport along \(k\circ h\) and
sequential transport along \(h\) then \(k\). Both sides normalize to the same
net sortwise map and final witness.

---

## 4. What has been tested in Phase 4

The regression suite uses persons and cities with relations

\[
\mathsf{Knows},\quad\mathsf{Lives},\quad\mathsf{Road},\quad\mathsf{Open}.
\]

The main pattern asks whether two people are connected by a knowledge edge and a
route between the cities where they live:

\[
\exists a,b.\;
\mathsf{Knows}(s,t)
\land\mathsf{Lives}(s,a)
\land\mathsf{Lives}(t,b)
\land\mathsf{Road}(a,b).
\]

Phase 4 checks:

1. multi-sort pattern compilation against the declared relation signature;
2. equality of compiled-query extensions and exhaustive witness enumeration;
3. witness normalization under reordered conjunction and alpha-renamed binders;
4. rejection of a certificate missing required atomic evidence;
5. finite universal tile evidence covering every source witness;
6. rejection of a sort-correct but relation-nonpreserving map with the exact
   missing image fact;
7. a stored direct-versus-sequential transport 3-cell; and
8. unary relations and the empty conjunction.

These are finite executable checks. They validate the prototype but do not prove
an all-model theorem.

---

## 5. Current theorem status

| Claim | Status | Exact scope |
|---|---|---|
| Diagram composition and reindex functoriality | tested | finite models and sampled syntax |
| Directed monoid termination/confluence ingredients | implemented and tested | a short paper proof exists; not mechanized |
| Monoid transport/rewrite coherence | tested | selected finite monoids and sampled branchings |
| Graph-query witness transport | implemented and tested | finite directed graphs |
| Relational pattern compilation | implemented and tested | finite relation-only signatures |
| Witness-certificate normalization | implemented and directly provable by inspection | Phase 4 certificate grammar only |
| Finite relational-tile evidence | implemented and tested | enumerated finite source matches |
| Relative completeness of relational tiles | open | requires a formal syntax-to-semantics theorem |
| Visual renderer | open | deferred until proof normal forms stabilize |
| Program E universal-evaluator bridge | open | requires actual quoted proof objects later |

---

## 6. Immediate next step

The next move should be **v0.6.1: render actual normalized proof objects**, not
another new mathematical domain.

The renderer should consume checked syntax and proof objects directly, producing:

- wires for visible variables and sorts;
- nested/shaded regions for existential witnesses;
- relation boxes for atom facts;
- tiles for witness transport;
- squares or globes for the stored 3-cells; and
- membrane boundaries for quoted lower-level proof objects.

This is now safe because the renderer has canonical objects to render. A renderer
before Phase 4 would have risked being visual polish around unsettled proof
semantics.

After that, return to the first serious nontrivial theorem attempt:

> a relative-completeness theorem for finite relational-pattern witness
> certificates, with an explicit comparison to canonical-database reasoning and
> graphical conjunctive-query calculi.

Only after actual proof objects and their diagrams exist should the Program E
reflection layer quote and inspect them.

---

## 7. Limits

Metasketch v0.6 does **not** yet provide:

- a complete proof calculus for regular logic;
- implication, negation, universal quantification, disjunction, or general
  equality reasoning in the relational proof layer;
- operation symbols in relational patterns;
- symbolic proof search over arbitrary models;
- a formal homotopy basis for all proof-level rewrites;
- a visual editor or renderer; or
- a general theorem on stratification, Tarski, Lawvere, or Program E.

The project remains a staged attempt to build a useful calculus while making
scope boundaries explicit.

---

## 8. Reference anchors

1. A. K. Chandra and P. M. Merlin, *Optimal Implementation of Conjunctive
   Queries in Relational Data Bases*, STOC 1977, DOI: 10.1145/800105.803397.
2. F. Bonchi, F. Seeber, and P. Sobociński, *Graphical Conjunctive Queries*,
   arXiv:1804.07626.
3. B. Fong and D. I. Spivak, *Graphical Regular Logic*, arXiv:1812.05765.
4. Y. Guiraud and P. Malbos, *Higher-Dimensional Categories with Finite
   Derivation Type*, Theory and Applications of Categories 22 (2009), 420--478.
