# Metasketch Phase 7: Pointed Boundary Reconstruction
## Finite raw certificates for unanchored visible variables

**Status:** Executable finite theorem slice. The implementation and tests are in
`metasketch0/raw_certificates.py` and `metasketch0/tests_phase7.py`.

**Scope:** finite many-sorted relation-only signatures, equality-free
existential-conjunctive patterns, finite models, and explicit witness evidence.
This is not a completeness theorem for arbitrary regular logic.

## 1. Problem

A Phase 6 raw certificate reconstructs a relational match from:

1. concrete relation-fact leaves;
2. an outer existential-witness prefix; and
3. a conjunction tree.

This works when every visible variable occurs in at least one relation atom. If a
visible variable does not occur in the matrix, no atom leaf determines its value.
For example, the pointed query

\[
Q(p) \equiv \top
\]

is satisfied by every person in a nonempty model, but a certificate for one
specific input such as \(p=u\) needs to record that selected input somewhere.

Phase 7 adds that missing evidence without putting it inside the formula matrix.

## 2. Pointed raw certificates

Let \(P\) be a finite relational pattern with visible variables
\(\bar x\), hidden variables \(\bar z\), and atom matrix \(A_P\). Define

\[
U(P)=\{x\in\bar x : x\text{ does not occur in any atom of }A_P\}.
\]

A pointed raw certificate is

\[
\rho=(P,M,\beta,\pi),
\]

where:

- \(M\) is a finite model;
- \(\pi\) is a raw matrix proof with exactly one fact leaf per pattern atom;
- \(\pi\) has one outer existential binder for each hidden variable; and
- \(\beta\) contains exactly one typed boundary assignment
  \(x\mapsto a\) for each \(x\in U(P)\).

The new node is represented by:

```text
BoundaryAssignmentProof(variable, value, display_label)
```

It is **boundary evidence**, not a leaf of the existential-conjunctive matrix.
The intended judgement is therefore pointed:

\[
M,\beta \models \exists\bar z.\,A_P(\bar x,\bar z).
\]

Existential binders still scope over the whole conjunction matrix. Boundary
assignments remain outside that binder spine because they instantiate free visible
inputs, not hidden witnesses.

## 3. Reconstruction theorem

### Theorem, finite pointed reconstruction

Let \(\rho=(P,M,\beta,\pi)\) be an accepted pointed raw certificate. Suppose:

1. every atom leaf names one pattern atom exactly once and records a true fact of
   \(M\);
2. all repeated variable occurrences in those leaves agree;
3. the outer binder prefix names every hidden variable exactly once and records a
   value in the correct carrier;
4. the boundary nodes name exactly the variables in \(U(P)\), each once, with a
   value in the correct carrier; and
5. all evidence for each variable agrees.

Then the reconstruction procedure produces a unique relational match

\[
\operatorname{rec}(\rho):P\to M
\]

that realizes every fact leaf, witness binder, and boundary assignment in
\(\rho\).

### Proof sketch

Every hidden variable receives a value from its unique outer binder. Every visible
variable either occurs in at least one fact leaf or belongs to \(U(P)\) and so
receives a value from its unique boundary node. The agreement checks make the
assignment total and single-valued. Each fact leaf is checked against the finite
model, so the resulting assignment satisfies every atom of \(P\). This is exactly
a `RelationalMatch`. Any other match realizing the same evidence agrees on every
variable and is therefore equal to \(\operatorname{rec}(\rho)\). \(\square\)

## 4. Converse construction

Given a checked Phase 5 witness proof with stored match \(m:P\to M\), raw
certificate erasure now adds the boundary assignments

\[
\beta_m(x)=m(x) \qquad (x\in U(P)).
\]

Thus erasure preserves the reconstruction theorem even for empty matrices and
other unanchored-visible queries:

\[
\operatorname{rec}(\operatorname{erase}(m))=m.
\]

The canonical witness normal form remains unchanged because it records the
reconstructed match, not presentation-only binder labels or conjunction
bracketing.

## 5. Executed checks

The Phase 7 test suite checks:

1. an empty conjunction with a selected visible `Person` value;
2. automatic insertion of a required boundary node while erasing a stored-match
   proof;
3. coexistence of an external boundary assignment with an internal existential
   witness;
4. rejection of missing boundary assignments;
5. rejection of duplicate assignments;
6. rejection of values outside a finite carrier; and
7. rejection of redundant boundary assignments for variables already anchored by
   relation facts.

The full v0.9 regression suite contains 133 checks.

## 6. Limits

This extension does not:

- allow arbitrary optional boundary assignments for all visible variables;
- add equality, implication, negation, or universal quantification;
- establish arbitrary proof reconstruction;
- infer boundary values from semantic truth alone; or
- create a same-level truth predicate.

The boundary node is a typed piece of finite evidence. It enriches the class of
quoted proof objects available to Program E, but does not alter the current
stratification, partiality, or representation-incompleteness safeguards.
