# Metasketch v1.0: Proof-Carrying Finite Core
## Certificate replay, pointed-boundary rendering, and formalization portability

**Status:** Implemented executable finite-core increment. This release does not
claim proof-assistant verification. The execution environment has no installed
proof assistant and could not resolve the official Lean installer host.

## 1. Purpose

v0.9 completed the finite pointed raw-certificate slice. v1.0 strengthens the
trust boundary without expanding the logic:

1. Every demonstrated monoid normalization can be exported as a replayable
   certificate.
2. Every demonstrated pointed raw reconstruction can be exported as a replayable
   unique-witness certificate.
3. Pointed boundary evidence now renders as an external typed input, visibly
   different from an existential witness.
4. Portable JSON fixtures and a theorem-by-theorem formalization plan are shipped
   for a future Lean, Coq, Agda, Isabelle, or Rocq port.

The central distinction is:

\[
\text{replayable finite certificate}
\neq
\text{machine-checked general theorem}.
\]

## 2. Monoid normalization certificate

For a ground term in the presentation

\[
(xy)z\to x(yz),\qquad ex\to x,\qquad xe\to x,
\]

a `MonoidNormalizationCertificate` stores:

\[
(s,\;s\Rightarrow^* n,\;\operatorname{flatten}(s),\;n,\;I(s_i)>I(s_{i+1})).
\]

Its independent checker verifies:

1. each named rewrite rule and redex position;
2. trace composability;
3. strict decrease of the declared polynomial interpretation;
4. absence of residual redexes at the claimed target; and
5. equality of the target with the right comb of the source's unit-free word.

The v1.0 test corpus enumerates every ground term built from \(e,a,b\) through
tree depth two: 147 distinct terms. Each generated certificate is replayed.
This is a complete finite audit of that corpus, not a proof by induction over all
terms.

## 3. Pointed raw-reconstruction certificate

A `PointedReconstructionCertificate` contains a raw proof tree with no stored
`RelationalMatch`, its claimed reconstructed mapping, its collected evidence, and
the complete finite list of semantic matches realizing that evidence.

Its checker reruns:

\[
\operatorname{validateRaw}(\rho),
\qquad
\operatorname{reconstruct}(\rho),
\qquad
\{m\in\operatorname{Match}_M(P):m\models\rho\}.
\]

Acceptance requires the last set to be a singleton containing the reconstructed
mapping. A forged mapping is rejected even when the raw syntax itself is
well-formed.

This directly realizes the narrow Phase 6 and 7 claim:

\[
\operatorname{AcceptedRaw}(\rho)
\Longrightarrow
\exists!m\in\operatorname{Match}_M(P)\;m\models\rho.
\]

## 4. Boundary rendering

A `BoundaryAssignmentProof` now becomes a green dashed external node in the SVG
scene graph. It has a typed outgoing port but belongs to no existential witness
region. It therefore visually encodes the intended distinction:

\[
\text{selected visible input}
\neq
\text{hidden existential witness}.
\]

The new `pointed_boundary.svg` showcase is generated from an accepted raw
certificate for the pointed truth query \(Q(p)\equiv\top\), selecting \(p=u\).
Its semantic manifest records both raw-certificate provenance and the uniquely
reconstructed finite match.

## 5. Formalization handoff

`formal/README.md` specifies the first two theorem ports:

- directed monoid normalization and confluence through the right-comb normal
  form; and
- unique pointed raw-certificate reconstruction.

`formal/fixtures/finite_core_v1.json` contains concrete certificate fixtures for
translation tests. A proof-assistant project should begin by defining its own
trusted syntax and checking those fixtures, then prove the general theorems
without treating fixture acceptance as proof.

## 6. New files

```text
metasketch0/
  certified_core.py       independent finite certificate checkers
  formal_fixtures.py      deterministic language-neutral fixture writer
  tests_phase10.py        certificate, corpus, fixture, and renderer checks

formal/
  README.md               theorem signatures and porting order
  fixtures/finite_core_v1.json

tools/
  generate_v1_artifacts.py

rendered_examples/
  pointed_boundary.svg
```

## 7. Scope boundary

v1.0 does not claim:

- Lean, Coq, Agda, Isabelle, or Rocq verification;
- a general termination proof performed by the executable corpus audit;
- regular-logic completeness;
- arbitrary proof reconstruction;
- semantic partiality from bounded evaluator resources; or
- a Program E bridge to weak point-surjectivity.

The practical result is stronger than a test-only prototype but weaker than a
formal proof-assistant development: an auditable finite kernel with certificates
that can be checked independently of the procedures that produced them.
