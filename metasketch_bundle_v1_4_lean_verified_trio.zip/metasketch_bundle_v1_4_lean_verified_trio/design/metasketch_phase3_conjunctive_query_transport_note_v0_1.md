# Metasketch Phase 3: Conjunctive-Query Transport
## Finite theorem note v0.1

**Status:** Executable finite result and theorem-note skeleton. The mathematical
claims below are standard for finite directed graphs and existential-conjunctive
queries. The contribution here is their realization inside Metasketch's common
language of structural diagrams, predicate tiles, witnesses, and higher cells.

**Scope:** finite directed graphs, graph homomorphisms, regular-logic queries
built from relation atoms, conjunction, and existential quantification. No claim
is made about arbitrary first-order logic, negation, universal quantification,
or a general completeness theorem.

---

## 1. Question

Can one Metasketch object carry all of the following at once?

1. a finite graph pattern;
2. the corresponding existential-conjunctive statement about a graph;
3. a concrete witness that the statement holds; and
4. a compositional proof that witnesses transport along graph homomorphisms.

Phase 3 answers yes for a finite prototype.

---

## 2. Pattern graphs and their logical compilation

Let

\[
P=(V_P,E_P)
\]

be a finite directed pattern graph. Partition its vertices into visible vertices

\[
\bar x=(x_1,\ldots,x_r)
\]

and hidden witness vertices

\[
\bar z=(z_1,\ldots,z_s).
\]

The compiled regular-logic query is

\[
Q_P(\bar x)
=
\exists \bar z\;\bigwedge_{(u,v)\in E_P} E(u,v).
\]

A pattern match in a graph \(G\) is a graph homomorphism

\[
m:P\to G.
\]

The visible component of \(m\) supplies an assignment to \(\bar x\), while the
hidden component supplies existential witnesses for \(\bar z\).

### Phase 3 compilation theorem

For every finite graph \(G\), every visible assignment \(\bar a\), and every
finite pattern \(P\),

\[
G\models Q_P(\bar a)
\quad\Longleftrightarrow\quad
\text{there exists a pattern match }m:P\to G
\text{ extending }\bar a.
\]

The implementation checks this equivalence by exhaustive witness enumeration for
five patterns: an edge, a length-two path, a fork, a diamond, and a directed
triangle.

---

## 3. Structural transport and preservation tiles

Let

\[
h:G\to H
\]

be a graph homomorphism. If \(m:P\to G\) is a pattern match, then

\[
h\circ m:P\to H
\]

is also a pattern match, because every edge of \(P\) is mapped to an edge of
\(G\), then to an edge of \(H\).

At the predicate level, this becomes a Metasketch preservation tile:

```text
Q_P^G |- d_h^*(Q_P^H)
```

where `d_h` is the structural diagram that applies `h` to the visible query
variables.

The executable kernel includes a diamond pattern with visible endpoints and two
existentially quantified middle vertices. It verifies:

```text
Q_diamond^G |- d_h^*(Q_diamond^H)
Q_diamond^H |- d_k^*(Q_diamond^K)
------------------------------------------------
Q_diamond^G |- (d_k o d_h)^*(Q_diamond^K)
```

for a graph chain

\[
G\xrightarrow{h}H\xrightarrow{k}K.
\]

A deliberately non-edge-preserving map fails the first tile and returns the
visible endpoint assignment witnessing failure.

---

## 4. Witness transport as an explicit higher cell

The key Phase 3 object is not merely a Boolean assertion that transport
composes. It is a stored witness-level higher cell.

Given

\[
m:P\to G,
\qquad
G\xrightarrow{h}H\xrightarrow{k}K,
\]

the cell has boundary

\[
\begin{array}{ccc}
m & \xrightarrow{h\circ -} & h\circ m \\
\Big\downarrow {(k\circ h)\circ -} & \Downarrow & \Big\downarrow {k\circ -} \\
(k\circ h)\circ m & = & k\circ(h\circ m).
\end{array}
\]

The kernel stores this as:

```text
QueryTransportCoherenceCell3
```

and validates all of the following:

1. `h` and `k` are total edge-preserving maps;
2. the composite map `k after h` is the actual graph-map composite;
3. sequential witness transport is a valid pattern match;
4. direct witness transport is a valid pattern match; and
5. the two labelled witness maps are equal.

The reference example intentionally merges the two hidden vertices of a diamond
when moving from \(H\) to \(K\). This checks that the construction uses ordinary
homomorphisms, not accidentally injective embeddings.

---

## 5. What this demonstrates about Metasketch

Phase 3 is the first kernel result where the structural and logical halves are
not simply adjacent.

| Metasketch layer | Phase 3 object |
|---|---|
| Structural data | finite graphs and graph homomorphisms |
| Logical statement | existential-conjunctive graph pattern query |
| Proof witness | pattern match / homomorphism from the pattern |
| Preservation tile | homomorphism preserves the query |
| Higher cell | direct and sequential witness transport agree |

This is still standard graph and database mathematics. Its role is architectural:
it demonstrates that Metasketch can place structure, statement, witness, and
coherence into one typed compositional kernel without identifying them as one
untyped object.

---

## 6. Limits

The prototype does not yet provide:

- a complete proof search procedure for conjunctive queries;
- a theorem that every regular-logic proof has a normal form in Metasketch;
- generic enumeration of mixed critical branchings among structural rewrites,
  substitution, and predicate rules;
- visual rendering of existential witness regions and transport cells; or
- a connection from query transport to the reflection machinery of Program E.

The next mathematical target is to generalize witness transport from finite graph
homomorphisms to a controlled class of finite relational signatures, then state
an explicit normal-form or relative-completeness theorem for that fragment.
