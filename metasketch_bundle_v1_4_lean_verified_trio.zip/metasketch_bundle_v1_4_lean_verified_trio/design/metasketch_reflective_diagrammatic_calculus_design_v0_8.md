# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.8: raw-certificate reconstruction and trusted witness recovery

**Status:** A finished finite prototype slice, not a completed foundation. v0.8
extends v0.7 by reconstructing a semantic witness map from a restricted raw proof
tree that carries no stored `RelationalMatch` field.

**Supersedes:** v0.7 for current status. Earlier design documents and theorem
notes remain in `design/archive/` or `design/` as historical and supporting
material.

**Author:** Benjamin John Schulz
**Date:** July 1, 2026

## 0. Executive summary

Metasketch aims at one typed visual language in which structural diagrams,
logical predicates, proof tiles, and higher coherence cells can be represented
and checked together. It uses explicit level shifts for quotation and checking,
so practical homoiconicity does not silently become an unstratified truth
predicate.

v0.8 closes the most important remaining gap in the finite relational witness
fragment. In v0.7, a witness proof stored its semantic `RelationalMatch` object.
In v0.8, a **raw certificate** stores only atom facts, existential witness
binders, and conjunction structure. A checked procedure reconstructs the unique
match forced by that evidence.

The full regression suite has **121 checks**:

| Layer | Checks | Current status |
|---|---:|---|
| Public API | 5 | checked construction boundary |
| Phase 1 | 35 | finite syntax, semantics, tiles, and reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting and confluence fillers |
| Phase 2.5 | 9 | monoid structure--logic coherence |
| Phase 3 | 14 | graph-pattern query transport |
| Phase 4 | 11 | relational witness certificates and normal forms |
| Phase 5 | 5 | certificate--match adequacy with stored matches |
| Phase 6 | 13 | raw-certificate reconstruction without stored matches |
| Lift schema | 4 | reusable transport-normalization 3-cells |
| Program E audit | 5 | stratified quotation and missing bridge premises |
| Renderer | 10 | auditable semantic SVG scenes |

## 1. Trusted construction boundary

The public API exposes checked constructors for contexts, terms, predicates,
diagrams, tiles, and finite models. A Phase 6 `checked_raw_certificate` entry
point validates a raw certificate and returns both the raw tree and its
independently reconstructed match.

```text
metasketch0.api
  checked_context, checked_term, checked_predicate
  checked_diagram, checked_tile, checked_model
  model_from_parts
  checked_raw_certificate

metasketch0.unsafe_ast
  experimental raw AST constructors only
```

This is a trusted-path convention, not capability security in Python. Renderers,
quotation, and theorem-facing routines either receive checked objects or
revalidate at their own boundary.

## 2. Current mathematical core

### 2.1 Directed monoid reference presentation

The oriented rules

\[
(xy)z\to x(yz),\qquad ex\to x,\qquad xe\to x
\]

have a conventional termination-and-confluence proof. Every normal form is the
right comb of the unit-free atom word. The stored critical-pair fillers include
the directed rewrite-theoretic analogue of the associator pentagon. This is not
full Mac Lane coherence because the implementation uses a directed rewrite rule,
not an invertible associator.

### 2.2 Structure--logic coherence

For the monoid instance, structural rewriting lifts through predicate transport:

\[
r:d\Rightarrow d'
\quad\leadsto\quad
\operatorname{Lift}(r,Q):d^*Q\Rightarrow(d')^*Q.
\]

The current generic schema takes a structural one-step rewrite, a transport
operation, and a normalization strategy, then constructs a stored 3-cell only
when the two normalized branches have a verified common target. It is a reusable
finite schema, not a general polygraphic coherence theorem.

### 2.3 Finite relational witness layer

For a finite relation-only pattern \(P\) and finite model \(M\), an explicit
witness proof records relation-fact leaves, existential binders, and conjunction
structure. Phase 5 establishes certificate--match adequacy when the match is
stored in the proof object.

### 2.4 Phase 6 raw reconstruction

A Phase 6 raw certificate removes the stored match field:

\[
\rho=(P,M,\mathrm{root}).
\]

The root has exactly one leaf per pattern atom and one outer witness-binder prefix
containing every hidden variable exactly once. Every visible variable must occur in an atom. The reconstruction
algorithm collects variable values from atom occurrences and hidden binders,
checks that all evidence agrees, and constructs the resulting `RelationalMatch`.

For each accepted raw certificate:

\[
\operatorname{rec}(\rho)\in\operatorname{Match}_M(P),
\]

and it is the unique match realizing all evidence in \(\rho\). Canonical
rebuilding preserves the witness normal form modulo conjunction presentation and
alpha-display names.

This is a genuine strengthening over Phase 5, but it remains deliberately
narrow. It does not reconstruct a match from arbitrary proof terms or cover
visible variables that have no atom occurrence.

## 3. Program E status

Program E is now exercised on real proof data at two levels:

1. a stored Phase 5 witness proof; and
2. a Phase 6 raw proof tree without a stored match object.

Quotation always raises level:

\[
\mathsf{quote}_k:
\mathsf{Proof}_k\to
\mathsf{Code}_{k+1}[\mathsf{Proof}_k].
\]

Proof checking is syntactic and higher-level. The current evaluator may return a
value, `resource_exhausted`, or `unsupported`; resource exhaustion is not treated
as semantic divergence. The implementation contains neither a total universal
evaluator \(e:A\to\Omega^A\) nor a representation-complete code class for all
predicates on proof codes. Hence it does not produce the weak-point-surjectivity
premise required for a Lawvere-style barrier.

The present escape routes are:

\[
\boxed{
\text{stratification}
+\text{ representation incompleteness}
+\text{ no total universal evaluator}
}
\]

## 4. Visual calculus status

The semantic renderer projects checked proof objects to audited SVG scenes. It
renders typed ports, relation atoms, existential witness scopes, structural maps,
preservation tiles, higher coherence cells, and quotation membranes. Each SVG
contains a canonical semantic manifest and an audit hash.

The renderer remains one-way. It is not a freehand editor and does not reconstruct
proofs from arbitrary SVG graphics.

## 5. Artifact map

```text
metasketch0/
  api.py                    checked public API
  checked.py                validated syntax and finite-model wrappers
  raw_certificates.py       Phase 6 raw proof trees and witness reconstruction
  adequacy.py               Phase 5 stored-match adequacy
  proofs.py                 witness proof syntax, normalization, transport cells
  coherence_lift.py         generic finite coherence-lifting schema
  reflection.py             quotation, checking, bounded evaluation, membrane
  reflection_audit.py       Program E interface audit
  render.py                 audited semantic SVG rendering
  tests_phase6.py           raw reconstruction tests
```

Supporting notes:

```text
metasketch_monoid_rewriting_proof_note_v0_1.md
metasketch_phase5_certificate_match_adequacy_note_v0_1.md
metasketch_phase6_raw_certificate_reconstruction_note_v0_1.md
metasketch_program_E_reflection_audit_note_v0_1.md
```

## 6. What remains open

v0.8 does not claim:

- general regular-logic completeness;
- witness recovery from arbitrary unannotated proof syntax;
- a general coherence-lifting theorem for arbitrary polygraphs;
- a homotopy basis for relational proof rewrites;
- semantic partiality from finite resource exhaustion;
- a Lawvere bridge from universal evaluation to weak point-surjectivity; or
- a two-way visual editor.

## 7. Next decision

The strongest next extension is a **boundary-assignment proof node**. It would
supply concrete values for visible variables that do not occur in any atom,
extending raw reconstruction to truth-like and unanchored-visible queries.

The higher-value alternative is to port the established monoid proof and the
Phase 6 reconstruction theorem into a proof assistant. That would convert the
first Metasketch fragment from a conventional proof note plus exhaustive finite
tests into machine-checked metatheory.

Program E should remain paused until either extension makes the definable
reflective predicate class materially richer.
