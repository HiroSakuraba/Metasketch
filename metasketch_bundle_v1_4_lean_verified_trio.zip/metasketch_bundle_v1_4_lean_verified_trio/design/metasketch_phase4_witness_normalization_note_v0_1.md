# Metasketch Phase 4: Witness-Normalized Relational Tiles
## Finite theorem note v0.1

**Status:** Executable finite-model result. The note describes exactly what the
v0.6 kernel implements and tests. It does not claim a completeness theorem for
all regular logic, all relational structures, or all proof systems.

**Scope:** finite relation-only signatures; equality-free existential-conjunctive
patterns; finite models; relation-preserving maps; explicit finite witnesses.

---

## 1. Result in one sentence

For a finite relational pattern, every accepted Phase 4 witness certificate
normalizes to one canonical witness map; a checked relational homomorphism
transports that normal form; and direct versus sequential transport has a stored
3-cell whose two sides normalize to the same net transport trace.

This is familiar mathematics at the semantic level. Conjunctive queries have
canonical relational-pattern models, and homomorphisms are the natural maps that
preserve positive-existential facts. The Metasketch contribution is architectural:
atom evidence, conjunction, existential witnesses, structural transport, composed
tiles, and a higher coherence cell are represented in one executable typed kernel.

---

## 2. Fragment

Let \(\Sigma\) be a finite relation-only many-sorted signature. It has sorts
\(S\) and relation symbols

\[
R : S_1\times\cdots\times S_n.
\]

No operation symbols are admitted in this phase. That restriction makes the
relationship between a pattern and its canonical finite relational structure
transparent.

A pattern \(P\) consists of:

- finite typed variables \(V_P\),
- visible variables \(\bar x\subseteq V_P\),
- hidden witness variables \(\bar z=V_P\setminus\bar x\), and
- relation atoms \(R_i(\bar v_i)\).

It compiles to the existential-conjunctive query

\[
Q_P(\bar x)
=
\exists \bar z.\; \bigwedge_i R_i(\bar v_i).
\]

A witness in a finite model \(M\) is a sort-respecting assignment

\[
w:V_P\to M
\]

that makes every pattern atom true. Equivalently, it is a homomorphism from the
pattern's canonical relational structure into \(M\).

---

## 3. Proof terms

The proof language is intentionally small.

\[
\begin{array}{rcl}
\mathsf{Truth} &:& \text{proof of the empty conjunction},\\
\mathsf{AtomFact}(i,\bar a) &:& \text{proof of the }i\text{-th pattern atom},\\
\mathsf{AndIntro}(\pi_1,\pi_2) &:& \text{proof of a conjunction},\\
\mathsf{ExistsWitness}(z,\widetilde z,a,\pi) &:& \text{proof using witness }a,\\
\mathsf{Transport}(\pi,h) &:& \text{transport along a relational homomorphism }h,\\
\mathsf{Compose}(\tau_1,\tau_2) &:& \text{composition of compatible transports},\\
\mathsf{Coherence}_3(\tau_{\mathrm{direct}},\tau_{\mathrm{sequential}})
&:& \text{a cell between direct and sequential transport.}
\end{array}
\]

Here \(\widetilde z\) is a displayed binder name. It can be alpha-renamed and is
not part of the canonical witness data.

An accepted `PatternWitnessProof` is checked against a concrete finite witness:

1. every pattern atom occurs exactly once among its atom leaves;
2. every hidden variable receives exactly one existential witness;
3. each atom leaf is a fact in the finite model; and
4. atom values and witness values agree with the declared witness map.

This is a certificate language for one finite positive-existential instance. It
is not yet a full sequent calculus for arbitrary \(P\vdash d^*Q\).

---

## 4. Canonical witness normal form

The normal form erases two inessential syntactic choices:

\[
\text{alpha-renaming of existential display binders},
\qquad
\text{associativity and commutativity of conjunction.}
\]

For a valid proof of a pattern witness \(w\), the normal form is

\[
\operatorname{NF}(\pi)
=
\bigl(
P,
(w(v))_{v\in V_P},
(w(x))_{x\in\bar x},
(w(z))_{z\in\bar z},
\operatorname{sort}\{(R_i,w(\bar v_i))\}_i
\bigr).
\]

Variables are ordered by the pattern declaration; relation facts are ordered
canonically by relation name and displayed values. Therefore two certificates
with different conjunction trees, atom orders, or alpha-renamed display binders
have the same normal form exactly when they certify the same concrete pattern
witness.

### Finite normalization proposition

For every accepted Phase 4 pattern-witness certificate \(\pi\),
\(\operatorname{NF}(\pi)\) is defined and depends only on its underlying match.

**Reason.** Validation fixes each atom fact and hidden witness to the corresponding
component of the match. Normalization then sorts finite lists and discards display
binder names. No search or choice remains.

This is a direct proposition about the implemented certificate grammar, not a
claim about arbitrary proofs in first-order logic.

---

## 5. Transport and finite tile evidence

A relational homomorphism

\[
h:M\to N
\]

is a total sort-respecting map that preserves every relation tuple. If
\(w:P\to M\) is a pattern witness, define

\[
(h\circ w)(v)=h_{\operatorname{sort}(v)}(w(v)).
\]

Every atom \(R(v_1,\ldots,v_n)\) true under \(w\) remains true under
\(h\circ w\), by relation preservation. Thus the transported assignment is a
witness in \(N\).

The Phase 4 kernel records this as `WitnessTransportProof`. For a fixed finite
source model, `FiniteRelationalTileProof` enumerates every source witness and
stores a validated transport proof for each one. That is finite universal evidence
for this model and pattern:

\[
M\models Q_P(\bar a)
\quad\Longrightarrow\quad
N\models Q_P(h\bar a).
\]

It is not a replacement for a symbolic theorem over all structures.

---

## 6. Composition coherence

For composable relational homomorphisms

\[
M\xrightarrow{h}N\xrightarrow{k}L,
\]

a witness \(w:P\to M\) has two transport proofs:

\[
\mathsf{Transport}(w,k\circ h),
\qquad
\mathsf{Compose}(\mathsf{Transport}(w,h),\mathsf{Transport}(h\circ w,k)).
\]

Their normal forms agree because their net sortwise map is the same:

\[
k_s(h_s(w(v)))=(k\circ h)_s(w(v)).
\]

The kernel stores this equality as `WitnessTransportCoherenceCell3`. The cell is
not merely a Boolean test result: it contains the direct proof, sequential proof,
and the common normalized boundary.

---

## 7. Tested example

The regression suite uses a two-sort signature:

\[
\mathsf{Knows}:\mathsf{Person}^2,
\quad
\mathsf{Lives}:\mathsf{Person}\times\mathsf{City},
\quad
\mathsf{Road}:\mathsf{City}^2,
\quad
\mathsf{Open}:\mathsf{City}.
\]

Its main pattern is

\[
\exists a,b.
\mathsf{Knows}(s,t)
\land
\mathsf{Lives}(s,a)
\land
\mathsf{Lives}(t,b)
\land
\mathsf{Road}(a,b).
\]

The Phase 4 suite checks:

- query extensions agree with exhaustive witness enumeration;
- two syntactically different certificates normalize to the same witness form;
- a certificate missing atom evidence is rejected with a concrete diagnosis;
- a finite relational-tile proof covers every source witness;
- a non-homomorphic map is rejected with the missing image relation fact;
- direct and sequential witness transport have a validated 3-cell and the same
  normalized trace; and
- unary relation atoms and the empty conjunction are handled correctly.

---

## 8. Relation to established work

The semantic foundation is not new. Conjunctive queries are a standard database
fragment, and the Chandra--Merlin theory relates query containment to graph or
relational homomorphisms. Graphical Conjunctive Queries provides a diagrammatic
calculus for the same positive-existential terrain. Graphical Regular Logic gives
a broader graphical treatment of the regular fragment.

The novelty target for Metasketch remains narrower and architectural: integrate
finite witness certificates, structural homomorphisms, preservation tiles,
composition, and explicit higher coherence into one stratified diagrammatic
runtime that later can be quoted and reflected on by Program E.

---

## 9. Limits and next proof obligation

Not implemented or claimed:

- arbitrary regular formulas with equality inside pattern certificates;
- implication, negation, universal quantification, or disjunction;
- symbolic relative completeness over all finite or infinite structures;
- equality of arbitrary proof terms beyond the specified witness normal form;
- a full homotopy basis for relational proof rewrites; or
- a visual renderer.

The next serious theorem target is a carefully bounded relative-completeness
statement:

> For finite relation-only patterns and relational homomorphism transport, a
> finite valid witness instance admits a canonical Phase 4 certificate, and two
> such certificates are identified exactly by witness normal form.

The current kernel has implemented and tested the constructive direction. The
converse and the exact statement of “identified exactly” require a formal proof
and a more explicit syntax-to-semantics bridge.

---

## References

1. A. K. Chandra and P. M. Merlin, *Optimal Implementation of Conjunctive
   Queries in Relational Data Bases*, STOC 1977, DOI: 10.1145/800105.803397.
2. F. Bonchi, F. Seeber, and P. Sobociński, *Graphical Conjunctive Queries*,
   arXiv:1804.07626.
3. B. Fong and D. I. Spivak, *Graphical Regular Logic*, arXiv:1812.05765.
4. Y. Guiraud and P. Malbos, *Higher-Dimensional Categories with Finite
   Derivation Type*, Theory and Applications of Categories 22 (2009), 420--478.
