# Metasketch finite-core formalization portability plan

This directory is a **formalization target**, not a proof-assistant-verified
artifact. The release environment contains no installed Lean, Coq, Agda,
Isabelle, or equivalent prover, and its network policy prevented installation of
a local Lean toolchain. Nothing in this directory should be cited as a
machine-checked theorem.

The runnable Python kernel supplies independently replayable finite certificates.
The documents here give a narrow, portable theorem specification for a future
Lean 4, Coq, Agda, Isabelle, or Rocq port. The companion JSON fixtures are
language-neutral regression oracles; they are not proof objects for a general
theorem.

## Formalization order

### F1. Directed monoid normalization

Define ground terms:

\[
t ::= e \mid a \mid m(t,t),
\]

with the directed rewrite rules

\[
m(m(x,y),z)\to m(x,m(y,z)),\qquad m(e,x)\to x,\qquad m(x,e)\to x.
\]

Formalize:

```text
flatten    : MTerm α → List α
rightComb  : List α → MTerm α
Step       : MTerm α → MTerm α → Prop
Normal     : MTerm α → Prop
```

The theorem sequence is:

```text
step_decreases:
  Step s t → I t < I s

normal_rightComb:
  Normal (rightComb w)

normalization_sound:
  StepStar s n → Normal n → n = rightComb (flatten s)

confluence:
  StepStar s u → StepStar s v → ∃n, StepStar u n ∧ StepStar v n
```

A direct proof of `normalization_sound` through the `flatten` invariant may be
simpler than importing a general critical-pair or Newman's-lemma library.
Confluence then follows because every normalizing path has the same right-comb
target. The Python `MonoidNormalizationCertificate` checks concrete instances of
exactly this statement.

### F2. Pointed raw-certificate reconstruction

Fix finite many-sorted relation-only signatures, finite models, a relational
pattern, and an accepted raw certificate with:

- one fact leaf for each relational atom;
- a single outer binder prefix for hidden variables; and
- one typed boundary assignment for every visible variable absent from the atom
  matrix.

Formalize a reconstruction function:

```text
reconstruct : AcceptedRawCertificate P M → Match P M
```

and prove:

```text
reconstruct_satisfies_evidence:
  reconstruct ρ realizes every atom leaf, hidden binder, and boundary node

reconstruct_unique:
  realizesEvidence ρ μ → μ = reconstruct ρ

erase_reconstruct:
  reconstruct (erase m) = m
```

The Python `PointedReconstructionCertificate` recomputes all finite semantic
realizers and requires singleton uniqueness for each concrete instance.

## Fixture contract

`fixtures/finite_core_v1.json` encodes two monoid-normalization certificates and
one pointed raw-reconstruction certificate. A formalization should parse the
fixture syntax into its own term and certificate types, then prove that each
fixture is accepted by the trusted checker. Fixtures validate translation and
implementation agreement. They do not substitute for quantifier-level proofs.

## Reflection boundary

The formalization should not start by encoding Program E or a total truth
predicate. Quotation and proof checking remain typed, level-raising interfaces.
The first reflection formalization goal is only a type-safety theorem:

```text
sameLevelTruthCallIsIllTyped : ¬ WellTyped (eval_k code_k argument_k)
```

when the code/argument levels do not match the declared `eval_{k+1→k}`
interface. This is a type-discipline theorem, not Tarski's theorem or Lawvere's
theorem.
