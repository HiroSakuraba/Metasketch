# The Directed Monoid Presentation in Metasketch
## Termination, confluence, normal forms, and stored fillers

**Status:** Conventional proof note for the finite Metasketch rewriting kernel.
It proves properties of the three-rule directed monoid presentation. It does not
claim Mac Lane coherence for arbitrary monoidal categories.

## 1. Presentation

Let terms be generated from variables, a nullary symbol \(e\), and a binary
symbol \(m\).  Write juxtaposition for \(m\).  The directed rewrite system is

\[
\begin{aligned}
\alpha &: (xy)z \longrightarrow x(yz),\\
\lambda &: ex \longrightarrow x,\\
\rho &: xe \longrightarrow x.
\end{aligned}
\]

The Metasketch kernel stores each application as a `RewriteStep`, a composable
sequence as a `RewriteTrace`, and every enumerated critical-pair joining as a
`CoherenceCell3`.

## 2. Termination

Define a polynomial interpretation on all terms by

\[
I(x)=1,\qquad I(e)=1,\qquad I(m(s,t))=2I(s)+I(t).
\]

Every rule strictly decreases \(I\):

\[
\begin{aligned}
I((xy)z)-I(x(yz)) &= 2I(x)>0,\\
I(ex)-I(x) &= 2,\\
I(xe)-I(x) &= 1.
\end{aligned}
\]

Because \(I\) takes values in the positive integers, there is no infinite
rewrite sequence.

**Theorem 1.** The directed presentation is terminating.

## 3. Critical pairs and local confluence

The rules are left-linear.  With the kernel's ordered-pair critical-pair
enumeration, there are seven nontrivial overlaps.  The table records the source
and a common reduct; entries that differ only by the order in which the two rules
are named are retained because the implementation stores ordered branchings.

| Overlap | Source | Two branches join at |
|---|---|---|
| \(\alpha/\alpha\) | \(((xy)z)w\) | \(x(y(zw))\) |
| \(\alpha/\lambda\) | \(((ex)z)\) | \(xz\) |
| \(\alpha/\rho\), root | \(((xy)e)\) | \(xy\) |
| \(\alpha/\rho\), left | \(((xe)z)\) | \(xz\) |
| \(\lambda/\rho\) | \(ee\) | \(e\) |
| \(\rho/\alpha\) | \(((xy)e)\) | \(xy\) |
| \(\rho/\lambda\) | \(ee\) | \(e\) |

For example, the \(\alpha/\alpha\) overlap has two directed routes:

\[
((xy)z)w
\Rightarrow (xy)(zw)
\Rightarrow x(y(zw)),
\]

and

\[
((xy)z)w
\Rightarrow (x(yz))w
\Rightarrow x((yz)w)
\Rightarrow x(y(zw)).
\]

This is the directed rewrite-theoretic pentagon corresponding in shape to the
associator pentagon.  It is not a proof that the kernel has invertible
associators or full monoidal-category coherence.

Each table entry is joined by an explicit pair of stored rewrite traces in the
kernel.  Since all critical pairs are joinable, the critical-pair lemma yields
local confluence.  By termination and Newman's lemma:

**Theorem 2.** The directed presentation is confluent.

## 4. Normal forms

Define the flattened atom word by

\[
\operatorname{flat}(e)=\epsilon,
\qquad
\operatorname{flat}(x)=x,
\qquad
\operatorname{flat}(st)=\operatorname{flat}(s)\operatorname{flat}(t).
\]

All three rules preserve `flat`.  For a word \(a_1\cdots a_n\), define its
right comb by

\[
\operatorname{rc}(\epsilon)=e,
\qquad
\operatorname{rc}(a_1)=a_1,
\qquad
\operatorname{rc}(a_1\cdots a_n)=a_1\operatorname{rc}(a_2\cdots a_n)
\quad(n\ge 2).
\]

A normal term contains neither a unit as an argument of a multiplication nor a
multiplication as the left child of a multiplication.  By structural induction,
every normal term is exactly the right comb of its flattened word.

**Theorem 3.** Every term rewrites to the unique normal form

\[
\operatorname{rc}(\operatorname{flat}(t)).
\]

Consequently, equality of normal forms decides equality in the free monoid
presented by the three equations.

## 5. Relation to the implementation

The proof is independent of random testing.  The kernel supplements it with:

- replayable enumeration of the seven ordered critical branchings;
- stored, validated trace pairs for their joins;
- randomized strategy-independence tests; and
- an independent flatten-to-right-comb oracle.

The proof establishes the mathematical result.  The implementation checks that
the concrete representation of the result has not drifted.

## References

1. F. Baader and T. Nipkow, *Term Rewriting and All That*, Cambridge University
   Press, 1998.
2. J. W. Klop, *Term Rewriting Systems*, in the *Handbook of Logic in Computer
   Science*, Vol. 2, 1992.
3. M. H. A. Newman, *On Theories with a Combinatorial Definition of
   Equivalence*, Annals of Mathematics 43 (1942), 223--243.
