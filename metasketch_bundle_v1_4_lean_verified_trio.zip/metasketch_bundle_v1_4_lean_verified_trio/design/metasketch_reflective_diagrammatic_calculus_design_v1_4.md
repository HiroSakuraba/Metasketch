# Metasketch: A Reflective Diagrammatic Calculus
## Design document v1.4: the finite-core trio machine-checked

**Status:** Finite-core release. F1, F2 (evidence core), and F3 are all
Lean-machine-checked. The general metatheory beyond the declared scopes
remains open.

**Supersedes:** v1.3 for current implementation status. Earlier notes remain in
`design/` as the project lineage.

**Author:** Benjamin John Schulz
**Date:** July 1, 2026

## Executive summary

v1.4 changes no Python kernel semantics and adds no logical fragment. It
discharges the compilation debt left by v1.2 and v1.3: the F2 and F3 Lean
sources, which were written without a compiler, are now compiled and verified
alongside F1 in Lean 4 v4.31.0 (core only, no mathlib, no `sorry`).

| Formal target | Status | Exact scope |
|---|---|---|
| F1, directed monoid normalization | Machine-checked (v1.1) | full generality over any atom type |
| F2, evidence reconstruction | Machine-checked (v1.4) | complete consistent three-source evidence determines one assignment; erasure round trip |
| F3, reflection-interface safety | Machine-checked (v1.4) | safe grammar, same-level Boolean diagonal, typed cross-level predicate codes |
| F2 relation/model front end | Open | relation membership, atom coverage, binder spine, arities, sorts, finite models |
| Universal evaluator / Lawvere bridge | Open | no object-language completeness claim |

The Python suite contains **156 checks**, all passing after the update.

## 1. What compilation found

F3 (`ReflectionSafety.lean`) compiled as shipped: zero errors, zero warnings.

F1 (`MonoidNormalization.lean`) recompiled unchanged from its v1.1 record.

F2 (`PointedRawReconstruction.lean`) did not compile as shipped. Three proof
scripts needed repair; no theorem statement changed:

1. Inside `AcceptedPointedRawCertificate.reconstruct`, the bare name
   `reconstruct` resolved to the declaration being defined rather than the
   top-level evidence reconstructor. Qualified as `Metasketch.reconstruct`.
2. The three source-inclusion lemmas used plain `simp`, which flattened the
   left-associated append membership into a right-associated disjunction, so
   the stated `Or.inl`/`Or.inr` witnesses no longer matched. Replaced with
   `simp only [Occurs, allEvidence, List.mem_append]`, which preserves the
   declared shape.
3. `erasePointed_covers` closed each branch with `simp [hX]`, leaving an
   unsolved existential goal. Replaced with explicit membership witnesses
   through `List.mem_append` and `List.mem_map`.

A linter warning for the deliberately unused consistency premise in
`reconstruct_unique` was silenced by renaming the binder to `_hconsistent`;
the hypothesis stays in the statement because it belongs to the
accepted-certificate contract.

This is the expected pattern for uncompiled handoffs: the mathematics
survived intact and every defect was a tactic-level scripting issue. It also
validates the v1.2 decision to gate machine-checked claims on an actual
compile.

## 2. Verified theorem inventory

`formal/lean/VERIFICATION.txt` records the full list and axiom footprints.
Summary:

F1: `step_decreases`, `flatten_step`, `normal_rightComb`, `progress`,
`exists_normal`, `normal_eq_rightComb`, `normalization_sound`,
`normal_unique`, `confluence`.

F2: `reconstruct_realizes_evidence`, `reconstruct_unique`, the three
source-tagged realization theorems, `pointed_reconstruct_unique`, and the
erasure round trip `reconstruct_erase`.

F3: `safeInterface_no_sameLevel_total_complete_truth`,
`diagonal_not_represented`, `sameLevel_not_representationComplete` (with no
finiteness assumption on the code type), `evalPredicate_correct`, and
`crossLevel_representation_complete`.

Every theorem uses at most Lean's three standard foundational axioms.
`evalPredicate_correct` and `crossLevel_representation_complete` are proved
with no axioms at all: the safe cross-level path is definitional.

## 3. Suite and status bookkeeping

The Phase 11 handoff-honesty check previously asserted that F2's status file
said "not machine-checked." Since that statement is no longer true, both were
updated together: `F2_STATUS.txt` now records the verified compile, the three
itemized repairs, and the retained front-end scope limits, and the test now
asserts exactly that content plus a three-file `verify.sh`. The suite total
remains 156 checks. `F3_STATUS.txt` and `formal/README.md` were brought
current, and the stale v1.2 heading in the top-level README was corrected.

Kernel hygiene: two unused imports were removed from `reflection.py`. No
other Python source changed.

## 4. What remains open

- The F2 relation/model front end in Lean: typed patterns, finite models,
  relation membership, atom-index coverage, and binder-spine syntax, ending
  in a full pointed-relational-certificate verification.
- Equality in relational patterns.
- A general coherence-lifting theorem for arbitrary polygraphs.
- Relative completeness beyond the finite relation-only conjunctive fragment.
- A semantic account of partial evaluation.
- A non-tautological universal-evaluator bridge to weak point-surjectivity.
- A two-way visual editor.

## 5. Next decision

The v1.3 plan deferred fragment growth until the finite-core trio compiled.
That gate is now fully met. The recommended order is unchanged in spirit:
formalize the F2 front end next (typed finite models and accepted-certificate
syntax in Lean), because it converts the strongest remaining Python-only
premise into a theorem and gives the planned equality extension a fully
machine-checked baseline. Equality in relational patterns follows it.
