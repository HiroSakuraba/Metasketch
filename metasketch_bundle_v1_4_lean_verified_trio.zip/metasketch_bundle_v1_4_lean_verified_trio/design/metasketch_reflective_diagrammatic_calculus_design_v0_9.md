# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.9: pointed raw certificates and visible-boundary evidence

**Status:** A finished finite prototype slice, not a completed foundation. v0.9
extends v0.8 with an explicit typed boundary-assignment node for visible query
variables that do not occur in a relational atom.

**Supersedes:** v0.8 for current status. Earlier design documents and theorem
notes remain supporting material in `design/`.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

## 0. Executive summary

Metasketch aims at one typed visual language in which structural diagrams,
logical predicates, proof tiles, and higher coherence cells can be represented
and checked together. Practical reflection is stratified: quotation raises a
level, proof checking is syntactic, and the implementation does not define a
total same-level truth predicate.

v0.8 reconstructed a semantic relational match from raw proof evidence with no
stored `RelationalMatch` field. That reconstruction required every visible
variable to occur in a relation atom. v0.9 removes this narrow limitation.

A **boundary-assignment proof node** now supplies the selected value of each
visible variable absent from every atom. The node belongs to the pointed
certificate boundary, not the existential-conjunctive matrix. It therefore does
not interfere with hidden-variable scope or turn context assignment into an
internal truth claim.

The complete regression suite has **133 checks**:

| Layer | Checks | Current status |
|---|---:|---|
| Public API | 6 | checked construction and pointed-boundary surface |
| Phase 1 | 35 | finite syntax, semantics, tiles, and reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting and confluence fillers |
| Phase 2.5 | 9 | monoid structure and logic coherence |
| Phase 3 | 14 | graph-pattern query transport |
| Phase 4 | 11 | relational witness certificates and normal forms |
| Phase 5 | 5 | certificate and match adequacy with stored matches |
| Phase 6 | 13 | raw reconstruction from facts and hidden binders |
| Phase 7 | 11 | pointed boundaries for unanchored visible variables |
| Lift schema | 4 | reusable transport-normalization 3-cells |
| Program E audit | 5 | stratified quotation and absent bridge premises |
| Renderer | 10 | auditable semantic SVG scenes |

## 1. Trusted construction boundary

The public API exposes checked constructors for contexts, terms, predicates,
diagrams, tiles, finite models, and pointed raw certificates.

```text
metasketch0.api
  checked_context, checked_term, checked_predicate
  checked_diagram, checked_tile, checked_model
  model_from_parts
  BoundaryAssignmentProof
  checked_raw_certificate

metasketch0.unsafe_ast
  experimental raw AST constructors only
```

`checked_raw_certificate` accepts a raw matrix proof plus an optional sequence of
validated `BoundaryAssignmentProof` nodes. Renderers, quotation, and
theorem-facing routines either receive checked objects or revalidate at their
own boundary.

This is a trusted-path convention, not capability security in Python.

## 2. Pointed raw reconstruction

For a relational pattern \(P\), let \(U(P)\) be the visible variables absent
from all relation atoms. A pointed raw certificate is

\[
\rho=(P,M,\beta,\pi),
\]

where \(\pi\) contains the atom leaves and hidden witness binders, and
\(\beta\) supplies one typed assignment for each variable in \(U(P)\).

The reconstruction contract is intentionally strict:

1. every pattern atom occurs in the matrix exactly once;
2. hidden witnesses form one outer existential prefix;
3. boundary assignments name exactly the unanchored visible variables;
4. every value is in the relevant finite carrier; and
5. all repeated evidence agrees.

For every accepted certificate:

\[
\operatorname{rec}(\rho)\in\operatorname{Match}_M(P)
\]

is the unique finite match realizing all its evidence.

This includes truth-like pointed queries such as

\[
Q(p)\equiv\top.
\]

A certificate selecting \(p=u\) now carries `BoundaryAssignmentProof("p", "u")`.
The value is not inferred from \(\top\). It is supplied explicitly as the
visible query input.

## 3. Current mathematical core

### 3.1 Directed monoid reference presentation

The oriented rules

\[
(xy)z\to x(yz),\qquad ex\to x,\qquad xe\to x
\]

have a conventional termination-and-confluence proof. Every normal form is the
right comb of the unit-free atom word. Stored critical-pair fillers include the
directed rewrite-theoretic analogue of the associator pentagon. This is not full
Mac Lane coherence because the implementation uses directed rewrite rules, not
an invertible associator.

### 3.2 Structure and logic coherence

For the monoid instance, structural rewriting lifts through predicate transport:

\[
r:d\Rightarrow d'
\quad\leadsto\quad
\operatorname{Lift}(r,Q):d^*Q\Rightarrow(d')^*Q.
\]

The generic implementation builds a stored 3-cell only when the two normalized
branches have a verified common target. It is a reusable finite schema, not a
general polygraphic coherence theorem.

### 3.3 Finite relational certificate layer

For a finite relation-only pattern \(P\) and finite model \(M\), explicit
witness proofs record relation facts, existential binders, conjunction
presentation, and transport data. Phase 5 gives finite certificate and match
adequacy when a match is stored. Phases 6 and 7 remove that stored match field and
reconstruct it from checked evidence.

### 3.4 Pointed adequacy boundary

Raw certificate erasure from a stored match now adds exactly the boundary nodes
needed for variables in \(U(P)\):

\[
\operatorname{rec}(\operatorname{erase}(m))=m.
\]

The canonical witness normal form does not change. It is derived from the
reconstructed semantic match, so it remains invariant under conjunction
presentation, alpha-display names, and boundary display labels.

## 4. Program E status

Program E is now exercised on three kinds of real proof data:

1. stored Phase 5 witness proofs;
2. Phase 6 raw proof trees with facts and hidden binders; and
3. Phase 7 pointed raw proof trees with visible-boundary nodes.

Quotation always raises level:

\[
\mathsf{quote}_k:
\mathsf{Proof}_k\to
\mathsf{Code}_{k+1}[\mathsf{Proof}_k].
\]

Boundary nodes are ordinary typed proof data under quotation. They do not create
a universal evaluator, a representation-complete code class, or a same-level
truth predicate. The current escape routes remain:

\[
\boxed{
\text{stratification}
+\text{ representation incompleteness}
+\text{ no total universal evaluator}
}
\]

The evaluator may return a value, `resource_exhausted`, or `unsupported`.
Resource exhaustion remains an implementation status, not semantic divergence.

## 5. Visual calculus status

The semantic renderer projects checked proof objects to audited SVG scenes. It
currently renders typed ports, relation atoms, existential witness scopes,
structural maps, preservation tiles, higher coherence cells, and quotation
membranes.

Phase 7 boundary nodes are validated proof data but are not yet a separate
showcase scene. The next renderer increment should show them as labeled external
context ports, visually distinct from hidden witness regions.

The renderer remains one-way. It is not a freehand editor and does not reconstruct
proofs from arbitrary SVG graphics.

## 6. Artifact map

```text
metasketch0/
  api.py                    checked public API
  raw_certificates.py       raw proofs, pointed boundaries, reconstruction
  proofs.py                 witness proof syntax, normalization, transport cells
  adequacy.py               Phase 5 stored-match adequacy
  coherence_lift.py         generic finite coherence-lifting schema
  reflection.py             quotation, checking, bounded evaluation, membrane
  reflection_audit.py       Program E interface audit
  render.py                 audited semantic SVG rendering
  tests_phase7.py           pointed-boundary reconstruction tests
```

Supporting notes:

```text
metasketch_monoid_rewriting_proof_note_v0_1.md
metasketch_phase5_certificate_match_adequacy_note_v0_1.md
metasketch_phase6_raw_certificate_reconstruction_note_v0_1.md
metasketch_phase7_pointed_boundary_reconstruction_note_v0_1.md
metasketch_program_E_reflection_audit_note_v0_1.md
```

## 7. What remains open

v0.9 does not claim:

- general regular-logic completeness;
- recovery from arbitrary unannotated proof syntax;
- a general coherence-lifting theorem for arbitrary polygraphs;
- a homotopy basis for relational proof rewrites;
- semantic partiality from finite resource exhaustion;
- a Lawvere bridge from universal evaluation to weak point-surjectivity; or
- a two-way visual editor.

## 8. Next decision

The highest-value next move is now a **proof-assistant port** of two narrow
results:

1. the directed monoid termination and confluence theorem; and
2. pointed raw-certificate reconstruction for finite relation-only patterns.

That would convert the current conventional proof notes and exhaustive finite
regression checks into machine-checked metatheory without broadening the logic
prematurely.

The next local product improvement is smaller: extend the renderer with a pointed
boundary showcase. That would make the new external assignment nodes visually
explicit before any graphical editor is considered.
