# Metasketch: A Reflective Diagrammatic Calculus
## Design document v1.3: F3 reflection-interface safety handoff

**Status:** Finite-core release. F1 is Lean-machine-checked. F2 and F3 each
have dependency-free Lean sources with Python finite audits, but neither is
claimed machine-checked in this runtime because Lean was unavailable.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

## Executive summary

v1.3 formalizes F3, the narrow reflection boundary needed before any serious
Program E experiment.  It does not broaden the object logic.  It makes the
reflection contract explicit at three levels:

| Formal target | Status | Exact scope |
|---|---|---|
| F1, directed monoid normalization | Machine-checked | Lean 4 core, v1.1 record |
| F2, evidence reconstruction | Lean source + finite audit | complete consistent three-source evidence determines one assignment |
| F3, reflection-interface safety | Lean source + finite audit | safe grammar, Boolean diagonal, typed cross-level predicate codes |
| Universal evaluator / Lawvere bridge | Open | no object-language completeness claim yet |

The Python suite contains **156 checks**, all passing.  Phase 12 adds the F3
constructor, typing, and diagonal regression tests.

## 1. F3 theorem package

The new Lean source `formal/lean/ReflectionSafety.lean` contains:

```text
safeInterface_no_sameLevel_total_complete_truth
sameLevel_not_representationComplete
evalPredicate_correct
crossLevel_representation_complete
```

The first theorem is grammar-level: the declared `SafeInterface` constructors
have no member that is truth-shaped, same-level, total, and
representation-complete.

The second theorem is mathematical: for any same-level Boolean evaluator
\(e:A\times A\to\mathsf{Bool}\), its diagonal predicate

\[
d(x)=\neg e(x,x)
\]

is not represented by any row.  Thus no such evaluator is representation
complete for predicates on its own code type.

The last two theorems show the intended safe alternative.  Every lower-level
Boolean predicate has a next-level code, and the typed evaluator applies that
code only to lower-level arguments.

## 2. Corrected membrane policy

Earlier Python wording said that same-level truth could be allowed by giving up
totality or completeness, but the implementation rejected both restricted
forms.  v1.3 corrects that mismatch.

- same-level total **and** representation-complete truth is rejected;
- same-level partial truth is allowed as an explicitly restricted interface;
- same-level incomplete truth is allowed as an explicitly restricted interface;
- total representation-complete truth about a strictly lower level is allowed.

This does not create semantic truth inside Metasketch.  It records the exact
interface restriction, rather than treating all same-level discussion as
forbidden.

## 3. Claim discipline

F3 proves a type-disciplined interface theorem and a Boolean diagonal theorem.
It does **not** prove Tarski's theorem, Lawvere's theorem, an impossibility
result for arbitrary homoiconic languages, or the absence of arbitrary host
language functions outside the checked API.

The checker’s bounded evaluator remains a resource-limited implementation
feature.  `resource_exhausted` is not identified with semantic divergence.

## 4. Next work

1. Compile F2 and F3 using `formal/lean/verify.sh` under Lean 4 v4.31.0 and
   record the axiom footprints.
2. Define a small typed object-language of quoted Metasketch witness proofs in
   Lean, rather than only an abstract Boolean predicate interface.
3. Prove that quote/check on that syntax preserve levels and cannot construct a
   same-level evaluator term.
4. Only then define a predicate class independently and test whether a proposed
   universal evaluator yields weak point-surjectivity or clearly fails at a
   named premise.

See `metasketch_f3_reflection_interface_formalization_note_v0_1.md` for the
full F3 boundary.
