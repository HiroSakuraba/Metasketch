# Metasketch: A Reflective Diagrammatic Calculus
## Design document v1.0: proof-carrying finite core and formalization handoff

**Status:** Finished finite-core release. The general metatheory remains open.

**Supersedes:** v0.9 for current implementation status. Earlier notes remain in
`design/` as the project lineage.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

## Executive summary

Metasketch is a finite prototype for a stratified diagrammatic calculus in which
structural diagrams, existential-conjunctive predicates, witness certificates,
and selected coherence cells are checked together and rendered as auditable SVG.

v1.0 does not broaden the logical fragment. It strengthens the existing slice in
three ways:

1. It adds independently replayable certificate checkers for monoid
   normalization and pointed raw-certificate reconstruction.
2. It renders visible boundary assignments as external typed input ports, rather
   than conflating them with hidden existential witnesses.
3. It packages exact theorem statements and deterministic fixtures for a future
   proof-assistant port.

The full Python regression suite contains **142 checks**. This is executable
finite evidence. It is not a replacement for a proof-assistant proof.

| Layer | Checks | Status |
|---|---:|---|
| Public API | 6 | checked construction and trusted-boundary exposure |
| Phase 1 | 35 | finite syntax, semantics, tiles, and reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting and confluence fillers |
| Phase 2.5 | 9 | monoid structure/logic coherence |
| Phase 3 | 14 | graph-pattern query transport |
| Phase 4 | 11 | relational witness proofs and normal forms |
| Phase 5 | 5 | stored-match certificate/match adequacy |
| Phase 6 | 13 | raw reconstruction from facts and hidden binders |
| Phase 7 | 11 | pointed boundary assignments |
| Phase 10 | 9 | proof-carrying finite certificates and boundary rendering |
| Coherence lift | 4 | reusable finite lifting schema |
| Program E audit | 5 | stratified quotation and absent bridge premises |
| Renderer | 10 | audited semantic SVG scenes |

## 1. Trusted boundary

Use `metasketch0.api` for supported construction. It exposes checked constructors
for finite syntax, diagrams, models, tiles, raw pointed certificates, and the
v1.0 replayable certificate layer:

```text
checked_context, checked_term, checked_predicate
checked_diagram, checked_tile, checked_model, model_from_parts
BoundaryAssignmentProof, checked_raw_certificate
certify_monoid_normalization
certify_pointed_reconstruction
audit_finite_monoid_corpus
```

`metasketch0.unsafe_ast` remains explicitly experimental. Python cannot make
this capability-secure, so proof checking, rendering, quotation, and certificate
replay revalidate their inputs.

## 2. Proof-carrying finite core

### 2.1 Directed monoid certificates

The directed rules

\[
(xy)z\to x(yz),\qquad ex\to x,\qquad xe\to x
\]

admit right-associated unit-free word normal forms. The conventional mathematical
proof remains in the monoid proof note. The runnable certificate checker verifies
one concrete trace at a time:

\[
\operatorname{cert}(s)=
(s,\;s\Rightarrow^*n,\;\operatorname{flatten}(s),\;n,\;I\text{-descent}).
\]

The target is checked independently against

\[
n=\operatorname{rightComb}(\operatorname{flatten}(s)).
\]

A bounded exhaustive corpus of all terms through depth two over \(e,a,b\)
contains 147 terms. All certificates replay.

### 2.2 Pointed reconstruction certificates

A raw certificate has no stored semantic match. It combines fact leaves, an outer
hidden-witness binder spine, and typed boundary assignments for visible variables
absent from relation atoms. The replay checker recomputes both the reconstructed
mapping and the full finite set of semantic matches realizing all evidence.

For every accepted instance \(\rho\):

\[
\exists!m\in\operatorname{Match}_M(P)\;m\models\rho.
\]

This is an instance-level finite result. The theorem target for a future proof
assistant is the same statement quantified over every finite relation-only model
and accepted raw certificate of the declared syntax.

## 3. Visual status

The renderer remains a one-way projection from checked proof objects. It now
includes five showcases:

```text
directed_pentagon.svg
relational_witness.svg
transport_coherence.svg
quoted_proof_membrane.svg
pointed_boundary.svg
```

`pointed_boundary.svg` makes the Phase 7 distinction legible. Its input node is
outside every witness scope and carries a `boundary_assignment` semantic
reference. Ordinary wires cannot cross quotation membranes; all SVGs embed a
canonical semantic manifest and SHA-256 audit hash.

## 4. Program E status

Program E is still a constraint and audit program, not a completed no-go theorem.
Real raw proofs and replayable certificates can now be quoted one level higher.
The implementation has no total universal evaluator, no representation-complete
same-level predicate class, and no semantic truth operator. The active escape
routes are:

\[
\boxed{\text{stratification} + \text{representation incompleteness}.}
\]

Bounded evaluation statuses remain implementation diagnostics; they are not
semantic divergence claims.

## 5. Formalization plan

The release environment did not contain a proof assistant and could not install
Lean because network resolution was unavailable. Therefore v1.0 ships a portable
formalization handoff rather than mislabeled verification.

`formal/README.md` gives the first formalization sequence:

1. directed monoid normalization through the right-comb normal-form theorem;
2. unique pointed raw-certificate reconstruction; and
3. typed reflection-interface safety, before any Lawvere-style bridge attempt.

The language-neutral fixture file is a translation oracle, not a proof:

```text
formal/fixtures/finite_core_v1.json
```

## 6. What remains open

- Formal proof-assistant verification.
- Equality in relational patterns.
- A general coherence-lifting theorem for arbitrary polygraphs.
- Relative completeness beyond the finite relation-only conjunctive fragment.
- A semantic account of partial evaluation.
- A non-tautological universal-evaluator bridge to weak point-surjectivity.
- A two-way visual editor.

## 7. Next decision

The next expansion should be **equality in relational patterns** only after the
finite-core theorems have a real proof-assistant port. Equality tests whether
witness reconstruction and normal forms handle identifications among variables,
not only fact membership and existential assignment. It is the smallest logical
extension that exercises the existing architecture rather than adding a separate
domain.
