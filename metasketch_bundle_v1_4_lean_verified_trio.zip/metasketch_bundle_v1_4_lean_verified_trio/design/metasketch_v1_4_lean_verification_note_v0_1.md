# Metasketch v1.4 note: compiling and verifying the F2 and F3 handoffs

**Author:** Benjamin John Schulz
**Date:** July 1, 2026

## What changed

v1.2 and v1.3 shipped complete Lean sources for F2 and F3 with an explicit
rule: no machine-checked claim until an actual compile. The v1.4 environment
has Lean 4.31.0, so the debt was paid rather than restated.

## Compile outcomes

F3 compiled as shipped. F1 recompiled unchanged. F2 failed to compile with
three tactic-level defects, all repaired without touching any theorem
statement:

1. **Name-resolution collision.** Inside the definition of
   `AcceptedPointedRawCertificate.reconstruct`, the bare name `reconstruct`
   resolved to the declaration being defined, not the top-level evidence
   reconstructor, producing an application-type mismatch. Fix: qualify as
   `Metasketch.reconstruct`.
2. **simp or-flattening.** The three source-inclusion lemmas
   (`atomEvidence_in_all`, `binderEvidence_in_all`, `boundaryEvidence_in_all`)
   used plain `simp`, which rewrote membership in `(A ++ B) ++ C` into a
   right-associated three-way disjunction; the stated left-associated
   `Or.inl`/`Or.inr` witnesses then failed to typecheck. Fix:
   `simp only [Occurs, allEvidence, List.mem_append]`, which keeps the
   declared shape.
3. **Unsolved coverage goals.** `erasePointed_covers` closed each branch with
   `simp [hX]`, leaving an existential membership goal open. Fix: explicit
   witnesses through `List.mem_append` and `List.mem_map`, for example
   `Or.inl (Or.inl ⟨x, hatom, rfl⟩)`.

One linter warning (deliberately unused consistency premise in
`reconstruct_unique`) was silenced by renaming the binder to `_hconsistent`;
the hypothesis remains part of the stated accepted-certificate contract.

## Verification record

`verify.sh` compiles all three files and reports axiom footprints for the
fourteen headline theorems. Every theorem uses at most Lean's standard
propext, Classical.choice, and Quot.sound; the two cross-level F3 theorems
(`evalPredicate_correct`, `crossLevel_representation_complete`) use no axioms
at all. Full record: `formal/lean/VERIFICATION.txt`.

## Bookkeeping updated in lockstep

The Phase 11 handoff-honesty test asserted that F2's status file said
"not machine-checked." That assertion and the status file were updated
together: `F2_STATUS.txt` now records the verified compile, the itemized
repairs, and the retained front-end scope, and the test checks exactly that
plus a three-file `verify.sh`. `F3_STATUS.txt`, `formal/README.md`, and the
top-level README (which still carried a v1.2 heading) were brought current.
Two unused imports were removed from `reflection.py`. Suite: 156/156.

## What this does not claim

- The F2 relation/model front end is not formalized: relation membership,
  atom-index coverage, binder-spine syntax, arities, sorts, and finite-model
  enumeration remain Python premises.
- F3 is a type-discipline and diagonal theorem about the declared interface
  grammar. It is not Tarski's theorem, Lawvere's theorem, or a claim about a
  universal evaluator.

## Methodological remark

Both uncompiled handoffs turned out mathematically sound; every defect was in
tactic scripting, and two of the three came from `simp` normalizing goals away
from the shapes the proofs anticipated. That is a repeatable lesson for future
handoffs written without a compiler: prefer `simp only` with named lemmas and
explicit witnesses wherever a subsequent term-mode step depends on goal shape.
