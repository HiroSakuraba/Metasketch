# Metasketch F3: Typed Reflection-Interface Safety
## Formalization note v0.1

**Status:** Lean source supplied; compilation pending in the current runtime.

## 1. What F3 proves

F3 formalizes the narrow safety contract of the Metasketch reflection membrane.
It does **not** try to prove Tarski's undefinability theorem, Lawvere's
fixed-point theorem, or an impossibility theorem for every possible reflective
language.

The Lean source `formal/lean/ReflectionSafety.lean` proves three statements.

### 1.1 Safe interface grammar

The only values of `SafeInterface` are:

\[
\begin{array}{rcl}
\mathsf{quote}_k &:& k \to k+1,\\
\mathsf{check}_k &:& k \to k+1,\\
\mathsf{eval}_k &:& k \to k+1,\\
\mathsf{sat}_k &:& k \to k+1,\\
\mathsf{truthLower}_k &:& k \to k+1,\\
\mathsf{truthSamePartial}_k &:& k \to k,\\
\mathsf{truthSameIncomplete}_k &:& k \to k.
\end{array}
\]

The first five are stratified.  The last two make their escape route explicit:
the former is not total, and the latter is not representation-complete.

The theorem

```text
safeInterface_no_sameLevel_total_complete_truth
```

states that no `SafeInterface` inhabitant is simultaneously:

\[
\text{truth-shaped}
\;\land\;
\text{same-level}
\;\land\;
\text{total}
\;\land\;
\text{representation-complete}.
\]

This is a theorem about the declared grammar, not an assertion that arbitrary
host-language values cannot be manufactured outside the checked API.

### 1.2 Diagonal incompleteness

For any type \(A\) and any Boolean table

\[
e:A\times A\to\{0,1\},
\]

define

\[
d(x)=\neg e(x,x).
\]

F3 proves:

```text
diagonal_not_represented
sameLevel_not_representationComplete
```

No row \(e(c,-)\) equals \(d\), so no same-level evaluator can represent every
Boolean predicate on its own code type.  This theorem is generic in \(A\); it
does not need a finite-domain assumption.

This is the precise mathematical reason the safe grammar excludes the forbidden
interface.  It is still not a complete Tarski/Lawvere development, because no
object-language truth predicate, syntax class, or weak point-surjectivity map is
being asserted.

### 1.3 Cross-level completeness

A predicate \(p:A\to\{0,1\}\) at level \(k\) is quoted as a code at level
\(k+1\):

\[
\mathsf{quotePredicate}_k(p):\mathsf{Code}_{k+1}(A\to\mathsf{Bool}).
\]

The evaluator has exactly the type

\[
\mathsf{evalPredicate}_{k+1\to k}:
\mathsf{Code}_{k+1}(A\to\mathsf{Bool})
\times A_k
\to \mathsf{Bool}_{k+1}.
\]

F3 proves that every lower-level predicate has such a code and evaluates
correctly.  The expression `eval code code` does not type-check: its second
argument would need to be an \(A_k\), while the first code lives at level
\(k+1\).

## 2. Python alignment

The Python kernel now exposes checked constructors through `metasketch0.api`:

```text
safe_quote_interface
safe_check_interface
safe_eval_interface
safe_satisfaction_interface
safe_lower_truth_interface
safe_same_level_partial_truth_interface
safe_same_level_incomplete_truth_interface
```

A raw `InterfaceSpec` remains available only for audits and negative tests.
`SafeReflectionInterface` rechecks the membrane before construction.

Phase 12 validates the constructor family, rejects the forbidden same-level
truth interface, verifies typed cross-level evaluation, and exhaustively checks
finite Boolean tables for code-set sizes 0 through 3.

## 3. Honest boundary

F3 does not yet prove any of the following:

- that Metasketch has a semantic truth predicate;
- that all internally definable predicates are coded;
- that a universal evaluator exists or fails to exist;
- weak point-surjectivity;
- Tarski's theorem or Lawvere's theorem for the actual calculus;
- semantic divergence or a partiality theorem.

The next reflective step should be a small, explicit object-language syntax and
a formally typed quote/check interface for actual Metasketch witness proofs.  A
Lawvere-style bridge should be attempted only after the domain of coded
predicates is defined independently of representation completeness.
