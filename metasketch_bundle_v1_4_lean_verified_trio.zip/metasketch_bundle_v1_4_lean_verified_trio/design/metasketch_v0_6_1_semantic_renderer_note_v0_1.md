# Metasketch v0.6.1: Auditable Semantic Rendering
## Technical note

## Claim

This note records a narrow implementation result:

> Normalized finite Metasketch proof objects can be rendered into SVG scenes
> whose visual topology is validated against the underlying proof data and whose
> canonical semantic content is embedded in the artifact itself.

The result is about a finite prototype. It is not a theorem that every valid
regular-logic proof has a complete diagrammatic rendering.

## Pipeline

For a checked proof object \(\pi\), the renderer computes

\[
\pi
\xrightarrow{\operatorname{normalize}}
N(\pi)
\xrightarrow{\operatorname{scene}}
S(N(\pi))
\xrightarrow{\operatorname{SVG}}
\operatorname{SVG}(S).
\]

The scene is accepted only after validation. The audit payload is

\[
\left(
\operatorname{manifest}(S),
\operatorname{SHA256}(\operatorname{canonicalJSON}(\operatorname{manifest}(S)))
\right).
\]

The payload is written into an SVG `<metadata>` element.

## Invariance result in the implemented fragment

For Phase 4 witness proofs, normalization discards:

- display names used for existential binders; and
- conjunction bracketing and order.

Therefore, when two accepted proof objects certify the same finite relational
match and differ only by those presentation choices,

\[
N(\pi_1)=N(\pi_2)
\quad\Longrightarrow\quad
\operatorname{manifest}(S(N(\pi_1)))
=
\operatorname{manifest}(S(N(\pi_2))).
\]

The regression suite checks this equality directly through the canonical JSON
and the resulting SHA-256 hash.

## Visual safety properties

### Witness scoping

Every existential witness binder belongs to a witness region. Every outgoing wire
from that binder must target a relation input inside that region:

\[
\operatorname{wire}(z)\subseteq\operatorname{scope}(z).
\]

### Quotation membranes

A membrane encloses quoted lower-level data. Edges that cross its boundary must
be typed code edges:

\[
\mathsf{code\_out}(\mathsf{Code}_{k+1}[X_k])
\to
\mathsf{code\_in}(\mathsf{Code}_{k+1}[X_k]).
\]

An ordinary variable, structural, or proof wire crossing the same boundary is
rejected during scene validation.

### Rendered 3-cells

A rendered 3-cell contains two boundary traces. The validator requires that both
traces begin at one source node, end at one target node, and compose edge by edge.
Thus a 3-cell cannot be attached to merely similar-looking routes.

## Artifacts

The gallery contains four demonstrations:

1. directed rewrite-theoretic pentagon;
2. finite relational witness certificate;
3. direct versus sequential relational witness transport; and
4. a quoted proof behind a level-raising membrane.

All four are generated from live kernel objects. None is hand-authored SVG.

## Limits

The semantic hash certifies the scene manifest, not a full formal proof of the
underlying metatheory. The existing finite proof checker, relational witness
validator, and 3-cell construction remain the trusted kernel for these examples.

The next theorem-facing task is the v0.7 finite relative-completeness statement
for relation-only conjunctive patterns. The renderer makes the theorem's proof
objects inspectable; it does not substitute for the theorem.
