# Metasketch v1.1 note: Lean verification of F1 and fixture-loop closure

**Author:** Benjamin John Schulz
**Date:** July 1, 2026

## What changed

v1.0 shipped a formalization handoff because its build environment could not
install a proof assistant. The v1.1 build environment could, so the handoff
for F1 was discharged rather than re-documented.

## The Lean development

`formal/lean/MonoidNormalization.lean` is dependency-free Lean 4 (v4.31.0,
core only). It defines `MTerm`, the three oriented rules closed under
congruence (`Step`), `StepStar`, `Normal`, `flatten`, `rightComb`, and the
polynomial interpretation `interp`, then proves:

1. `interp_pos`, `step_decreases`: strict polynomial descent (termination).
2. `flatten_step`, `flatten_stepStar`: the unit-free leaf word is a rewrite
   invariant.
3. `normal_rightComb`: every right comb is normal.
4. `progress`: every term is normal or steps, proved constructively by the
   same case split the Python normalizer uses.
5. `exists_normal`: existence of normal forms by well-founded recursion on
   `interp`.
6. `normal_eq_rightComb`: normal terms are exactly the right combs of their
   own leaf words.
7. `normalization_sound`: any normal reduct of `s` equals
   `rightComb (flatten s)`. This is the general statement whose instances the
   Python `MonoidNormalizationCertificate` replays.
8. `normal_unique` and `confluence`: uniqueness of normal forms and rejoining
   of arbitrary reducts, derived without any critical-pair machinery.

The axiom footprint is `propext`, `Classical.choice`, `Quot.sound` only, with
no `sorry`. `formal/lean/verify.sh` recompiles the file and reprints the
footprint; `formal/lean/VERIFICATION.txt` records the run.

## Fixture-loop closure

`metasketch0.formal_fixtures` gains `term_from_json`,
`monoid_certificate_from_json`, and `replay_fixture_bundle`. Phase 10 now
replays the shipped `formal/fixtures/finite_core_v1.json` and rejects a
tampered normal form, so the translation oracle and the checker cannot drift
apart silently. Pointed-reconstruction entries serialize mappings and evidence
but not the finite model, so they are counted structurally rather than
replayed; this is stated in the replay contract and remains an F2-port task.

The Lean file carries `rfl` cross-checks for the two fixture instances
(pentagon source and `m(m(a,b),e)`), tying the Lean definitions to the same
oracle.

## What this does not claim

- F2 (unique pointed reconstruction) is not machine-checked.
- The Program E audit is unchanged and is not Tarski's or Lawvere's theorem.
- The Lean proof covers the ground fragment the kernel actually normalizes;
  it says nothing about open terms or extended signatures.

## Kernel hygiene fixes folded into v1.1

- `proofs.py`: `Mapping` was used in an annotation but never imported. Deferred
  annotations masked the bug; it would have surfaced under
  `typing.get_type_hints`. Fixed by importing `Mapping`.
- `certified_core.py`: removed unused imports and a dead `by_depth`
  accumulator in `enumerate_ground_monoid_terms`.
- `reflection.py`: removed a dead `expected` local in the REFL rule (the live
  check below it was already complete).
- `render.py`: removed a dead `port_table` local.
- `run_all_tests.py`: docstring said the suite ran "through v0.9"; corrected.
- v0.6 design doc heading contained an em dash; replaced per project
  convention.

Suite: 144/144 passing after all changes.
