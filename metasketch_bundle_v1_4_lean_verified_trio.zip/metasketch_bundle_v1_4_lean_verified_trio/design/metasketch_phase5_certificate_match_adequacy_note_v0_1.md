# Metasketch Phase 5: Finite Certificate--Match Adequacy
## A narrow theorem for the relation-only existential-conjunctive fragment

**Status:** Implemented finite adequacy result. This note deliberately does not
claim completeness for arbitrary regular logic or arbitrary proof terms.

## 1. Fragment

Fix a finite many-sorted relation-only signature, a finite relational pattern
\(P\), and a finite model \(M\).  Let

\[
V_P=\bar x\sqcup\bar z
\]

be the pattern variables, split into visible variables \(\bar x\) and hidden
existential variables \(\bar z\).  If the atoms of \(P\) are

\[
R_i(\bar v_i),\qquad i=1,\ldots,n,
\]

then the compiled query is

\[
Q_P(\bar x)=\exists\bar z.\bigwedge_{i=1}^{n}R_i(\bar v_i).
\]

A semantic match is a sort-respecting map

\[
w:V_P\to M
\]

that sends every pattern atom to a true relation tuple in \(M\).  Denote the
finite set of matches by \(\operatorname{Match}_M(P)\).

## 2. Certificates and normal forms

A Phase 5 witness certificate contains:

- one atom-fact leaf for every pattern atom;
- one explicit witness binder for every hidden variable; and
- a conjunction tree joining the atom leaves.

Validation checks that each leaf is a fact in \(M\), each binder agrees with the
witness assignment, and every required atom and hidden variable occurs exactly
once.

The normal form forgets only presentation choices:

\[
\text{display names of bound variables},
\qquad
\text{order and bracketing of conjunction.}
\]

It retains the ordered witness assignment and canonically sorted relation facts.
Write \(\operatorname{NF}(\pi)\) for this normal form.

## 3. Build and erase

The implementation defines two operations:

\[
\operatorname{build}:
\operatorname{Match}_M(P)
\to
\operatorname{Cert}^{\mathrm{can}}_M(P),
\]

which creates the fixed-order canonical certificate for a match, and

\[
\operatorname{erase}:
\operatorname{Cert}^{\mathrm{can}}_M(P)
\to
\operatorname{Match}_M(P),
\]

which returns the verified witness map carried by the certificate.

The certificate object currently carries its witness map explicitly. Therefore
this is an adequacy theorem for the implemented certificate discipline, not a
claim that arbitrary unannotated proof syntax can be reconstructed into a match.
That distinction is intentional and important.

## 4. Finite adequacy theorem

**Theorem.** For every fixed finite relation-only pattern \(P\) and finite model
\(M\):

1. \(\operatorname{erase}(\operatorname{build}(w))=w\) for every
   \(w\in\operatorname{Match}_M(P)\).
2. For every accepted certificate \(\pi\),

   \[
   \operatorname{NF}(\pi)
   =
   \operatorname{NF}(
   \operatorname{build}(
   \operatorname{erase}(\pi))).
   \]

3. For a visible assignment \(\bar a\),

   \[
   M,\bar a\models Q_P
   \quad\Longleftrightarrow\quad
   \exists\pi\in\operatorname{Cert}^{\mathrm{can}}_M(P)
   \;\operatorname{visible}(\pi)=\bar a.
   \]

Equivalently, normalized accepted certificates are in bijection with concrete
pattern matches.

### Proof

For (1), `build` inserts the values of \(w\) into every atom leaf and hidden
binder; `erase` returns that same assignment.  Validation confirms that the
assignment is a genuine match.

For (2), validation requires each atom fact and witness binder to agree with the
carried match.  Normalization discards only alpha-display names and conjunction
presentation.  Hence rebuilding the same match produces the same normal form.

For (3), the ordinary existential-conjunctive semantics says exactly that some
assignment to \(\bar z\) makes every atom true.  Such an assignment is a match;
(1) builds its accepted certificate.  Conversely, an accepted certificate
contains a valid match by validation, yielding an existential witness for the
compiled query. \(\square\)

## 5. What the test suite establishes

The v0.7 suite exhaustively checks the theorem's ingredients on a two-sorted
pattern involving `Knows`, `Lives`, and `Road`, plus a unary `Open` pattern.  It
checks both round trips, equality modulo normal form for deliberately reordered
and alpha-renamed proofs, and equality of visible assignment sets derived from
query semantics and accepted canonical certificates.

This is deliberately narrower than a general relative-completeness theorem. The
next genuine expansion would either remove the explicit witness-map field from
certificates and reconstruct it, or enlarge the logic fragment while retaining a
comparable normal-form theorem.

## References

1. A. K. Chandra and P. M. Merlin, *Optimal Implementation of Conjunctive
   Queries in Relational Data Bases*, STOC 1977.
2. F. Bonchi, F. Seeber, and P. Sobociński, *Graphical Conjunctive Queries*,
   arXiv:1804.07626.
