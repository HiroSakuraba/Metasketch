# Metasketch Phase 6: Raw Certificate Reconstruction
## A finite reconstruction theorem for anchored existential-conjunctive proofs

**Status:** Implemented and exhaustively audited on the delivered finite examples.
This note strengthens Phase 5 by removing the stored `RelationalMatch` field from
one restricted certificate syntax. It does not claim reconstruction for arbitrary
regular-logic proofs, arbitrary raw syntax, or unanchored visible variables.

## 1. Why Phase 6 is needed

A Phase 5 `PatternWitnessProof` stores a semantic match explicitly:

\[
\pi=(w,\mathrm{root}),
\]

where \(w\) is a typed relational match and `root` is a tree of atom facts,
conjunction introductions, and existential witness binders. That gives a useful
certificate discipline, but it leaves open whether the proof tree itself carries
enough information to recover \(w\).

Phase 6 answers this question for a restricted raw syntax. A raw certificate
stores only

- one concrete model fact for every pattern atom;
- one concrete existential witness for every hidden variable; and
- a conjunction tree joining the fact leaves.

It stores no `RelationalMatch` object.

## 2. Fragment and anchoring condition

Fix a finite many-sorted relation-only signature, a finite relational pattern
\(P\), and a finite model \(M\). Write the variables as

\[
V_P=\bar x\sqcup\bar z,
\]

where \(\bar x\) are visible variables and \(\bar z\) are hidden existential
variables. Let the atoms be

\[
R_i(\bar v_i),\qquad i=1,\ldots,n.
\]

A raw certificate is reconstruction-eligible only when every visible variable
occurs in at least one atom. This is the **anchoring condition**.

The condition is necessary for this first syntax. If a visible variable does not
occur in any fact, a proof of the empty-conjunction query does not contain a
concrete value for it. Such queries remain valid regular logic, but they need a
future explicit boundary-assignment node before a concrete witness map can be
reconstructed.

## 3. Raw certificate syntax

A raw certificate is

\[
\rho=(P,M,\mathrm{root}),
\]

where `root` has an outer existential-binder prefix followed by a conjunction matrix built from:

\[
\begin{aligned}
\mathsf{Truth} & & \text{for the empty conjunction},\\
\mathsf{Atom}(i,\bar a) & & \text{for a concrete fact }R_i(\bar a),\\
\mathsf{And}(p,q) & & \text{for conjunction introduction},\\
\mathsf{Exists}(z,\text{name},a,p) & & \text{for an explicit witness }a.
\end{aligned}
\]

Validation requires:

1. every atom index appears exactly once;
2. every hidden variable has exactly one existential binder;
3. existential binders form one outer prefix over the complete conjunction matrix;
4. every atom tuple is a true tuple of the corresponding relation in \(M\);
5. every binder witness is in the carrier of its declared sort; and
6. all occurrences of a pattern variable force the same value.

The final condition is crucial. Distinct true facts can still be mutually
inconsistent as evidence for one pattern match.

## 4. Reconstruction

For every pattern variable \(v\), collect its evidence set

\[
E_\rho(v)=
\{\text{values at occurrences of }v\text{ in atom leaves}\}
\cup
\{\text{binder witness for }v\text{ when }v\in\bar z\}.
\]

A certificate is accepted only if every \(E_\rho(v)\) is nonempty and all of its
values agree. Define

\[
\operatorname{rec}(\rho)(v)
=
\text{the unique value in }E_\rho(v).
\]

The resulting total assignment is then checked as a `RelationalMatch`. This final
check verifies all typing and all relation atoms independently of the proof-tree
presentation.

## 5. Finite reconstruction theorem

**Theorem.** Let \(P\) be an anchored finite relation-only pattern and \(M\) a
finite model. For every accepted raw certificate \(\rho\) for \((P,M)\):

1. \(\operatorname{rec}(\rho)\) is a typed relational match in
   \(\operatorname{Match}_M(P)\).
2. It is the unique match in \(\operatorname{Match}_M(P)\) that realizes every
   atom fact and existential witness carried by \(\rho\).
3. Canonical rebuilding followed by witness normalization is independent of
   conjunction order, conjunction bracketing, and displayed binder names.

### Proof

Each atom leaf forces one value for every variable occurring in that atom. Each
hidden binder forces the value of its hidden variable. The anchoring condition
ensures every visible variable receives atom evidence; the binder condition
ensures every hidden variable receives witness evidence. Acceptance requires all
values forced for a fixed variable to agree, so \(\operatorname{rec}(\rho)\) is a
well-defined total assignment.

Each atom leaf is checked against its relation in \(M\), and every such leaf has
exactly the tuple obtained by applying \(\operatorname{rec}(\rho)\) to its pattern
atom. Hence the reconstructed assignment satisfies every atom and is a relational
match. Any match realizing the same raw evidence agrees with
\(\operatorname{rec}(\rho)\) on every variable, so it is equal to it. Canonical
rebuilding reads only the recovered assignment and the fixed pattern order, so
alpha-display names and conjunction presentation do not affect its normal form.
\(\square\)

## 6. Executable checks

The delivered Phase 6 suite verifies:

- a raw certificate has no stored semantic `match` field;
- a reordered, alpha-renamed proof tree reconstructs the original match;
- exhaustive finite enumeration finds exactly one semantic match realizing all
  raw evidence;
- reconstruction preserves the Phase 5 canonical witness normal form;
- inconsistent but individually true atom facts are rejected;
- existential binders with incomplete conjunction scope are rejected;
- missing hidden binders are rejected; and
- an unanchored visible variable is rejected with an explicit diagnostic.

The raw certificate is also a valid Program E quotation target. Quotation raises
its level, while reconstruction remains a finite lower-level proof check rather
than a same-level semantic truth predicate.

## 7. Limits and next extension

This result does not recover witnesses from arbitrary proof syntax. It relies on
concrete atom facts and explicit hidden binders. The most natural extension is a
**boundary-assignment node** for visible variables that do not occur in atoms.
That would extend reconstruction to the regular-logic truth pattern and other
unanchored visible queries without changing the central consistency argument.

## References

1. A. K. Chandra and P. M. Merlin, *Optimal Implementation of Conjunctive
   Queries in Relational Data Bases*, STOC 1977.
2. F. Bonchi, F. Seeber, and P. Sobociński, *Graphical Conjunctive Queries*,
   arXiv:1804.07626.
