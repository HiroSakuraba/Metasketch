# Metasketch-0 v0.5

A dependency-free finite prototype for a stratified diagrammatic calculus. It is
not a complete foundation, proof assistant, or general theorem about reflection.

## Run

```bash
python run_all_tests.py
python -m metasketch0.tests
python -m metasketch0.tests_phase2
python -m metasketch0.tests_phase25
python -m metasketch0.tests_phase3
python demo.py
```

The v0.5 suite has **68 checks**:

| Phase | Checks | Focus |
|---|---:|---|
| 1 | 35 | finite structural and logical kernel, syntax hygiene, reflection interfaces |
| 2 | 10 | directed monoid rewriting and stored confluence fillers |
| 2.5 | 9 | monoid structure/logic coherence |
| 3 | 14 | conjunctive-query transport and witness-level coherence |

## What v0.5 adds

- Public checked wrappers: `CheckedPredicate`, `CheckedDiagram`, and
  `CheckedTile`.
- Exhaustive finite-model validation against a declared signature.
- Nested capture-avoidance tests for simultaneous substitution.
- Finite directed pattern graphs compiled into existential-conjunctive queries.
- Explicit graph-homomorphism witnesses for query satisfaction.
- Preservation tiles for graph-pattern queries.
- `QueryTransportCoherenceCell3`, an explicit higher cell for direct versus
  sequential witness transport.

## Phase 3 in one picture

A pattern graph \(P\) with visible vertices \(\bar x\) and hidden vertices
\(\bar z\) compiles to:

```text
Q_P(xbar) = exists zbar. conjunction over pattern edges E(u,v)
```

A match \(m:P -> G\) is a concrete existential witness. A graph homomorphism
\(h:G -> H\) transports both the query and its witness. For a composable chain
\(G -> H -> K\), the kernel stores a verified cell:

```text
(k after h) after m  =  k after (h after m)
```

This is standard graph and database mathematics. The Metasketch contribution is
architectural: the structure map, query, witness, tile, and coherence witness
all live in one typed executable kernel.

## Important limits

- Raw AST constructors remain available for experiments. The checked wrappers
  are the public route for claims and tests.
- Finite-model validation and query transport are finite. No infinite-model or
  general regular-logic theorem is claimed.
- The Phase 2 directed pentagon is a rewrite-theoretic analogue of the
  associator pentagon, not full Mac Lane coherence.
- The reflection routine proves a finite same-level Boolean incompleteness fact,
  not Tarski's theorem or Lawvere's theorem.
- No visual renderer is implemented yet.

## File map

```text
metasketch0/
  syntax.py            raw syntax, hygiene, static validation
  checked.py            public checked wrappers
  semantics.py          finite semantics and model validation
  tiles.py              preservation tiles and composition
  queries.py            graph patterns, query compilation, matches, homomorphisms
  query_transport.py    witness-level transport coherence cells
  reflection.py         quotation, certificate checking, bounded evaluation, membrane
  rewriting.py          first-order rewriting with stored traces
  coherence.py          monoid critical-pair fillers and directed pentagon
  tile_coherence.py     monoid structure/logic coherence cells
  tests*.py             four finite regression phases

design/
  metasketch_reflective_diagrammatic_calculus_design_v0_5.md
  metasketch_phase3_conjunctive_query_transport_note_v0_1.md
```
