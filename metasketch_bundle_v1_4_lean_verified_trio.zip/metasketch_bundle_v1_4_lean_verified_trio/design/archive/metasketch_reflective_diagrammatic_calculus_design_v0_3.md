# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.3 (implementation progress and revised plan)

**Status:** Design document plus implementation report. It describes a research
program and a tested kernel that realizes the first phases of it. It does not
claim a completed foundation.

**Supersedes:** v0.2. The full design rationale (the motivation, the membrane
philosophy, the long-form discussion of stratification) lives in v0.2 and is
carried forward unchanged except where noted. v0.3 adds the implementation
progress, updates the theorem and phase status, records two bugs found and fixed,
and revises the immediate next step. v0.2 is included alongside this document for
reference.

**Author:** Benjamin John Schulz
**Date:** June 30, 2026

No em dashes are used anywhere, per project convention.

---

## 0. What v0.3 changes

v0.2 specified the calculus and named its first milestone (Section 16 of v0.2): a
preservation tile that composes and is semantically sound in finite models, plus
a minimal membrane checker separating a legal higher-level check from an illegal
same-level truth call. v0.3 reports that this milestone is met and exceeded by a
tested kernel called Metasketch-0, and that two further layers are done:

1. **Phase 1** realizes the structural and logical core, the preservation tile
   with its two readings, and the controlled-reflection safeguards, including an
   executable demonstration of the reflection-cost lower bound.
2. **Phase 2** orients the monoid signature as a rewriting system and computes its
   coherence, recovering Mac Lane's pentagon as a critical pair.
3. **Phase 2.5** is the first place structure and logic cohere through an explicit
   3-cell: transporting a predicate along a diagram commutes with structurally
   rewriting that diagram, and the coherence cell is shown to be exactly the
   associativity axiom by a non-associative counterexample.

Test status of the delivered kernel: Phase 1 31/31, Phase 2 9/9, Phase 2.5 8/8,
total 48/48 passing, combined runner exits zero.

---

## 1. Design recap (carried from v0.2)

### 1.1 The spine

A stratified diagrammatic calculus with a base of structural diagrams and a layer
of logical predicates over them, connected by transport (reindexing). Structural
diagrams compose as string diagrams; predicates form a regular-logic fragment
(Top, equality, relations, conjunction, existential quantification); a
preservation tile is the primitive that binds the two.

### 1.2 The preservation tile

A preservation tile is the judgment

```
P |- d^*Q
```

for a structural diagram d from a source context to a target context, a predicate
P on the source, and a predicate Q on the target. It has two simultaneous
readings:

- structural: every input satisfying P is sent by d to an output satisfying Q;
- logical: P entails the substitution of Q along d.

Composition of tiles along a shared middle predicate is the first coherence
obligation (v0.2 theorem target for tile composition, the interchange law).

### 1.3 Controlled reflection and the membrane

Reflection is stratified. Quotation raises a level. A checker inspects a lower
level from a strictly higher one. Evaluation is partial and never coerces
divergence to a Boolean. The one interface the membrane forbids is a same-level,
total, representation-complete truth predicate, because that configuration is
inconsistent. This is the design's answer to the reflection obstruction: the
calculus keeps the useful reflective capabilities and refuses only the one that
collapses.

### 1.4 Reflection-cost profile

Each reflective capability carries a level cost sigma_X, the minimum number of
level increases needed to host it safely. The design conjectures the profile
sigma_wf, sigma_check, sigma_eval, sigma_sat all at most one, and sigma_truth at
least one for a same-level total representation-complete truth. v0.3 demonstrates
this profile on finite instances (Section 2.5).

---

## 2. Implementation progress: Metasketch-0

Metasketch-0 is a dependency-free Python kernel. Every claim below is a decidable
finite computation carried out by the test suite, not an assertion. The suite
prints per-item PASS or FAIL and a summary, and the runner exits nonzero on any
failure.

### 2.1 Phase 1: structural and logical core, tiles, reflection

Realized and tested:

- Sorts, terms, contexts, and structural diagrams as term substitutions, with
  composition equal to substitution.
- Regular-logic predicates interpreted as subsets of a finite product of carriers.
- Reindexing d^*Q as syntactic substitution, cross-checked against the semantic
  preimage under d.
- The preservation tile and its finite-model validity check.
- Tile composition (the interchange milestone), verified on 400 constructed live
  composable tile pairs over random finite models, alongside reindex
  functoriality and the agreement of diagram composition with function
  composition.

Libraries with teeth. A genuine monoid homomorphism validates the idempotence and
multiplication preservation tiles; a non-homomorphism breaks them and the checker
returns the witnessing environment. A graph homomorphism preserves edges and
length-2 paths (the latter exercising existential quantification); a
non-homomorphism breaks both, with witnesses.

Controlled reflection. Quotation that raises the level by exactly one, enforced by
a code-type invariant. A genuine finite proof-certificate checker (rules for
axioms, reflexivity, conjunction introduction and elimination, and tile
composition) that accepts valid certificates and rejects invalid ones. Partial
evaluation returning a value, a bottom on divergence, or an unsupported status. A
membrane checker that forbids exactly the same-level total representation-complete
truth interface.

The Program E boundary made executable. For a finite code set of size two, every
one of the sixteen candidate same-level evaluators is checked and none is
representation-complete: the diagonal predicate d(c) = not eval(c, c) is a row of
none. Sampling confirms the same for size three. Stratified escape is checked for
sizes two, three, and four: at the next level one can hold codes for every
predicate on the level below, and the diagonal cannot be formed because codes and
arguments then live in different sets. The interface the membrane forbids is
verified to be exactly the configuration the diagonal proves impossible.

Phase 1 result: 31 of 31 checks pass.

### 2.2 Phase 2: structural rewriting and coherence

The monoid signature is oriented as a rewriting system and its coherence is
computed:

- rules: alpha `m(m(x,y),z) => m(x,m(y,z))`, lam `m(e,x) => x`, rho `m(x,e) => x`;
- termination: the positive-coefficient monotone polynomial interpretation
  `I(m(a,b)) = 2 I(a) + I(b)`, checked to strictly decrease on every one of 1874
  reduction steps over random terms;
- confluence: two different redex-selection strategies produce identical normal
  forms on 500 random terms, consistent with Newman's lemma given termination and
  joinable critical pairs;
- critical pairs: a Knuth-Bendix style analyzer enumerates all seven critical
  pairs and verifies each is joinable;
- the pentagon: the alpha-with-alpha overlap on ((ab)c)d is exactly Mac Lane's
  pentagon. The analyzer finds it automatically. The explicit 3-cell is the pair
  of a two-step route and a three-step route sharing source ((ab)c)d and target
  a(b(cd)), and every step is checked to be a valid associator rewrite;
- unit coherence: the alpha/unit and unit/unit critical pairs are the unit
  coherence cells, all joinable;
- decision procedure: the normal form of any term is the right comb of its
  underlying atom word, so the rewriting decides the free-monoid word problem,
  cross-checked against an independent flatten oracle.

Phase 2 result: 9 of 9 checks pass. This is the first layer to exercise genuine
3-cell structure rather than degree-1 tiles.

### 2.3 Phase 2.5: coherence between structure and logic

This is the first place the structural and logical halves of Metasketch must
cohere through an explicit 3-cell. Transporting a predicate Q along a structural
diagram d, written reindex(d, Q), branches against a structural rewrite of d:

```
structural 2-cell:  reindex(d, Q)  --alpha/lam/rho on d-->  reindex(d', Q)
transport 2-cell:   reindex(d, Q)  --substitute-->          Q[d]
```

The coherence 3-cell fills the span. The tested statement is that transport
commutes with structural normalization:

```
nf_pred( reindex(d, Q) )  ==  nf_pred( reindex( nf_diagram(d), nf_pred(Q) ) ).
```

Verified two ways:

- syntactic: both routes reach one predicate normal form, over 400 random
  diagram-predicate pairs and over 221 filled single-redex critical branchings,
  including the pentagon lifted into a tile (a diagram whose image term is the
  four-fold left comb, so the pentagon appears inside the transported predicate);
- semantic: in several monoid models (additive Z modulo 4, 5, 3 and multiplicative
  Z modulo 6) the two routes have equal extension, over 173 squares.

Teeth. In a deliberately non-associative magma on three elements, where
`(0*0)*0 = 0` but `0*(0*0) = 2`, the two routes DIFFER. The witness found by the
suite is the predicate y = x. So the coherence cell is not a triviality of
notation: it is exactly the associativity axiom, and it is sound reasoning only in
a model of the theory. The same squares are confirmed to cohere in a genuine
monoid. A valid preservation tile is also confirmed to keep its transported
predicate stable when its diagram is structurally rewritten in a monoid model.

Phase 2.5 result: 8 of 8 checks pass.

This connects to the companion program document (the five-program design, Program
D and Program E): the coherence obstruction handled here and in Phase 2 is the
abelian, Squier-style obstruction that belongs on the structural side and is
distinct from the reflection obstruction handled by the Phase 1 diagonal. Both are
now executable and are kept separate, as that document argued they should be.

### 2.4 Engineering notes: two bugs found and fixed

Reported plainly, since the suite caught both and the green results are the
post-fix state.

1. In the stratified-escape check, a list was compared against a tuple, which is
   always false in Python, so point-surjectivity across the level gap wrongly read
   as failing. The mathematics was correct; the comparison was fixed to use a
   consistent type.
2. In the rewriting engine, the substitution routine re-resolved substituted
   values, so a critical-pair term that shared a variable name with a rule's
   pattern variable produced an infinite resolution loop and a RecursionError.
   Fixed by making rewriting substitution single-pass (simultaneous) and confining
   chain resolution to unification.

### 2.5 Reflection-cost profile, demonstrated

On the finite tested fragment:

| capability                              | sigma_X | basis in the kernel                                   |
|-----------------------------------------|---------|-------------------------------------------------------|
| well-formedness                         | <= 1    | checkable one level up on quoted syntax               |
| proof checking                          | <= 1    | certificate checker verifies level-k certificates at k+1 |
| contextual evaluation                   | <= 1    | partial evaluator returns value, bottom, or unsupported |
| model-relative satisfaction             | <= 1    | model supplied as data at the higher level            |
| same-level total complete truth         | >= 1    | diagonal shows same level impossible; stratification escapes |

These are demonstrated on finite instances, not proved in general. Turning the
lower bound into a general theorem for a named polygraphic fragment remains a
target (see Section 5).

---

## 3. Theorem and milestone status (v0.2 program)

| Target (descriptive)                                   | Status        | Where realized                          |
|--------------------------------------------------------|---------------|-----------------------------------------|
| Preservation-tile composition / interchange            | DONE (tested) | tiles.py, tests Phase 1                  |
| Reindex functoriality and diagram composition          | DONE (tested) | semantics.py, tests Phase 1             |
| Finite-model soundness of tiles                         | DONE (tested) | semantics.py, libraries.py             |
| Termination of the structural presentation             | DONE (tested) | coherence.py, tests Phase 2            |
| Confluence via joinable critical pairs                 | DONE (tested) | rewriting.py, tests Phase 2            |
| Proof coherence, explicit 3-cells (the pentagon)       | DONE (tested) | coherence.py, tests Phase 2            |
| Structure/logic coherence at the tile layer            | DONE (tested) | tile_coherence.py, tests Phase 2.5    |
| Free-monoid decision procedure                          | DONE (tested) | tests Phase 2                          |
| Reflection-cost lower bound (sigma_truth >= 1), finite | DONE (tested) | reflection.py, tests Phase 1          |
| Reflection-cost lower bound, general theorem           | OPEN          | Section 5; Girard-style target          |
| Focused proof search / normalization for tiles (T2)    | OPEN          | not started                             |
| Relative completeness of the tile calculus (T3)        | OPEN          | not started                             |
| Universal-evaluator bridge to point-surjectivity       | OPEN          | conceptual; companion Program E E1      |

---

## 4. Development sequence status

- Phase 1, structural and logical core plus reflection safeguards: DONE.
- Phase 2, coherence of the structural presentation (monoid): DONE.
- Phase 2.5, structure/logic coherence at the tile layer: DONE.
- Phase 2 for other signatures (graphs, relations): NOT STARTED.
- Phase 3, relational-database benchmark and larger examples: NOT STARTED.
- Phase 4 and 5 reflection machinery: partially realized (quotation, checker,
  partial evaluation, membrane, diagonal). The general minimal-stratification
  theorem is OPEN.

---

## 5. What is not yet done, and the revised immediate next step

Not yet done: coherence for signatures beyond the monoid; a general focused proof
procedure for the regular-logic tiles as opposed to the structural rewriting done
here; relative completeness of the tile calculus; the relational-database
benchmark; a visual renderer (diagrams remain abstract syntax); and the general
reflection-cost lower bound as a theorem rather than a finite demonstration.

Revised immediate next step. Two candidates, in order of value:

1. Extend the coherence analysis to a signature with a genuine
   structure-and-relation interaction, for example a preorder or a graph with a
   transitivity or composition rule, so that a critical branching mixes a
   structural rewrite with a relational transport. This generalizes Phase 2.5
   beyond the single-operation monoid and is the natural test of whether the
   coherence machinery scales to signatures where structure and logic interact
   nontrivially.

2. Attack the general reflection-cost lower bound. Formalize a polygraphic
   fragment with internal rewrite certificates and prove that at least one level
   shift is mandatory to avoid same-level point-surjectivity while preserving
   representation capability. The anchor is Girard's paradox, which shows that
   collapsing one universe level is already inconsistent; the target is its
   polygraphic analogue. This is the theorem that would upgrade the demonstrated
   sigma_truth >= 1 to a proof.

---

## 6. Delivered kernel manifest

```
metasketch0/
  syntax.py          sorts, terms, contexts, diagrams, regular predicates, reindex
  semantics.py       finite models, interpretation, extensions, tile validity
  tiles.py           preservation tiles and composition (interchange)
  libraries.py       monoid and graph seeds with homomorphism tiles
  reflection.py      levels, quote, certificate checker, partial eval, membrane, diagonal
  rewriting.py       first-order rewriting: match, unify, positions, normalize, critical pairs
  coherence.py       monoid rules, termination interpretation, the pentagon 3-cell
  tile_coherence.py  structure/logic coherence: transport versus structural rewriting
  tests.py           Phase 1 battery and the reflection-cost profile
  tests_phase2.py    Phase 2 battery (rewriting and coherence)
  tests_phase25.py   Phase 2.5 battery (structure/logic coherence)
demo.py              readable walkthrough
run_all_tests.py     runs Phases 1, 2, 2.5 together
README.md            usage and scope
```

Run `python run_all_tests.py` to reproduce all 48 checks.
