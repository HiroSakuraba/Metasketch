# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.4: corrected kernel, accurate status, and next theorem targets

**Status:** Research-design document and implementation report. Metasketch-0 is a
finite executable prototype. It is not yet a complete diagrammatic foundation,
a complete regular-logic calculus, a proof assistant, or a general theorem about
reflection.

**Supersedes:** v0.3. The v0.4 revision fixes a capture-avoidance bug, adds a
static validation layer, stores explicit rewrite and coherence witnesses, and
narrows claims whose prior wording exceeded the implementation.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

---

## 1. Purpose

Metasketch aims at a ZX-like diagram language for metamathematics. One visual
language should represent:

1. mathematical structures and structural maps;
2. predicates and statements about those structures;
3. proof steps and structure-preserving transformations; and
4. higher cells witnessing that different proof or rewrite routes agree.

The goal is not to make a multiplication operation and a theorem about
multiplication literally the same untyped object. The workable objective is a
**stratified higher-dimensional language** in which they are adjacent kinds of
cell and can interact compositionally.

The central primitive is a preservation tile:

```text
P |- d*Q
```

where `d : Gamma -> Delta` is a structural diagram, `P` is a predicate on the
source context, and `Q` is a predicate on the target context.

It has two readings:

- **Structural:** every source assignment satisfying `P` is mapped by `d` to a
target assignment satisfying `Q`.
- **Logical:** `P` entails the substitution, or reindexing, `d*Q`.

The long-range proposal connects this constructive calculus to Program E. Typed
quotation and evaluation can be added, but the system must retain enough
stratification, partiality, or representation limits to avoid untyped universal
self-reference.

---

## 2. What v0.4 implements

Metasketch-0 is a dependency-free Python kernel with 54 passing tests:

| Layer | Tests | What the tests establish |
|---|---:|---|
| Phase 1 | 35 | finite-model tiles, syntax hygiene, static validation, small reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting, critical pairs, stored confluence fillers |
| Phase 2.5 | 9 | stored structure/logic coherence cells and finite semantic checks |
| **Total** | **54** | executable regression suite passes |

The code is intentionally small. Its role is to expose false definitions early,
not to simulate a finished foundation.

### 2.1 Corrected syntax discipline

The original prototype used names for variables and assumed existential binders
would be fresh. That is unsafe. For example, with

```text
d : (x) -> (y),    y := x
Q(y) := exists x. R(y, x)
```

naive substitution produces

```text
exists x. R(x, x),
```

which captures the free `x` introduced by the diagram. The correct pullback is
alpha-equivalent to

```text
exists x_0. R(x, x_0).
```

v0.4 implements capture-avoiding substitution. A regression test uses a
2-element model with `R = {(0,1)}` and verifies that the syntactic pullback has
the same extension as the semantic preimage.

The kernel now also has an explicit static checker:

```text
validate_diagram(d, signature)
validate_predicate(P, signature, context)
validate_tile_syntax(P, d, Q, signature)
```

It checks operation arity, relation arity, sort agreement, diagram target
coverage, free variables, and unsafe binder shadowing. The raw constructors are
still lightweight for experimentation, so this is not yet a fully intrinsic type
system. The next parser should require checked syntax at the public boundary.

### 2.2 Directed rewriting with stored 3-cells

The structural monoid presentation is oriented as:

```text
alpha: m(m(x,y),z) -> m(x,m(y,z))
lam:   m(e,x)      -> x
rho:   m(x,e)      -> x
```

The kernel now stores:

```text
RewriteStep
RewriteTrace
CoherenceCell3
```

A `CoherenceCell3` contains two validated, directed rewrite traces with common
source and target. The kernel enumerates the seven nontrivial critical pairs of
this presentation and constructs a stored confluence filler for each one.

The alpha/alpha critical overlap has the familiar pentagon shape:

```text
((ab)c)d ->* a(b(cd))
```

by a two-step route and a three-step route. This is a **directed
rewrite-theoretic analogue** of the associator pentagon. It is not full Mac Lane
coherence, since the rules are not invertible natural associators and no monoidal
category of natural transformations has been constructed.

### 2.3 Explicit structure/logic coherence cells

For a structural rewrite `d -> d'` and target predicate `Q`, v0.4 stores a
`TileCoherenceCell3` with boundary:

```text
reindex(d, Q)          ->*  N
     |                        ^
     v                        |
reindex(d', Q)         ->*  N
```

The vertical edge is the structural update of the diagram under transport. The
two lower paths are concrete stored predicate-normalization traces. The filler
validates that both paths end in the same predicate normal form.

This is a finite implementation of the desired principle:

> Transporting a predicate through a structural presentation should cohere with
> rewriting that presentation.

The equality is not merely notation. In a selected non-associative magma,
`((0*0)*0) = 0` while `0*(0*0) = 2`. The transported predicate `y = e` then
separates the two routes. In selected monoids the routes agree, exactly because
associativity is valid there.

### 2.4 Controlled reflection with real level tags

The reflection layer keeps four capabilities distinct:

```text
quote  : code a lower-level object
check  : check a finite proof certificate
exec   : evaluate a code in a context, possibly partially
truth  : semantically decide every statement of a system
```

Quotation is level-raising. The finite stratified interface is now explicit:

```text
PredicateCode[k+1, Pred[k]] x Element[k] -> Bool.
```

A predicate code cannot be passed as an element of the level it describes. The
attempt triggers a type error. The earlier prototype used unequal set sizes as a
metaphor for this separation; v0.4 uses actual level-tagged objects instead.

The evaluator reports one of:

```text
value | resource_exhausted | unsupported
```

`resource_exhausted` replaces `bottom`. Exceeding a rewrite budget does not prove
divergence. A future semantics of partiality may use a genuine bottom element,
but the current bounded interpreter does not earn that claim.

---

## 3. What is proved, tested, or open

This distinction is mandatory for the project.

| Claim | Status | Exact meaning |
|---|---|---|
| Capture-avoiding substitution matches a semantic preimage | **Tested** | one explicit finite regression case plus ordinary test coverage |
| Static syntax checks reject selected malformed inputs | **Implemented and tested** | checker exists, but raw AST constructors remain public |
| Tile composition is semantically valid | **Tested** | 400 constructed finite-model cases, plus direct semantics |
| Reindexing is functorial in tested examples | **Tested** | finite semantic comparisons |
| Monoid rewriting terminates | **Paper proof available** | the polynomial interpretation decreases on every directed rule |
| Monoid rewriting is confluent | **Proof schema available** | finite critical-pair enumeration plus termination; formal proof not mechanized |
| Seven critical-pair fillers exist in the kernel | **Implemented and tested** | stored traces are replayed and checked |
| Phase 2.5 coherence cells exist for the monoid fragment | **Implemented and tested** | stored finite cells, selected models, generated examples |
| Full polygraphic homotopy basis | **Open** | no Squier-style theorem or proof assistant formalization yet |
| Finite same-level Boolean evaluator is incomplete | **Finite diagonal fact** | exhaustive for size 2, sampled regression checks for size 3 |
| General Tarski or Lawvere barrier for Metasketch | **Open** | requires a named syntax-to-semantics or categorical bridge |

### 3.1 Termination proof for the monoid fragment

For ground terms define:

```text
I(atom) = I(e) = 1
I(m(a,b)) = 2 I(a) + I(b).
```

Then:

```text
I(m(m(a,b),c)) - I(m(a,m(b,c))) = 2 I(a) > 0
I(m(e,x)) - I(x) = 2
I(m(x,e)) - I(x) = 1.
```

Every directed rewrite strictly lowers a positive integer. Therefore no infinite
rewrite chain exists. The implementation checks this behavior on generated
terms, but the displayed calculation is the actual mathematical argument.

### 3.2 Confluence claim and its limit

The implementation enumerates all nontrivial overlaps of the three rules and
joins each pair to a common normal form. With termination, the standard
critical-pair route gives a short confluence proof for this finite first-order
presentation. The code is evidence and a replayable witness generator, not a
machine-checked proof of the critical-pair theorem or Newman's lemma.

### 3.3 Reflection claim and its limit

For a finite set `C` and a Boolean table

```text
e : C x C -> {0,1},
```

the diagonal predicate

```text
d(c) = 1 - e(c,c)
```

cannot equal any row of `e`. This proves that a finite same-level table cannot
represent every Boolean predicate on its own code set.

This does **not** alone prove Tarski's undefinability theorem, Lawvere's
fixed-point theorem, or a general minimum-stratification theorem. Those results
need stronger language, semantic, or categorical premises. The finite result is
a useful design test, not the final Program E theorem.

---

## 4. Formal kernel

### 4.1 Structural layer

A signature has sorted operations and relations. A context is a finite ordered
list of distinct sorted variables. A diagram

```text
d : Gamma -> Delta
```

is a tuple assigning each variable of `Delta` a term over `Gamma`.

Composition is substitution:

```text
e : Delta -> Theta
d : Gamma -> Delta
------------------
e o d : Gamma -> Theta.
```

### 4.2 Logical layer

The first predicate fragment is regular logic:

```text
Top, equality, relation atoms, conjunction, existential quantification.
```

For a diagram `d : Gamma -> Delta` and predicate `Q` over `Delta`, reindexing
produces a predicate `d*Q` over `Gamma`. Substitution is capture-avoiding.

### 4.3 Preservation tiles

A tile is:

```text
P |- d*Q.
```

Two composable tiles

```text
P |- d*Q
Q |- e*R
```

produce

```text
P |- (e o d)*R.
```

The finite implementation validates this by interpreting diagrams as functions
between finite environments and predicates as subsets of finite context products.

### 4.4 Higher cells

The current hierarchy is deliberately modest:

```text
terms and diagrams       structural 1-cells
rewrite rules            directed structural 2-cells
rewrite traces           composites of 2-cells
CoherenceCell3           filler between parallel traces
TileCoherenceCell3       filler linking structural and logical routes
```

This is enough to make the first coherence obligations executable. It is not yet
a complete formal definition of an omega-category or a polygraphic hyperdoctrine.

---

## 5. Relation to Program E

Program E studies the cost of reflective self-description in a diagrammatic
foundation. Metasketch is the constructive branch of that program.

The safe architecture is:

```text
one visual language
+ typed cell dimensions
+ explicit quotation membranes
+ level-raising code interfaces
+ partial or restricted evaluators
```

rather than one untyped object that is simultaneously structure, statement,
proof, and code.

The relevant future theorem is not “homoiconic diagrams are impossible.” It is:

> For a named reflective polygraphic fragment, determine the least level shift,
> partiality, or representation restriction needed to encode diagrams, rewrites,
> and proof certificates while retaining soundness.

The finite diagonal routine confirms why the strongest same-level Boolean
interface needs scrutiny. It does not yet supply the universal-evaluator bridge
to weak point-surjectivity required for a Lawvere-style theorem.

---

## 6. Immediate next steps

### Priority 1: close the raw-AST loophole

Make validated construction the default public API.

1. Give each parser-produced term and predicate a declared signature and ambient
context.
2. Make unchecked constructors private or visibly experimental.
3. Add model validation: carriers, operation arities, operation codomains, and
relation tuple arities.
4. Extend hygiene tests to nested quantifiers and substitutions with multiple
simultaneous replacements.

This is the most important engineering step because membrane safety ultimately
depends on the type discipline being enforced, not merely available.

### Priority 2: generalize Phase 2.5 beyond monoids

Use a graph or preorder signature with a relation rule that interacts nontrivially
with structural transport. The task is to enumerate mixed branchings among:

```text
structural rewrites,
reindexing rules,
predicate-normalization rules.
```

The result should be a general schema for constructing `TileCoherenceCell3`
objects, not a monoid-specific normalization trick.

### Priority 3: formalize the proof schema

Write a concise theorem note for the monoid fragment:

1. strict polynomial termination;
2. complete enumeration of the seven critical pairs;
3. joinability witnesses;
4. confluence by the standard terminating critical-pair criterion;
5. normal forms as right combs of unit-free atom words.

This could later be ported to a proof assistant, but the first useful milestone
is a conventional mathematical proof that exactly matches the code.

### Priority 4: Program E bridge

Specify a restricted reflective calculus with:

```text
code object A,
truth object Omega,
typed quote and evaluator interfaces,
a declared class of definable predicates.
```

Then determine whether a proposed universal evaluator gives a non-tautological
bridge to weak point-surjectivity. A positive bridge would activate the Lawvere
barrier. A failed bridge should identify whether the calculus escapes through
stratification, partiality, weakened truth, or incomplete representation.

---

## 7. Repository manifest

```text
metasketch0/
  syntax.py          raw syntax, hygiene, and static validation
  semantics.py       finite-model interpretation and tile validity
  tiles.py           preservation tiles and composition
  libraries.py       monoid and graph examples
  reflection.py      quotation, certificates, bounded evaluation, membrane, diagonal
  rewriting.py       rewriting rules, stored steps, and stored traces
  coherence.py       monoid termination argument and structural 3-cells
  tile_coherence.py  explicit structure/logic 3-cells
  tests.py           Phase 1 tests
  tests_phase2.py    Phase 2 tests
  tests_phase25.py   Phase 2.5 tests
run_all_tests.py     full 54-check runner
README.md            concise use and scope statement
```

---

## 8. References and boundaries

1. F. W. Lawvere, *Diagonal Arguments and Cartesian Closed Categories* (1969).
   The later Program E barrier requires an actual weak point-surjectivity bridge.
2. J. W. Gray and A. S. Kock, graphical and categorical treatments of regular
   logic. Use as a baseline for the logical layer, not as a novelty claim.
3. C. Squier, *Word Problems and a Homological Finiteness Condition for Monoids*
   (1987). Relevant to the future homotopy-basis and coherence program.
4. S. Mac Lane, *Categories for the Working Mathematician*. The current pentagon
   is a directed rewriting analogue, not a full implementation of monoidal
   coherence.
5. J.-Y. Girard, work on Type-in-Type and universe inconsistency. Relevant to
   future minimum-stratification questions, not established by this kernel.

Before publication, replace this short boundary list with exact bibliographic
records and section-level citations for every theorem used in a formal claim.
