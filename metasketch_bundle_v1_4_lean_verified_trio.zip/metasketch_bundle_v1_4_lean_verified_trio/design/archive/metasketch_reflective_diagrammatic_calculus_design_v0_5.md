# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.5: checked finite kernel and Phase 3 query transport

**Status:** Research-design document and implementation report. Metasketch-0 is
a finite executable prototype. It is not yet a complete diagrammatic foundation,
a full regular-logic calculus, a proof assistant, or a general theorem about
reflection.

**Supersedes:** v0.4. v0.5 completes the immediate v0.4.1 hardening pass and
implements Phase 3, the first nontrivial structure-and-logic result beyond the
monoid fragment.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

---

## 1. Purpose

Metasketch seeks a ZX-like visual language for metamathematics. The intended
language should represent, in one compositional setting:

1. mathematical structures and structural maps;
2. predicates and statements about those structures;
3. proofs and structure-preserving transformations; and
4. higher cells witnessing that alternative proof or rewrite routes agree.

The design does not collapse a structural operation and a proposition about that
operation into one untyped object. It instead gives them adjacent typed roles in
a higher-dimensional calculus.

The core judgment is a preservation tile:

```text
P |- d*Q
```

where `d : Gamma -> Delta` is a structural diagram, `P` is a source predicate,
and `Q` is a target predicate. It reads both structurally and logically:

- Every input satisfying `P` is sent by `d` to an output satisfying `Q`.
- `P` entails the pullback, or reindexing, `d*Q`.

The long-range Program E connection remains unchanged. Quotation, checking, and
restricted evaluation are useful, but semantic truth for a fully expressive
same-level calculus must remain stratified, partial, or incomplete.

---

## 2. What v0.5 changes

### 2.1 Checked construction and finite-model validation

v0.4 added static validators. v0.5 makes them usable as public wrappers:

```text
CheckedPredicate
CheckedDiagram
CheckedTile
```

These records validate their syntax against a declared signature and context at
construction time. Raw abstract syntax remains available for experiments, but
Phase 3 uses the checked route for its core objects.

The finite semantics layer now also validates finite models exhaustively against
a signature:

- every declared carrier exists and has distinct elements;
- every declared operation is total on the finite input product and returns in
  the declared output carrier; and
- every declared relation tuple has the correct arity and lies in the indicated
  carriers.

### 2.2 Nested hygiene under simultaneous substitution

The v0.4 capture fix covered one existential binder. v0.5 tests the harder
case: a diagram simultaneously swaps two free variables while the target
predicate binds variables with those same displayed names. Both binders are
alpha-renamed, and the result is checked against the direct semantic preimage in
a finite graph model.

### 2.3 Phase 3: conjunctive-query transport

A finite directed pattern graph now compiles to an existential-conjunctive
regular-logic query. A concrete pattern match is a witness for the query.
Graph homomorphisms transport both the query and its witnesses.

The implementation includes five query patterns:

```text
edge, length-two path, fork, diamond, directed triangle
```

and checks, in a selected finite graph, that the extension of each compiled query
matches exhaustive enumeration of its graph-homomorphism witnesses.

### 2.4 Explicit query-transport coherence cells

For composable graph homomorphisms

\[
G\xrightarrow{h}H\xrightarrow{k}K
\]

and a pattern witness \(m:P\to G\), the kernel stores

```text
QueryTransportCoherenceCell3
```

for the equality

\[
(k\circ h)\circ m = k\circ(h\circ m).
\]

This is Phase 3's first higher cell whose boundaries are actual existential
witnesses rather than only normalized monoid terms.

---

## 3. Current executable scope

| Layer | Tests | What the tests establish |
|---|---:|---|
| Phase 1 | 35 | finite-model tiles, syntax hygiene, small reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting, critical pairs, stored confluence fillers |
| Phase 2.5 | 9 | monoid structure/logic coherence cells and finite semantic checks |
| Phase 3 | 14 | graph-pattern compilation, finite witness transport, query tiles, and witness-level coherence |
| **Total** | **68** | executable regression suite passes |

The suite does not replace proof. It keeps the definitions, examples, and
claimed scope falsifiable while the conventional metatheory is written.

---

## 4. Phase 3 formal kernel

### 4.1 Pattern compilation

Let a finite directed pattern graph be

\[
P=(V_P,E_P).
\]

Choose visible vertices \(\bar x\) and hidden witness vertices \(\bar z\).
Metasketch compiles the pattern into

\[
Q_P(\bar x)
=
\exists \bar z\;\bigwedge_{(u,v)\in E_P} E(u,v).
\]

The compiled predicate is hygienic by construction: hidden pattern vertices are
assigned fresh bound variables, and any later reindexing still uses the
capture-avoiding substitution routine.

### 4.2 Match-query correspondence

For finite graphs, a pattern match

\[
m:P\to G
\]

is exactly an existential witness assignment for \(Q_P\). The implementation
exhaustively checks this correspondence for the five small patterns listed
above.

This is a standard fact about conjunctive queries. The Metasketch-specific point
is that the same data object can be connected to a compiled predicate, a finite
semantic extension, a preservation tile, and a higher transport cell.

### 4.3 Query preservation tile

A graph homomorphism \(h:G\to H\) induces a structural diagram on the visible
query variables. For each compiled pattern query the desired tile is

\[
Q_P^G \;\vdash\; d_h^*(Q_P^H).
\]

The Phase 3 diamond example validates this tile in a finite graph model, then
composes it through \(G\to H\to K\). A non-edge-preserving map fails the tile
and yields the visible endpoint assignment witnessing the failure.

### 4.4 Witness-level 3-cell

For a match \(m:P\to G\), the stored coherence cell compares the two routes:

\[
m\xrightarrow{h\circ -}h\circ m\xrightarrow{k\circ -}k\circ(h\circ m),
\]

and

\[
m\xrightarrow{(k\circ h)\circ -}(k\circ h)\circ m.
\]

The `QueryTransportCoherenceCell3` validates the composite graph map, the two
transported witnesses, and equality of their labelled maps. The current
reference instance deliberately identifies two hidden diamond witnesses in the
target graph. This confirms that the kernel uses homomorphisms, not accidental
injectivity.

A standalone theorem-note skeleton is included as:

```text
design/metasketch_phase3_conjunctive_query_transport_note_v0_1.md
```

---

## 5. What is proved, tested, or open

| Claim | Status | Exact meaning |
|---|---|---|
| Capture-avoiding substitution matches semantic preimage | **Tested** | one single-binder and one nested simultaneous-substitution regression case, plus broader tests |
| Checked syntax and finite models reject selected malformed inputs | **Implemented and tested** | public wrappers exist; raw AST construction remains available for experimentation |
| Tile composition is semantically valid | **Tested** | constructed finite-model cases plus direct finite semantics |
| Monoid rewriting terminates | **Paper proof available** | polynomial interpretation strictly decreases every directed rule |
| Monoid rewriting is confluent | **Proof schema available** | finite critical-pair enumeration plus termination; not proof-assistant formalized |
| Monoid and tile coherence cells | **Implemented and tested** | finite stored traces and selected finite models |
| Pattern-query compilation equals match enumeration | **Tested** | five patterns in a selected finite graph |
| Graph homomorphisms preserve compiled diamond queries | **Implemented and tested** | selected finite graph chain with a non-homomorphism counterexample |
| Direct and sequential witness transport agree | **Implemented and tested** | stored `QueryTransportCoherenceCell3` on a selected chain |
| General relational query-transport theorem | **Open as a written theorem** | standard proof exists, but Metasketch has not yet stated it for a general signature class |
| Focused proof search or relative completeness | **Open** | no general proof procedure yet |
| General Program E reflection barrier | **Open** | finite diagonal evidence remains a design test, not a Lawvere or Tarski theorem |

---

## 6. Controlled reflection

The reflection layer continues to distinguish:

```text
quote  : code lower-level syntax
check  : verify a finite proof certificate
exec   : evaluate code with bounded resources
truth  : decide semantic truth for every sentence at a level
```

The executable interface uses explicit cross-level predicate codes:

```text
PredicateCode[k+1, Pred[k]] x Element[k] -> Bool.
```

The finite diagonal routine shows that a same-level finite Boolean evaluator
cannot represent every predicate of its own code set. This is not a general proof
of Tarski's theorem, Lawvere's theorem, or a minimum-stratification theorem.

---

## 7. Files added or changed in v0.5

```text
metasketch0/
  checked.py              checked public wrappers
  queries.py              finite graph patterns, query compilation, matches, homomorphisms
  query_transport.py      explicit witness-level query transport 3-cells
  tests_phase3.py         Phase 3 regression suite
  semantics.py            finite-model signature validation
  syntax.py               hygienic first-order syntax and static checks
  ...                     Phase 1, 2, and 2.5 modules retained

design/
  metasketch_reflective_diagrammatic_calculus_design_v0_5.md
  metasketch_phase3_conjunctive_query_transport_note_v0_1.md
```

---

## 8. Recommended next step

Do not broaden immediately to arbitrary first-order logic or Program E's
universal-evaluator bridge. The best next result is a **finite relational
transport schema**.

1. Generalize graph patterns to finite relational signatures of arity at most
   two, then arity \(n\).
2. Make relation-preservation data explicit in a structural map certificate.
3. Generate and store mixed coherence cells for structural map composition,
   witness transport, and reindexing.
4. State and prove a relative soundness theorem for existential-conjunctive
   Metasketch proof objects in that finite fragment.
5. Only after the witness language stabilizes, build the visual renderer for
   witness regions, preservation tiles, and higher transport cells.

This path advances the original goal directly: one diagrammatic system in which
structures, statements, witnesses, and proof coherence are visibly related, but
not conflated into an untyped universal evaluator.
