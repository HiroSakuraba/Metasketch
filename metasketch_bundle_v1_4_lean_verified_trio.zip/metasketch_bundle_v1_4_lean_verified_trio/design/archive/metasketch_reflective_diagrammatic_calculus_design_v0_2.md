# Metasketch
## A stratified diagrammatic calculus for mathematical structures, statements, proofs, and controlled self-reference

**Status:** Research-design document. This proposes a staged formal language and theorem program. It is not a claim that the calculus is complete, consistent, or capable of representing all mathematics.

**Companion program:** Program E — *Reflective Diagrammatic Stratification*.

**What v0.2 changes.** This revision makes the reflection boundary explicit rather than implicit. It adds: (i) a **reflection-cost profile** that distinguishes proof checking from semantic truth; (ii) a typed family of quotation, checking, evaluation, and satisfaction interfaces; (iii) nested **quotation membranes** whose geometry enforces level discipline; and (iv) partial-evaluation semantics in which divergent rewriting returns \(\bot\), never an unearned Boolean truth value.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026  
**Version:** v0.2

---

## Executive summary

The objective is a ZX-like visual calculus for metamathematics in which one coherent diagrammatic language can express:

1. **mathematical structures** — operations, relations, presentations, and models;
2. **maps between structures** — homomorphisms, substitutions, and interpretations;
3. **statements about structures** — equations, relations, conjunctions, and existential claims;
4. **proofs of statements** — rewrites, entailment tiles, and witness constructions; and
5. **proofs about proofs** — coherence cells showing that alternative proof paths agree.

The core design choice is deliberately restrained:

> A structure, a statement, a proof, and a proof-coherence witness are not declared to be one untyped object. They are represented in one graphical language as **different typed cell dimensions**.

This preserves the attractive part of homoiconicity — one compositional visual medium — without erasing the distinctions needed for soundness, semantics, and controlled self-reference.

The proposed working name is **Metasketch**. Its initial mathematical base is:

\[
\boxed{
\text{regular sketches}
\; + \;
\text{graphical regular logic}
\; + \;
\text{polygraphic higher-dimensional rewriting}
}
\]

The key primitive is a **preservation tile**. Given a structural map

\[
f:A\to B,
\]

and predicates \(P\) on \(A\) and \(Q\) on \(B\), a tile records an entailment

\[
P \;\vdash\; f^{\!*}Q.
\]

It has two readings at once:

- **Structural reading:** every instance of \(P\) is sent by \(f\) to an instance of \(Q\).
- **Logical reading:** \(P\) entails the pullback of \(Q\) along \(f\).

This is the exact sense in which one rewrite-like object can express both preservation of structure and an inference about structure.

Metasketch is designed to connect directly to Program E. Reflection is not built into the base calculus. It is added only through a **typed level tower**:

\[
\mathsf{Diag}_0
\xrightarrow{\mathsf{quote}_0}
\mathsf{Code}_1,
\qquad
\mathsf{Diag}_1
\xrightarrow{\mathsf{quote}_1}
\mathsf{Code}_2,
\quad \ldots
\]

A level can reason about diagrams from the level below. The system does not initially assume that a level can totally and completely encode all predicates about itself. That is precisely the boundary Program E investigates.

---

# 1. The design problem

## 1.1 The desired capability

A conventional formal system typically separates four media:

| Role | Conventional representation |
|---|---|
| Structure | algebraic signatures, categories, graphs, models |
| Statement | formulas or sequents |
| Proof | derivation trees or proof terms |
| Metaproof | external mathematics about proofs |

This separation is useful, but it makes structural mathematics feel linguistically fragmented. A monoid, a homomorphism of monoids, a theorem about a monoid, and a proof that a map preserves multiplication are usually displayed in four different notations.

The target is a common *diagrammatic* medium in which these activities can compose. The goal is not to abolish their differences. The goal is to make the differences visible as typed geometry rather than hidden in unrelated notation.

## 1.2 What “ZX-like” should mean here

ZX-calculus succeeds because it is not merely a drawing convention. It has:

- a finite graphical vocabulary;
- explicit composition rules;
- rewrite rules with semantic meaning;
- normal forms or completeness theorems on important fragments;
- machine-checkable rewriting.

A metamathematical analogue should aim for the same properties. It should **not** merely attach labels such as “proof” or “theorem” to ordinary category-theory diagrams.

A usable Metasketch calculus needs:

1. a small, typed graphical syntax;
2. compositional semantics for structures and statements;
3. local rewrite rules for proofs;
4. higher cells for proof coherence;
5. a restricted but nontrivial logic fragment with soundness;
6. a route to automated normalization or proof search;
7. a controlled quotation interface for metamathematics.

## 1.3 The central correction from Program E

The tempting slogan is:

> “A diagram should literally be both the structure and the theorem about the structure.”

Taken literally and without typing, this is almost certainly the wrong target. A multiplication operation and the associativity law about multiplication live at different logical and categorical levels. Treating them as indistinguishable destroys the very relation that says the law holds of the operation.

The corrected slogan is:

\[
\boxed{
\text{One diagram language; typed levels for structure, statement, proof, and reflection.}
}
\]

This retains the aesthetic and practical ambition while keeping the Program E safeguards intact.

---

# 2. The proposal in one picture

Metasketch uses one graphical alphabet, but every object has **two independent coordinates**:

1. **cell dimension** says what role it plays in a proof or presentation; and
2. **reflection level** says which diagrams it may describe.

Keeping these coordinates separate is essential. A 2-cell may be a proof tile about a level-0 structure; a level-2 code may describe a level-1 proof tile. Neither coordinate replaces the other.

\[
\begin{array}{ccl}
\text{Cell dimension 0/1} &:& \text{objects, wires, operations, and structural maps}\\
\text{Cell dimension 2} &:& \text{equations, entailments, and proof tiles}\\
\text{Cell dimension 3+} &:& \text{coherences between proof paths}\\[4pt]
\text{Reflection level }0 &:& \text{the base calculus }\mathcal M_0\\
\text{Reflection level }k+1 &:& \text{typed codes and claims about selected }\mathcal M_k\text{ objects.}
\end{array}
\]

## 2.1 Visual vocabulary

| Visual feature | Intended meaning |
|---|---|
| Solid wires | typed variables, objects, or data carriers |
| Solid boxes | operations, functions, constructors, or structural maps |
| Relation regions / enclosures | predicates in a context |
| Dashed tiles between diagrams | entailments, equations, or proof steps |
| Movie cells / labeled homotopies | coherence between proof paths |
| **Rigid quotation membrane** | a sealed code for a diagram at the next reflection level |
| **Code port** | the only legal connection across a quotation membrane |
| Level label and nesting depth | visible proof that a diagram is being discussed from a higher level |

Color may support readability, but it is never the type system. The level is enforced by **nested topology**: a quotation membrane carries a visible level label and physically encloses the lower-level diagram it quotes.

## 2.2 Membrane rules

A quotation membrane is not decorative brackets. It is a typed boundary with the following rules.

1. A level-\(k\) structural wire cannot cross into a level-\(k+1\) region as an ordinary wire.
2. Quoting a diagram creates a code token only through a designated code port:

   \[
   \mathsf{quote}_k:\mathsf{Diag}(\mathcal M_k)\to\mathsf{Code}_{k+1}.
   \]

3. The outer region may inspect the code through a declared checker, evaluator, or satisfaction interface. It cannot directly splice the quoted diagram into an outer structural composition.
4. Rendering is a controlled *view* of the enclosed lower-level syntax, not an untyped structural rewrite. A quoted diagram does not become a same-level raw diagram merely because it is displayed.
5. Each nested quotation strictly raises the level:

   \[
   k<k+1<k+2<\cdots.
   \]

6. A type checker rejects an evaluator or truth tile whose source and target claim unrestricted same-level semantic evaluation.

These rules make illicit self-evaluation visually impossible rather than merely discouraged in prose.

## 2.3 The one-sentence visual rule

\[
\boxed{
\text{A diagram may be quoted across a membrane, but only a typed higher-level interface may inspect the code.}
}

# 3. Mathematical spine

## 3.1 Base layer: a sketch or polygraphic presentation

Start with a finite presentation \(\mathcal S\) for the mathematical structure being studied.

For the first implementation, \(\mathcal S\) should be a **regular sketch** or a finite-limit/regular presentation. It supplies:

- sorts or object types;
- operations with typed inputs and outputs;
- relation symbols;
- equations and commutative diagrams;
- specified finite-limit or regular constraints.

A polygraphic presentation then supplies rewriting dimensions:

\[
\Sigma_0 \;\text{(objects)},
\quad
\Sigma_1 \;\text{(arrows / string diagrams)},
\quad
\Sigma_2 \;\text{(rewrites)},
\quad
\Sigma_3 \;\text{(coherences)}, \ldots
\]

This is the natural home for the “rewrites are higher morphisms” aspect of the proposal.

For the first regular-logic core, parallel composition is cartesian product \(\times\), so copying and discarding are available. A later linear or process-theoretic extension may replace \(\times\) with a non-cartesian tensor \(\otimes\), but it should not be mixed into the first soundness theorem.

## 3.2 Contexts and structural diagrams

A **context** is a list of typed boundary variables:

\[
\Gamma = (x_1:A_1,\ldots,x_n:A_n).
\]

A structural diagram

\[
d:\Gamma\to\Delta
\]

is a string diagram made from the declared operations and structural constructors. It can be read as a term tuple, process, substitution, or morphism.

Composition is ordinary wiring composition:

\[
\Gamma \xrightarrow{d} \Delta \xrightarrow{e} \Theta
\qquad\Rightarrow\qquad
 e\circ d:\Gamma\to\Theta.
\]

Parallel composition is juxtaposition.

## 3.3 Predicate layer: regular logic as diagrammatic regions

For each context \(\Gamma\), let

\[
\mathrm{Pred}(\Gamma)
\]

be a poset of predicates in that context. Initially this is the regular-logic fragment:

\[
\top,
\qquad
=,
\qquad
\wedge,
\qquad
\exists.
\]

This fragment is deliberately chosen because it is rich enough to express:

- equations between terms;
- relations and relational composition;
- existence of witnesses;
- images and substitutions;
- many homomorphism-preserved properties.

It is also close to established graphical regular logic.

A predicate is drawn as a labeled region or boundary decoration over a context diagram. For example:

\[
P(x,y)
\]

is a region enclosing the wires for \(x\) and \(y\). Conjunction is region intersection or stacking. Existential quantification is represented by hiding a wire or applying a designated witness/elimination construction.

## 3.4 Reindexing and transport

A structural diagram \(d:\Gamma\to\Delta\) pulls predicates on \(\Delta\) back to predicates on \(\Gamma\):

\[
d^*:\mathrm{Pred}(\Delta)\to\mathrm{Pred}(\Gamma).
\]

This is substitution in logical form. If \(Q\) is a statement about outputs in \(\Delta\), then \(d^*Q\) is the statement about inputs in \(\Gamma\) obtained by feeding those inputs through \(d\).

For appropriate context projections, existential quantification supplies a left adjoint:

\[
\exists_\pi \dashv \pi^*.
\]

The first calculus need not expose this categorical language to the user. Internally, however, it is the mechanism that makes witness introduction and elimination compose correctly.

## 3.5 The preservation tile

The central primitive is a typed square or tile:

\[
\begin{array}{c}
P \\
\Downarrow\; d \\
Q
\end{array}
\qquad\text{meaning}\qquad
P\vdash d^*Q.
\]

More explicitly, for a map \(d:\Gamma\to\Delta\), a preservation tile is a proof of

\[
P\;\Rightarrow\;d^*Q.
\]

The tile has two non-competing interpretations.

| Interpretation | Reading |
|---|---|
| Structural | Any input satisfying \(P\) is mapped by \(d\) to an output satisfying \(Q\). |
| Logical | From premise \(P\), infer the substituted conclusion \(d^*Q\). |

This is the calculus’s key unification. It does not claim that homomorphisms *are* proofs. Instead, homomorphisms and proofs are linked by a compositional relation.

## 3.6 Interchange law

Suppose there are preservation tiles

\[
P\vdash d^*Q
\qquad\text{and}\qquad
Q\vdash e^*R.
\]

Then composition gives a preservation tile

\[
P\vdash (e\circ d)^*R.
\]

Graphically: stack two preservation squares, then contract the shared middle boundary.

This is the first central theorem target because it says that **composition of structure maps commutes with transport and composition of proofs**.

---

# 4. A precise categorical package

The informal description above can be formalized as a **polygraphic regular hyperdoctrine**.

This is a working term, not a claim that the term is standard.

A Metasketch instance contains:

1. a cartesian category \(\mathsf{Ctx}\) of contexts and structural diagrams for the initial regular-logic core;
2. a polygraphic presentation of \(\mathsf{Ctx}\), so equalities and transformations have explicit generators and higher cells;
3. a contravariant predicate assignment

   \[
   \mathsf{Pred}:\mathsf{Ctx}^{\mathrm{op}}\to\mathbf{Pos};
   \]

4. reindexing maps \(d^*\) for structural diagrams;
5. existential quantification along declared projections;
6. proof tiles representing order relations

   \[
   P\le d^*Q;
   \]

7. higher coherence cells representing equality of proof composites; and
8. later, a typed quotation tower for controlled reflection.

The likely categorical ambient objects are:

- a **regular category** or regular hyperdoctrine for the initial logical fragment;
- a **double category** or **equipment** when preservation squares become primary objects;
- a **2-category or bicategory** when proof transformation and coherence must be nontrivial;
- a **polygraph** when the presentation and algorithmic rewriting are primary.

The design should not prematurely choose one formalism as universal. The first paper should select the smallest one that supports the required theorem.

---

# 5. Worked seed example: monoids and homomorphisms

## 5.1 Structure vocabulary

Use one sort \(M\), multiplication and unit in a cartesian context:

\[
\mu:M\times M\to M,
\qquad
\eta:1\to M.
\]

A monoid presentation includes rewrite cells for associativity and unit laws:

\[
\mu\circ(\mu\times 1)
\;\Rightarrow\;
\mu\circ(1\times\mu),
\]

\[
\mu\circ\langle\eta\circ!,1\rangle
\;\Rightarrow\;1,
\qquad
\mu\circ\langle 1,\eta\circ!\rangle
\;\Rightarrow\;1.
\]

At Level 0, these are structural relations in the presentation.

## 5.2 A homomorphism as a structural diagram plus a preservation tile

Let \(h:M\to N\) be a candidate map between two monoid objects. The multiplication-preservation condition is the equation

\[
h\circ\mu_M
=
\mu_N\circ(h\times h).
\]

In Metasketch it is a tile between two parallel structural diagrams:

\[
\begin{array}{ccc}
M\times M & \xrightarrow{\;h\times h\;} & N\times N\\
\bigg\downarrow\scriptstyle{\mu_M} & & \bigg\downarrow\scriptstyle{\mu_N}\\
M & \xrightarrow{\;h\;} & N
\end{array}
\]

The implementation should render this as one preservation tile over a commuting square, rather than as unrelated equation and proof notation.

Read structurally, the tile certifies that \(h\) is multiplication-preserving. Read logically in context \(x:M,y:M\), it certifies:

\[
h(\mu_M(x,y))
=
\mu_N(h(x),h(y)).
\]

The unit-preservation tile is analogous.

## 5.3 A statement about a structure

Let \(P(x)\) be the predicate “\(x\) is idempotent,” represented in context \(x:M\) by

\[
P(x)\;:\Longleftrightarrow\;\mu(x,x)=x.
\]

A homomorphism preservation proof shows:

\[
P(x)
\;\vdash\;
h(x)\cdot h(x)=h(x).
\]

Equivalently,

\[
P\vdash h^*Q,
\]

where \(Q(y)\) says \(y\cdot y=y\). This is a genuine preservation tile: a structure map and an inference appear in one compositional cell.

## 5.4 What the example does and does not demonstrate

It demonstrates that the calculus can represent structures, maps, predicates, and preservation proofs with one geometric grammar.

It does **not** yet demonstrate a novel theorem. The novelty must come from a reusable calculus with soundness, normalization, coherence, and reflection properties—not from drawing monoid diagrams differently.

---

# 6. The initial logic boundary

## 6.1 Begin with regular logic

The first release should support only:

\[
\top,
\quad =,
\quad \wedge,
\quad \exists.
\]

Regular logic is the correct starting point because it matches finite diagrams, relations, images, and witnesses. It also avoids the immediate difficulties of unrestricted negation, implication, and universal quantification.

In user-facing language:

| Logical construct | Diagrammatic role |
|---|---|
| Equality | A rewrite/equation between parallel diagrams |
| Conjunction | Join two predicate regions in the same context |
| Existential statement | Hide a witness wire after constructing it |
| Substitution | Plug a structure diagram into a predicate region |

## 6.2 Add later, not now

The following should be explicit later milestones:

- universal quantification;
- implication and negation;
- modal or temporal operators;
- higher-order predicates;
- dependent types;
- unbounded proof reflection.

Each creates variance, polarity, or self-reference issues that do not belong in the first soundness theorem.

---

# 7. Program E integration: controlled reflection

Metasketch does not treat reflection as a binary feature. It distinguishes four capabilities that are often conflated:

1. **quotation** — turning a lower-level diagram into data;
2. **proof checking** — verifying that supplied finite syntax is a valid derivation;
3. **evaluation or satisfaction** — running a coded term or testing a coded formula in a supplied environment or model; and
4. **global semantic truth** — deciding whether every coded sentence of a level is true.

The first three can be useful in a stratified calculus. The fourth is where Tarski- and Lawvere-style barriers become relevant under additional representation-completeness assumptions.

## 7.1 Base calculus versus reflective tower

The Metasketch base calculus is **not** self-referential merely because it has diagrams and proof tiles. It becomes reflective only when diagrams themselves can be quoted and inspected by a higher level.

\[
\begin{array}{lll}
\mathcal M_0 &:& \text{structures, maps, predicates, and proofs}\\
\mathcal M_1 &:& \text{codes and claims about selected }\mathcal M_0\text{ diagrams}\\
\mathcal M_2 &:& \text{codes and claims about selected }\mathcal M_1\text{ proof objects.}
\end{array}
\]

Quotation is level-raising:

\[
\mathsf{quote}_k:
\mathsf{Diag}(\mathcal M_k)
\to
\mathsf{Code}_{k+1}(\mathsf{Diag}_k).
\]

The notation \(\uparrow_k X\) means “a level-\(k\) object \(X\), imported as data into level \(k+1\).”

## 7.2 Reflection API: quote, check, evaluate, satisfy

The first reflective interface should have four different operations, not one vague evaluator.

### Quotation

\[
\mathsf{quote}_k:
\mathsf{Diag}_k
\to
\mathsf{Code}_{k+1}(\mathsf{Diag}_k).
\]

Quotation packages finite syntax. It does not assert that the quoted diagram is correct, true, executable, or universal.

### Proof checking

\[
\mathsf{check}_{k+1}:
\mathsf{Code}_{k+1}(\mathsf{Proof}_k(\Gamma\vdash\varphi))
\to
\mathsf{Bool}_{k+1}.
\]

A checker verifies an explicit finite certificate against declared inference rules. It may be total for finite certificates. It does **not** decide whether an arbitrary formula is true or whether a proof exists.

### Term evaluation

A coded term generally needs an environment. The evaluator is therefore contextual and level-indexed:

\[
\mathsf{eval}_{k+1\Downarrow k}:
\mathsf{Code}_{k+1}(\mathsf{Term}_k(\Gamma,A))
\otimes
\uparrow_k\mathsf{Env}_k(\Gamma)
\rightharpoonup
\uparrow_k\mathsf{Val}_k(A).
\]

Equivalently, the implementation may make partiality explicit by returning a lifted result:

\[
\widehat{\mathsf{eval}}_{k+1\Downarrow k}:
\mathsf{Code}_{k+1}(\mathsf{Term}_k(\Gamma,A))
\otimes
\uparrow_k\mathsf{Env}_k(\Gamma)
\to
\mathsf{Lift}(\uparrow_k\mathsf{Val}_k(A)),
\qquad
\mathsf{Lift}(X)=X\cup\{\bot\}.
\]

### Satisfaction in a supplied model

\[
\mathsf{sat}_{k+1\Downarrow k}:
\mathsf{Code}_{k+1}(\mathsf{Form}_k(\Gamma))
\otimes
\uparrow_k\mathsf{Model}_k(\Gamma)
\rightharpoonup
\mathsf{Lift}(\Omega_{k+1}).
\]

This evaluates a formula in a specified model or context. It is not a global truth oracle.

## 7.3 The explicit prohibition

The initial language contains no operation of the form

\[
\mathsf{True}_k:
\mathsf{Code}_{k}(\mathsf{Sent}_k)
\to
\Omega_k
\]

that is simultaneously:

- total,
- semantically correct for every level-\(k\) sentence,
- internally available at level \(k\), and
- representation-complete for predicates about its own code object.

This prohibition does not weaken the practical objective. It separates useful proof checking and model-relative satisfaction from the far stronger claim of same-level global semantic truth.

## 7.4 Partiality as a secondary safeguard

Stratification is the main guardrail. Partiality is the secondary one.

When coded evaluation is implemented by graph rewriting, a rewrite may fail to terminate or may remain unresolved under the declared strategy. In that case the evaluator returns \(\bot\), or more generally an effectful result recording divergence or branching. It does **not** return “false,” “true,” or an arbitrary normal form.

Thus a paradoxical self-application attempt has three controlled outcomes:

| Situation | Result |
|---|---|
| It violates membrane typing | rejected before execution |
| It is well typed but outside the supported evaluator fragment | explicit “unsupported” result |
| It generates an infinite rewrite sequence | \(\bot\) / divergence |

The system must never silently convert nontermination into a Boolean semantic answer.

## 7.5 Program E barrier and reflection-cost profile

Program E becomes active only if a proposed extension adds all of the following:

1. a total unstratified evaluator;
2. weak point-surjectivity, meaning codes represent every predicate on the code object; and
3. a fixed-point-free truth operation, such as Boolean negation.

Lawvere’s diagonal theorem then yields the familiar fixed-point conflict. The research contribution is not to re-prove Lawvere. It is to determine whether a concrete diagrammatic reflection interface actually implies the decisive representation-completeness premise.

The constructive target is a **reflection-cost profile**, not a single vague claim that “stratification is needed.” For a designated fragment \(F\), let

\[
\sigma_X(F)
=
\min\left\{r\in\mathbb N\cup\{\infty\}:\;
X\text{ has a sound representation in level }k+r\text{ about }F\subseteq\mathcal M_k
\right\}.
\]

The capability label \(X\) is one of

\[
X\in\{\mathsf{wf},\mathsf{check},\mathsf{eval},\mathsf{sat},\mathsf{truth}\},
\]

for well-formedness, proof checking, contextual evaluation, model-relative satisfaction, and global semantic truth.

The intended early profile is not a theorem yet, but it gives a precise target:

\[
\sigma_{\mathsf{wf}}(F)\le 1,
\qquad
\sigma_{\mathsf{check}}(F)\le 1,
\qquad
\sigma_{\mathsf{eval}}(F)\le 1\;\text{for a declared terminating or partial fragment},
\]

while, under the hypotheses needed for Tarski/Lawvere diagonalization,

\[
\sigma_{\mathsf{truth}}(F)\ge 1.
\]

The longer-term Program E question is whether sharper lower bounds can be proved for diagrams, rewrites, and proof certificates in a specified polygraphic fragment.

# 8. Core rewrite families

The initial calculus should distinguish rewrite families by color, edge style, or cell tag. This makes proof obligations inspectable.

| Rewrite family | Form | Intended role |
|---|---|---|
| Structural equation | \(d\Rightarrow d'\) | Axiom or derived equality between parallel structure diagrams |
| Map-preservation tile | \(P\vdash f^*Q\) | A map carries one predicate to another |
| Logical introduction/elimination | \(P\wedge Q\Rightarrow P\), witness rules, equality substitution | Regular-logic inference |
| Naturality / interchange tile | compatibility of composition with predicate transport | Ensures structure and proof compose together |
| Coherence cell | equality between composites of tiles | Certifies proof-path independence |
| Quote / check / eval / sat interface | typed level-changing reflection step | Controlled metamathematics only; never an untyped truth rule |

The rendering should make it impossible to mistake a structural equation for a logical rule or a quote operation. Visual uniformity must not become type erasure.

---

# 9. Theorem program

## T0. Syntax and semantics

**Goal:** Define a finite Metasketch fragment and a semantics into a regular category or a regular hyperdoctrine.

**Deliverable:** A sound interpretation theorem: every accepted structural rewrite, predicate rule, and preservation tile is semantically valid.

## T1. Preservation-tile composition

**Goal:** Prove the compositional law

\[
(P\vdash d^*Q)
\quad\text{and}\quad
(Q\vdash e^*R)
\quad\Longrightarrow\quad
P\vdash (e\circ d)^*R.
\]

**Why it matters:** This is the formal expression of the desired “homomorphisms and inferences compose in the same visual world” idea.

## T2. Regular-fragment normalization

**Goal:** Give a normal form or focused proof representation for a restricted diagrammatic regular-logic fragment.

**Example target:** Every finite proof built from equality, conjunction, substitution, and existential witness operations reduces to a canonical tile composite modulo stated coherence cells.

**Risk:** Full confluence may be too strong. A terminating normalization procedure modulo coherent isomorphism is already a good result.

## T3. Relative completeness

**Goal:** Establish completeness relative to a declared semantic class.

**Conservative initial version:** If two finite Metasketch diagrams have equal interpretations in every finite relational model of a chosen fragment, then the calculus proves their equality.

**Caution:** This may be false or computationally difficult for broad fragments. Treat it as a later target, not an assumption.

## T4. Proof coherence

**Goal:** Classify critical branchings between structural and logical rewrites and add 3-cells that make the relevant proof diagrams commute.

**Deliverable:** A finite coherent presentation for a small signature, such as monoids with a finite regular-predicate library.

## T5. Stratified quotation and checker soundness

**Goal:** Define quotation, rendering-for-inspection, and proof checking across one level shift.

**Deliverables:**

\[
\mathsf{render}_{k+1}(\mathsf{quote}_k(d))\cong d
\]

for a supported finite fragment, together with a theorem that \(\mathsf{check}_{k+1}\) accepts exactly the well-formed proof certificates generated by the declared rule set.

**Boundary:** This theorem concerns syntax and finite certificates. It is not a truth theorem.

## T6. Reflection-cost profile and minimum stratification

**Goal:** For a named fragment \(F\), establish upper and lower bounds on

\[
\sigma_X(F),
\qquad
X\in\{\mathsf{wf},\mathsf{check},\mathsf{eval},\mathsf{sat},\mathsf{truth}\}.
\]

**First meaningful target:** show that finite well-formedness and proof checking admit a one-level representation, while any same-level total global truth interface satisfying the relevant representation-completeness and Boolean hypotheses is excluded.

**Ambitious target:** prove a minimum level shift required to encode diagrams, rewrites, and proof certificates for a nontrivial polygraphic fragment while retaining a soundness theorem.

## T7. Universal-evaluator bridge or sharp boundary theorem

**Goal:** Formalize a proposed universal evaluator diagram and determine one of two outcomes:

1. it implies weak point-surjectivity for a clearly defined predicate class, yielding a conditional Lawvere barrier; or
2. it fails at a named premise, classifying the exact escape route: stratification, partiality, truth weakening, or representation incompleteness.

Either outcome is valuable. The second is likely more realistic for the first serious result.

# 10. Toy systems and falsification tests

## 10.1 M0 — Monoids

**Purpose:** minimal algebraic seed.

Include:

- multiplication and unit;
- associativity and unit rewrites;
- homomorphism squares;
- idempotent and unit predicates;
- proof tiles for preservation of idempotence.

**Pass condition:** Structural diagrams, statements, and proof tiles type-check and compose under T1.

**Failure condition:** The visual syntax cannot distinguish a structural law from a proof about a law without falling back to unrelated external notation.

## 10.2 M1 — Directed graphs and graph homomorphisms

**Purpose:** relational example with regular logic.

Include:

- vertex and edge sorts;
- incidence relations;
- graph homomorphisms;
- predicates expressing “there exists a path of length two” or “this edge has a source.”

**Pass condition:** Existential witness wiring and relation preservation work diagrammatically.

**Why it matters:** It tests relations and existence rather than only equations.

## 10.3 M2 — Finite relational database sketch

**Purpose:** practical regular-logic benchmark.

Treat a database schema as a sketch; queries are predicates in contexts; migrations are structure maps; query containment is a proof tile.

**Pass condition:** A database migration and a conjunctive-query containment proof are represented by one preservation-square formalism.

## 10.4 M3 — A small proof-coherence case

**Purpose:** test higher cells.

Choose a setting where two proof routes establish the same preservation fact. Enumerate the critical branchings and add a coherence cell proving that the two composites agree.

**Pass condition:** The calculus records why the proof paths agree instead of merely treating them as an external equality.

## 10.5 M4 — Quoted diagram certificates

**Purpose:** first Program E integration.

Quote a finite monoid diagram and a short rewrite certificate into the next level. Prove type preservation and render/quote adequacy for this finite fragment.

**Pass condition:** The level shift is explicit and no same-level universal evaluator is silently introduced.


## 10.6 M5 — Membrane and partial-evaluation control

**Purpose:** test that reflection safety is enforced by diagram topology and operational semantics, not merely by documentation.

Construct three small coded examples:

1. a well-typed finite proof certificate accepted by \(\mathsf{check}_{1}\);
2. a code token that attempts an illegal same-level evaluator connection and is rejected by the membrane/type checker; and
3. a well-typed but divergent graph-rewrite evaluator whose result is \(\bot\).

**Pass condition:** the three cases are visibly different in the rendered diagrams and produce the three different outcomes promised in Section 7.4.

---

# 11. Computational architecture

The mathematical design needs a prototype early. The prototype should not attempt to solve arbitrary theorem proving. Its role is to force type discipline and expose bad definitions.

```text
metasketch/
  core/
    sorts.py              # object and context types
    diagrams.py           # string-diagram AST and composition
    predicates.py         # regular predicates in contexts
    tiles.py              # entailments and preservation tiles
    coherences.py         # higher cells / critical branchings
    levels.py             # reflection levels, lifting, and quotation membranes
    reflection_api.py     # quote, check, eval, sat interfaces and result types
    partiality.py         # Lift(X), divergence, and supported-fragment statuses
  libraries/
    monoids.py
    graphs.py
    relations.py
    database_sketches.py
  semantics/
    finite_relations.py
    finite_sets.py
    model_checker.py
  rewrite/
    matcher.py
    normalizer.py
    critical_pairs.py
  tests/
  notebooks/
```

## 11.1 First concrete data structures

- **Context:** ordered typed boundary list.
- **Diagram:** directed acyclic hypergraph with typed ports and composition boundaries.
- **Predicate:** syntax tree over equality, conjunction, existential binding, and relation atoms.
- **Tile:** pair of typed source/target predicate-decorated diagrams plus a rule label.
- **Coherence:** a 3-cell whose boundary is a pair of tile composites.
- **Quoted object:** immutable serialized abstract syntax tree with source level, target code level, and a membrane boundary.
- **Reflection interface:** a typed signature for \(\mathsf{quote}\), \(\mathsf{check}\), \(\mathsf{eval}\), or \(\mathsf{sat}\), including its source fragment and declared partiality behavior.
- **Lifted result:** either a value in the imported lower-level type, \(\bot\) for divergence, or an explicit unsupported-fragment status.

## 11.2 First automation targets

1. Type checking.
2. Rewrite matching for finite diagrams.
3. Semantic validation in finite models.
4. Search for short proof-tile composites.
5. Critical-pair enumeration for a small rewrite library.
6. Quote/render-for-inspection round-trip tests.
7. Membrane-crossing rejection tests.
8. Distinguish finite proof checking from model-relative satisfaction and divergent evaluation.

## 11.3 What not to automate first

- arbitrary higher-order theorem proving;
- unrestricted unification across levels;
- automatic discovery of semantic models;
- an untyped self-interpreter or same-level truth predicate;
- automatic claims of completeness.

---

# 12. Literature boundary and novelty discipline

Metasketch is not new merely because it combines familiar components. The nearest existing bodies of work are substantial.

| Existing area | What it already provides | What Metasketch must add |
|---|---|---|
| Functorial semantics and sketches | Syntax presented categorically; models as structure-preserving interpretations | A unified diagrammatic proof-tile interface and operational rewrite calculus |
| Graphical regular logic | String-diagram syntax and proof rules for regular logic | Explicit integration with polygraphic structural rewrites, homomorphism transport, and higher coherence |
| Polygraphs and higher-dimensional rewriting | Rewrites as higher cells; critical-branching/coherence machinery | A predicate/proof layer coupled compositionally to structural diagrams |
| Diagrammatic first-order logic | Graphical reasoning about formulas and relations | A stratified metamathematical quotation layer and a precise relation to Program E |
| ZX and graphical linear algebra | Rewrite-complete diagrammatic calculi for process theories | A logic-and-metatheory calculus whose diagrams represent structures, statements, and proofs |
| Proof assistants / dependent type theory | Internal languages, proof terms, type checking, controlled reflection | A visual polygraphic interface with explicit structural and logical preservation tiles |

The specific novelty target is narrow:

> A finite, typed, polygraphic calculus in which structural maps and regular-logic proofs are connected by compositional preservation tiles; the calculus supplies proof coherence and a stratified quotation interface whose limits are analyzed through Program E.

The project fails its novelty test if it is only a new rendering of graphical regular logic, only a polygraph with labels, or only a proof assistant syntax drawn as string diagrams.

---

# 13. Risks and design safeguards

| Risk | Why it is serious | Safeguard |
|---|---|---|
| The calculus merely repackages graphical regular logic | Existing work is already sophisticated | State a theorem that requires both structural polygraph and predicate transport; compare expressivity formally |
| The visual notation hides typing distinctions | “Homoiconicity” becomes ambiguity | Rigid quotation membranes, typed ports, visible level labels, and a checker that rejects illicit crossings |
| Proof checking is confused with truth deciding | A syntactic certificate checker can be mistaken for an internal truth oracle | Keep \(\mathsf{check}\), \(\mathsf{eval}\), \(\mathsf{sat}\), and global truth as separate typed interfaces |
| Full logic makes the first system intractable | Negation and implication introduce difficult variance and diagonal risks | Start with the regular fragment only |
| Coherence explodes combinatorially | Higher-dimensional rewriting can generate many critical pairs | Restrict signatures and prove local coherent presentations first |
| Nontermination is misread as a truth value | Rewriting-based evaluation may diverge | Return \(\bot\) or an explicit effectful result; never silently coerce divergence to true or false |
| Quote/eval silently activates the Program E barrier | Total same-level reflection can smuggle in diagonalization | Quote raises level by default; every evaluator declares its source fragment, context requirement, and completeness status |
| Theorem targets are only restatements of existing results | The new name adds no mathematics | Maintain a literature matrix and residue dictionary from day one |

# 14. Development sequence

## Phase 1 — A working regular Metasketch kernel

**Deliverables**

- Formal syntax for contexts, structural diagrams, predicate regions, and proof tiles.
- Semantics in finite relational models.
- Monoid and graph libraries.
- Soundness of the basic tile rules.

**Decision criterion**

The monoid and graph examples can be rendered, type-checked, semantically evaluated, and composed without ad hoc notation outside the calculus.

## Phase 2 — Polygraphic proof coherence

**Deliverables**

- Critical-pair analyzer for a small library.
- Explicit 3-cells for at least one nontrivial proof-coherence example.
- A normalization or focused proof procedure for a restricted fragment.

**Decision criterion**

Alternative proof routes are represented internally and reconciled through explicit coherence cells.

## Phase 3 — Regular-query / database test

**Deliverables**

- Relational-schema sketches.
- Conjunctive-query predicates.
- Migration and query-containment preservation tiles.

**Decision criterion**

The calculus yields a useful practical example, not only algebraic toy diagrams.

## Phase 4 — Stratified metadiagrams and reflection API

**Deliverables**

- Quotation membranes and code ports for finite diagrams and finite proof certificates.
- \(\mathsf{quote}\), \(\mathsf{check}\), \(\mathsf{eval}\), and \(\mathsf{sat}\) interfaces with explicit source levels and partiality behavior.
- Level checker, membrane-crossing rejection tests, and quote/render adequacy theorem for a declared fragment.
- A first reflection-cost upper-bound table for well-formedness, proof checking, and supported evaluation.

**Decision criterion**

Metamathematical diagrams can be manipulated without an untyped self-evaluator, a hidden same-level truth predicate, or ambiguity between proof checking and semantic truth.

## Phase 5 — Program E boundary and minimum-stratification theorem

**Deliverables**

- A concrete candidate universal evaluator interface.
- An attempted bridge to weak point-surjectivity.
- Upper and lower bounds on the reflection-cost profile for a named fragment.
- Either a conditional diagonal theorem or a sharp failure analysis identifying stratification, partiality, truth weakening, or restricted representation.

**Decision criterion**

The reflection boundary is mathematically specific: the document states the least proven level shift for each supported capability and identifies why stronger same-level reflection fails or remains unavailable.

---

# 15. First paper shapes

## Paper 1 — *Metasketch: A Diagrammatic Regular Calculus for Structures and Preservation Proofs*

**Scope:** Phases 1–2.

Contents:

1. syntax for structural diagrams, predicates, and preservation tiles;
2. finite relational semantics and soundness;
3. the preservation-tile interchange theorem;
4. a monoid and graph case study;
5. coherent normalization for a small fragment.

This is the primary constructive paper.

## Paper 2 — *Stratified Metadiagrams: Quotation and Proof Certificates in a Polygraphic Calculus*

**Scope:** Phase 4.

Contents:

1. level-indexed quotation membranes and rendering-for-inspection;
2. typed \(\mathsf{check}\), \(\mathsf{eval}\), and \(\mathsf{sat}\) interfaces;
3. type preservation, adequacy, and explicit partial-evaluation semantics;
4. a reflection-cost upper-bound profile for finite certificates and supported evaluation;
5. a proof that the interface does not supply same-level predicate completeness;
6. relation to Program E’s escape routes.

## Paper 3 — *Reflection Boundaries for Diagrammatic Calculi*

**Scope:** Phase 5.

Contents:

1. Program E’s conditional Lawvere framework;
2. a formal universal-evaluator hypothesis for a diagrammatic calculus;
3. a bridge theorem or bridge-failure classification;
4. lower and upper bounds on the reflection-cost profile;
5. minimum stratification or partiality requirements for the chosen fragment.

This paper should be attempted only after the base calculus exists. Otherwise the “diagrammatic” part risks becoming motivational decoration around a known diagonal theorem.

---

# 16. Immediate next step

Build **Metasketch-0** around monoids and directed graphs.

The first formal milestone is not a universal foundation. It is this:

\[
\boxed{
\text{A preservation tile composes correctly and is semantically sound in finite models.}
}
\]

Concretely, implement and prove the following:

1. typed structural diagrams \(d:\Gamma\to\Delta\);
2. regular predicates \(P\in\mathrm{Pred}(\Gamma)\);
3. a tile judgment \(P\vdash d^*Q\);
4. vertical composition of tiles;
5. horizontal composition along structure maps;
6. a finite-model semantics validating those compositions; and
7. a minimal membrane type checker that distinguishes a quoted proof certificate, a legal higher-level checker call, and an illegal same-level truth call.

Once this kernel works, the higher-dimensional coherence and reflective layers become meaningful research rather than aspirational overlays.

---

# References and source boundary

The following sources delimit the proposal’s starting point. They should be cited precisely in any paper derived from this design document.

1. Brendan Fong and David I. Spivak, *Graphical Regular Logic*, arXiv:1812.05765 (2019). Establishes a graphical/string-diagram treatment of regular logic and regular calculi.
2. Brendan Fong and David I. Spivak, *String Diagrams for Regular Logic*, EPTCS 323 (2020), arXiv:2009.06836.
3. Dimitri Ara, Albert Burroni, Yves Guiraud, Philippe Malbos, François Métayer, and Samuel Mimram, *Polygraphs: From Rewriting to Higher Categories*, arXiv:2312.00429 (2023). Broad reference for polygraphs, higher-dimensional rewriting, and coherence.
4. Yves Guiraud and Philippe Malbos, *Identities among Relations for Higher-Dimensional Rewriting Systems*, arXiv:0910.4538 (2009).
5. Samuel Mimram, *Towards 3-Dimensional Rewriting Theory*, arXiv:1403.4094 (2014).
6. Fabio Bonchi et al., *Diagrammatic Algebra of First Order Logic*, arXiv:2401.07055 (2024). Relevant neighboring work on string-diagrammatic reasoning for first-order logic.
7. Jonathan Gorard, Manojna Namuduri, and Xerxes D. Arsiwalla, *ZX-Calculus and Extended Hypergraph Rewriting Systems I: A Multiway Approach to Categorical Quantum Information Theory*, arXiv:2010.02752 (2020).
8. Jonathan Gorard, Manojna Namuduri, and Xerxes D. Arsiwalla, *Fast Automated Reasoning over String Diagrams using Multiway Causal Structure*, arXiv:2105.04057 (2021).
9. F. William Lawvere, *Diagonal Arguments and Cartesian Closed Categories*, Lecture Notes in Mathematics 92 (1969), 134–145; TAC Reprint 15 (2006). The categorical fixed-point barrier used by Program E.
10. Alfred Tarski, *Der Wahrheitsbegriff in den formalisierten Sprachen*, *Studia Philosophica* 1 (1935), 261–405; English translation in *Logic, Semantics, Metamathematics* (1956). The classical truth-boundary reference for same-language semantic truth.
11. Program E — *Reflective Diagrammatic Stratification*, v1 (internal companion design document, June 30, 2026).

---

# One-sentence design rule

\[
\boxed{
\text{Make structure, statements, proofs, and metaproofs visually adjacent; make every reflective crossing pass through a typed higher-level membrane.}
}
