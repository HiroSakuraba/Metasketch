# Historical design revisions

These documents are retained only for version history. They predate the v0.4
corrections and should not be used as the current technical specification.

Use `../metasketch_reflective_diagrammatic_calculus_design_v0_4.md` instead.
