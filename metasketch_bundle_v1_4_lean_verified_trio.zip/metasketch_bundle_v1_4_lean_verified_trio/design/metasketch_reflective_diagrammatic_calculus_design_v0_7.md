# Metasketch: A Reflective Diagrammatic Calculus
## Design document v0.7: trusted construction, adequacy, coherence lifting, and Program E audit

**Status:** Runnable finite prototype with a conventional monoid proof note, a
finite certificate--match adequacy result, and a first reflection audit on real
proof objects. It remains neither a general proof assistant nor a completed
foundation for metamathematics.

**Supersedes:** v0.6.1 for implementation status. The renderer, visual grammar,
and earlier finite phases remain part of the project. v0.7 closes the most
important current-fragment gaps without widening the logical fragment.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

---

## 0. Executive summary

v0.6.1 made witness certificates and their higher coherence renderable. v0.7
makes four targeted improvements before attempting a broader logical fragment or
a stronger reflective theorem.

1. **Checked public API.** The supported construction boundary is now
   `metasketch0.api`. It validates contexts, terms, predicates, diagrams, tiles,
   and finite models. Raw AST construction remains deliberately available only
   through `metasketch0.unsafe_ast` for experiments. This is a Python trust
   boundary, not a claim that direct imports are impossible.

2. **Monoid proof closure.** A standalone proof note proves termination,
   confluence, and right-comb normal forms for the directed monoid presentation.
   The seven ordered critical branchings are listed explicitly; the kernel stores
   and replays the corresponding confluence fillers.

3. **Finite certificate--match adequacy.** For a fixed finite relation-only
   pattern and model, normalized accepted certificates are in bijection with
   concrete relational matches. A visible assignment satisfies the compiled
   conjunctive query exactly when some accepted canonical certificate has that
   assignment.

4. **Reusable coherence lifting.** A generic schema now takes a structural
   one-step rewrite, a transport operation, and a normalization strategy and
   constructs a checked transport-normalization 3-cell when the two branches
   share a normal form. The monoid tile construction is its first instance;
   relational witness transport remains a parallel compositional instance.

5. **Program E audit on actual proof objects.** Quotation of a Phase 5 witness
   certificate is level-raising, checking is syntactic and higher-level, and the
   current kernel has no total universal evaluator or representation-complete
   same-level predicate code class. Therefore no weak-point-surjectivity bridge
   is present or assumed.

The full regression suite now has **106 checks**:

| Layer | Checks | Focus |
|---|---:|---|
| Public API | 5 | checked construction and finite-model boundary |
| Phase 1 | 35 | finite syntax, semantics, tiles, and reflection interfaces |
| Phase 2 | 10 | directed monoid rewriting and confluence fillers |
| Phase 2.5 | 9 | monoid structure--logic coherence |
| Phase 3 | 14 | graph-pattern query transport |
| Phase 4 | 11 | relational witness certificates and normal forms |
| Phase 5 | 5 | certificate--match adequacy |
| Lift schema | 4 | reusable transport-normalization lifting |
| Program E audit | 5 | actual proof quotation and missing bridge premises |
| Renderer | 10 | auditable SVG scenes, scopes, membranes, and 3-cells |

---

## 1. Trusted construction boundary

The old prototype had static validation and capture-avoiding substitution, but
users could create raw AST objects and accidentally bypass the intended entry
point. v0.7 distinguishes two APIs.

```text
metasketch0.api
  checked_context
  checked_term
  checked_predicate
  checked_diagram
  checked_tile
  checked_model
  model_from_parts

metasketch0.unsafe_ast
  lightweight experimental raw AST constructors
```

The safe API is not parser-only. Programmatic proof search, compilation, and
future theorem-prover integration need checked synthesis as well as checked
parsing. Every public model constructor exhaustively validates finite carriers,
operation arities and codomains, and relation tuple arities and sorts.

The present implementation rule is:

\[
\text{raw object}
\longrightarrow
\text{checked wrapper or local revalidation}
\longrightarrow
\text{renderer, quotation, or theorem-facing routine}.
\]

This does not make Python imports capability-secure. It makes the trusted path
explicit and testable.

---

## 2. Directed monoid presentation is now a proved reference object

The structural rules are

\[
(xy)z\to x(yz),
\qquad ex\to x,
\qquad xe\to x.
\]

A polynomial interpretation proves termination. The full ordered critical-pair
table gives local confluence. Newman's lemma yields confluence. Every normal form
is the right comb of the atom word after units are erased.

This gives Metasketch a compact reference presentation with all of the following
in one place:

- directed structural rewrites;
- stored rewrite traces;
- explicit 3-cell fillers for every critical branching;
- a decision procedure for the free-monoid word problem; and
- a controlled example of lifting structural rewrites through predicate
  transport.

The result is a directed rewrite-theoretic analogue of the associator pentagon.
It is not full Mac Lane coherence for arbitrary monoidal categories, because the
kernel's associativity rule is directed rather than invertible.

The complete proof is in `metasketch_monoid_rewriting_proof_note_v0_1.md`.

---

## 3. Phase 5: finite certificate--match adequacy

Let \(P\) be a finite relation-only pattern with visible variables \(\bar x\),
hidden variables \(\bar z\), and compiled query

\[
Q_P(\bar x)=\exists\bar z.\bigwedge_i R_i(\bar v_i).
\]

For a fixed finite model \(M\), write \(\operatorname{Match}_M(P)\) for the
finite set of typed relational matches. The certificate layer provides

\[
\operatorname{build}:
\operatorname{Match}_M(P)
\to
\operatorname{Cert}^{\mathrm{can}}_M(P),
\]

and

\[
\operatorname{erase}:
\operatorname{Cert}^{\mathrm{can}}_M(P)
\to
\operatorname{Match}_M(P).
\]

The proved finite correspondence is

\[
\operatorname{erase}\circ\operatorname{build}=1,
\]

and, for each accepted presentation-level certificate \(\pi\),

\[
\operatorname{NF}(\pi)=
\operatorname{NF}(\operatorname{build}(\operatorname{erase}(\pi))).
\]

Thus, for every visible assignment \(\bar a\),

\[
M,\bar a\models Q_P
\quad\Longleftrightarrow\quad
\exists\pi\;[
\operatorname{check}(\pi)=\mathsf{accept}
\land
\operatorname{visible}(\pi)=\bar a].
\]

The implementation's `PatternWitnessProof` carries its match explicitly. This
means the result is a certificate-discipline adequacy theorem, not a general
proof-reconstruction theorem from arbitrary unannotated syntax. That is an
intentional limitation, stated plainly in the Phase 5 note.

---

## 4. Reusable coherence-lifting schema

The generic shape is

\[
r:d\Rightarrow d'
\quad\mapsto\quad
\operatorname{Lift}(r,Q):d^*Q\Rightarrow(d')^*Q.
\]

A `CoherenceLiftingSchema` declares:

1. a one-step structural rewrite operation;
2. a validator for that rewrite;
3. a transport or reindexing operation;
4. a predicate-normalization procedure returning a trace; and
5. a validator for normalization traces.

For one structural branch and one target predicate, it constructs a
`LiftedTransportCoherenceCell3` with boundaries

\[
\operatorname{normalize}(d^*Q),
\qquad
\operatorname{normalize}((d')^*Q).
\]

The cell validates only when the structural step is valid, both traces are
composable and validated, and their targets coincide.

The monoid reindexing system is the first concrete instantiation. Relational
witness transport is represented by a separate adapter because it is a
composition-of-homomorphisms coherence, not literally a rewrite-plus-predicate
normalization. Both make the same higher-dimensional design pattern explicit:
parallel compositional routes require stored, validated coherence data.

This is a reusable finite schema, not yet a general Squier-style homotopy-basis
theorem.

---

## 5. Program E audit on a real witness proof

The reflection program is now applied to an actual Phase 5 proof object rather
than toy syntax alone. Given a certificate \(\pi\) at level \(k\), v0.7 constructs

\[
\mathsf{quote}_k(\pi):
\mathsf{Proof}_k
\to
\mathsf{Code}_{k+1}[\mathsf{Proof}_k].
\]

The audit establishes these current facts:

- quotation raises level by exactly one;
- proof checking is permitted only at a strictly higher level and is syntactic,
  not semantic truth;
- resource exhaustion in the bounded evaluator is **not** treated as a proof of
  divergence or as semantic partiality;
- the membrane blocks a same-level interface that is both total and
  representation-complete; and
- no total universal evaluator \(e:A\to\Omega^A\) or point-surjective code
  class is implemented or assumed.

Therefore the current interface does not supply a non-tautological bridge to
weak point-surjectivity. The identified escape routes are

\[
\boxed{
\text{stratification}
\;+
\text{representation incompleteness}
\;+
\text{absence of a total universal evaluator}.
}
\]

The finite diagonal table remains a useful warning about same-level Boolean
representation. It is not Tarski's undefinability theorem and not a general
Lawvere theorem.

---

## 6. Current artifact map

```text
metasketch0/
  api.py                   supported checked public API
  unsafe_ast.py            explicitly experimental raw AST frontend
  checked.py               proof-carrying checked wrappers
  adequacy.py              Phase 5 certificate--match correspondence
  coherence_lift.py        reusable transport-normalization schema
  reflection_audit.py      Program E audit of real witness proofs
  syntax.py                raw finite regular-logic syntax and hygiene
  semantics.py             finite model semantics and validation
  proofs.py                certificate syntax, normalization, transport cells
  coherence.py             monoid rewriting, traces, and critical-pair fillers
  tile_coherence.py        monoid rewrite/reindex coherence cells
  render.py                audited semantic SVG scene graph
  tests_phase5.py          finite adequacy tests
  tests_phase_lift.py      coherence-lifting tests
  tests_phase_reflection_audit.py
```

Supporting notes:

```text
metasketch_monoid_rewriting_proof_note_v0_1.md
metasketch_phase5_certificate_match_adequacy_note_v0_1.md
metasketch_program_E_reflection_audit_note_v0_1.md
```

---

## 7. What remains deliberately open

v0.7 does not claim:

- a general completeness theorem for regular logic;
- reconstruction of a semantic match from arbitrary raw proof syntax;
- a general coherence-lifting theorem for arbitrary polygraphs;
- a full homotopy basis for relational proof rewrites;
- semantic partiality from a finite resource budget;
- a Lawvere bridge from universal evaluation to weak point-surjectivity; or
- a two-way visual editor.

---

## 8. Next decision

The strongest next project is to remove the explicit `RelationalMatch` field from
one restricted certificate syntax and prove a reconstruction theorem:

\[
\text{accepted raw certificate}
\longrightarrow
\text{unique normalized witness map}.
\]

That would make the certificate--match adequacy result nontrivial in a stronger
sense. The alternative is to extend the generic coherence schema to a second
structural theory with nontrivial relation transport, then ask for a small
symbolic rather than enumerative result. Program E should wait until one of those
makes the reflective predicate class more concrete.
