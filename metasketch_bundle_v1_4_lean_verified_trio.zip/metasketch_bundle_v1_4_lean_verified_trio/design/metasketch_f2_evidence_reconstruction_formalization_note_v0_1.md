# Metasketch F2 Evidence-Reconstruction Formalization Note
## v0.1: Lean source handoff, finite cross-checks, and exact scope

**Status:** F2 evidence-core source completed in dependency-free Lean 4 syntax;
not independently compiled in this runtime. The Python kernel provides finite
replay and exhaustive cross-checks. Only F1 is currently machine-checked.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

## 1. What F2 is

F2 concerns the reconstruction step behind a pointed raw Metasketch
certificate. The checked Python front end extracts three kinds of evidence:

\[
\begin{array}{rcl}
E_{\mathrm{atom}} &:& \text{values read from concrete relation-fact leaves},\\
E_{\mathrm{binder}} &:& \text{values named by the outer existential-witness spine},\\
E_{\mathrm{boundary}} &:& \text{values supplied for visible variables absent from the matrix}.
\end{array}
\]

Let

\[
E = E_{\mathrm{atom}} \cup E_{\mathrm{binder}} \cup E_{\mathrm{boundary}}.
\]

The F2 core assumes two acceptance conditions:

\[
\forall x\;\exists a\;(x,a)\in E
\]

and

\[
(x,a)\in E \land (x,b)\in E \implies a=b.
\]

The reconstruction function chooses the value attached to each variable. The
second condition proves that the choice is independent of which supporting
entry is selected.

## 2. Lean theorem interface

`formal/lean/PointedRawReconstruction.lean` defines:

```text
Evidence Var Val
Assignment Var Val
Occurs, Covers, Consistent, Realizes
reconstruct

PointedRawCertificate
AcceptedPointedRawCertificate
EvidencePartition
erasePointed
```

Its central theorem interface is:

```text
reconstruct_realizes_evidence
  complete consistent evidence -> reconstruction realizes every entry

reconstruct_unique
  any assignment realizing the same evidence equals reconstruction

reconstruct_realizes_atomEvidence
reconstruct_realizes_binderEvidence
reconstruct_realizes_boundaryEvidence
  each provenance class remains individually visible after reconstruction

reconstruct_erase
  canonical three-source erasure followed by reconstruction returns
  the original assignment
```

The formal proof is generic over arbitrary types of variables and values. It
does not require the variable set to be finite; finite pattern and model data
are enforced before translation by the concrete Metasketch front end.

## 3. Why this is the right first F2 slice

The distinctive mathematical content of Phase 6 and Phase 7 is not finite
search. It is the fact that evidence from separate syntactic positions
constrains one semantic witness map:

\[
\operatorname{rec}(\rho):\operatorname{Var}(P)\to |M|.
\]

The Lean source verifies the abstract uniqueness mechanism once its front-end
premises have been extracted. This isolates the theorem that is reused by:

- raw fact-leaf reconstruction;
- hidden existential-witness reconstruction;
- pointed free-input reconstruction; and
- canonical erase/reconstruct round trips.

This is deliberately narrower than a full formalization of finite relational
patterns. The next extension is to formalize the Python front-end validation
that produces the three evidence packages:

1. typed signature and finite model;
2. pattern atom indices and relation arities;
3. relation-fact membership;
4. one outer binder prefix for hidden variables;
5. exactly one boundary assignment for each unanchored visible variable.

Once those objects live in Lean, `reconstruct_realizes_atomEvidence` can be
strengthened from “realizes extracted atom evidence” to “satisfies every
relation atom of the pattern in the finite model.”

## 4. Finite executable audit

The new Python Phase 11 suite adds a small independent audit of the theorem
kernel. Over two variables, two possible values, and evidence lists of lengths
2 through 4, it exhaustively verifies:

\[
\text{complete} \land \text{consistent}
\quad\Longrightarrow\quad
\text{exactly one realizing assignment}.
\]

It checks 88 covered, consistent evidence lists. It separately confirms that:

- incomplete evidence has multiple realizers;
- inconsistent evidence has none;
- atom, binder, and boundary evidence recombine to one map; and
- the Lean source exposes the declared theorem names with no placeholders.

This executable audit is a regression check, not a substitute for Lean
compilation.

## 5. Compilation status

The v1.2 `formal/lean/verify.sh` script compiles both F1 and F2 and prints the
axiom footprints of their central theorems in a Lean 4 v4.31.0 environment.
The current execution environment had no `lean` executable and could not
resolve the Lean release host, so F2 has **not** been independently compiled
here.

The strict claim boundary is therefore:

\[
\boxed{
\text{F1: machine-checked}\qquad
\text{F2: complete source + finite audits, compilation pending}
}
\]

## 6. Recommended F2 completion criterion

Promote F2 to machine-checked only when all of the following have been run in a
clean Lean 4 v4.31.0 environment:

```text
./formal/lean/verify.sh
lean --version
#print axioms reconstruct_realizes_evidence
#print axioms reconstruct_unique
#print axioms pointed_reconstruct_unique
#print axioms reconstruct_erase
```

Then record the exact compiler output and axiom footprint in a new
`F2_VERIFICATION.txt`. Until then, `F2_STATUS.txt` remains the authoritative
scope label.
