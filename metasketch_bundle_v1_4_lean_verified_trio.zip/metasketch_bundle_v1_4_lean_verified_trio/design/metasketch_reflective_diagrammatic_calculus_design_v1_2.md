# Metasketch: A Reflective Diagrammatic Calculus
## Design document v1.2: F2 evidence-core formalization handoff

**Status:** Finite-core release. F1 is machine-checked. F2 now has a complete
Lean source for its evidence-reconstruction kernel, with Python finite audits;
F2 is not yet claimed machine-checked because this runtime could not compile
Lean.

**Supersedes:** v1.1 for current implementation and formalization status.

**Author:** Benjamin John Schulz  
**Date:** July 1, 2026

## Executive summary

Metasketch remains a finite prototype for a stratified diagrammatic calculus in
which structural diagrams, existential-conjunctive predicates, raw proof
certificates, selected coherence cells, and auditable SVG projections are
checked together.

v1.2 does not broaden the logical fragment. It formalizes the central
mathematical kernel of F2, pointed raw-certificate reconstruction.

| Formal target | v1.2 status | Exact scope |
|---|---|---|
| F1, directed monoid normalization | Machine-checked | Lean 4 v4.31.0, core only |
| F2, evidence reconstruction | Lean source + finite audit | complete and consistent atom/binder/boundary evidence determines one assignment |
| Full pointed relational certificate | Open | finite models, relation facts, binder syntax, arities, and scope not yet represented in Lean |
| Reflection type safety | Open | Program E remains an audit/design boundary |

The Python suite now contains **150 checks**, all passing. Phase 11 adds six F2
handoff checks and a finite exhaustive audit of the generic uniqueness kernel.

## 1. F2 formal core

A raw certificate produces three evidence sources:

\[
E_{\mathrm{atom}},\quad E_{\mathrm{binder}},\quad E_{\mathrm{boundary}}.
\]

The Lean definition combines them into:

\[
E = (E_{\mathrm{atom}} \cup E_{\mathrm{binder}}) \cup E_{\mathrm{boundary}}.
\]

Under coverage and agreement,

\[
\begin{aligned}
\forall x\;\exists a\;&(x,a)\in E,\\
(x,a)\in E\land(x,b)\in E&\Rightarrow a=b,
\end{aligned}
\]

there is a uniquely determined assignment:

\[
\operatorname{rec}(E):x\mapsto a.
\]

The source `formal/lean/PointedRawReconstruction.lean` proves the following
interface, subject to compilation:

```text
reconstruct_realizes_evidence
reconstruct_unique
reconstruct_realizes_atomEvidence
reconstruct_realizes_binderEvidence
reconstruct_realizes_boundaryEvidence
reconstruct_erase
```

The first two are the main F2 theorem kernel. The remaining four preserve
provenance and establish the canonical round trip.

## 2. Scope boundary

The source does **not** yet prove that a raw Metasketch proof tree is well
formed. The Python trusted front end continues to validate:

- many-sorted relation signatures and finite models;
- relation arity and fact membership;
- every pattern atom appearing exactly once;
- a single outer binder spine with one hidden witness per hidden variable;
- pointed boundary assignments exactly for visible variables absent from the
  relation matrix; and
- syntax-to-evidence extraction.

This separation is intentional. It prevents a source-level evidence theorem
from being overstated as a complete regular-logic or relational-model theorem.

## 3. F2 completion path

1. Compile the new Lean source using `formal/lean/verify.sh` on Lean 4 v4.31.0.
2. Record `#print axioms` output in `F2_VERIFICATION.txt`.
3. Move a minimal finite relation-only signature, model, pattern, and atom-fact
   datatype into Lean.
4. Prove that validated raw proof trees extract complete, consistent evidence.
5. Compose that extraction theorem with F2 core uniqueness to obtain the full
   pointed relational reconstruction theorem.

The final result should take the shape:

\[
\rho\text{ accepted}\quad\Longrightarrow\quad
\exists!\,m\in\operatorname{Match}_M(P)\;.
; m\text{ realizes }\rho.
\]

## 4. Current project status

The existing finite fragment remains unchanged:

- checked public Python API with raw AST isolation;
- directed monoid rewriting and stored directed confluence fillers;
- existential-conjunctive relational patterns;
- witness certificates, normalization, and transport coherence;
- pointed raw certificates with no stored match;
- semantic renderer with quotation membranes and auditable SVG manifests;
- Program E audit with stratification and representation-incompleteness as the
  declared escape routes.

The next work remains focused. Complete F2 at the relation/model front end
before adding equality, negation, a visual editor, or a universal evaluator.

## 5. Claim discipline

The following distinction is mandatory in all future notes:

\[
\boxed{
\begin{array}{ll}
\text{F1} & \text{machine-checked Lean theorem},\\
\text{F2 core} & \text{Lean source and finite Python cross-checks, compilation pending},\\
\text{F2 full} & \text{open formalization target}.\\
\end{array}
}
\]

See `design/metasketch_f2_evidence_reconstruction_formalization_note_v0_1.md`
and `formal/lean/F2_STATUS.txt` for the authoritative details.
