# Phase 4.1 implementation: semantic renderer

## Delivered

- `metasketch0/render.py` defines validated scene nodes, typed ports, scoped
  regions, semantic edges, boundary traces, 3-cells, canonical manifests, and
  deterministic SVG serialization.
- `metasketch0/showcases.py` creates four SVG showcase objects from live kernel
  values and writes a static gallery.
- `metasketch0/tests_phase_renderer.py` adds 10 renderer checks.

## Safety rules enforced

1. Every visual object has a semantic reference.
2. Ordinary edges connect matching typed `out` and `in` ports.
3. Witness outputs cannot leave their existential region.
4. Quotation membranes allow only `code_out -> code_in` crossings.
5. Every 3-cell boundary is a composable existing-edge trace with shared source
   and target.
6. Every SVG embeds the canonical semantic manifest and its SHA-256 audit hash.

## Run

```bash
python run_all_tests.py
python -m metasketch0.render_showcases --out rendered_examples
```
