"""
A short readable walkthrough of Metasketch-0.

Run:  python demo.py
"""

from metasketch0 import libraries as lib
from metasketch0.tiles import valid_in
from metasketch0 import reflection as refl


def rule(title):
    print("\n" + title)
    print("-" * len(title))


def main():
    print("Metasketch-0 walkthrough")
    print("========================")

    rule("1. A preservation tile has two readings at once")
    tile = lib.tile_preserves_idempotence()
    print("  tile:", tile)
    print("  structural reading: h sends idempotents of M to idempotents of N")
    print("  logical reading:    idempotent(x) entails idempotent(h(x))")

    Z6 = tuple(range(6))
    mul6 = lambda a, b: (a * b) % 6
    good = lib.monoid_hom_model(Z6, mul6, 1, Z6, mul6, 1, h=lambda x: x)
    bad = lib.monoid_hom_model(Z6, mul6, 1, Z6, mul6, 1,
                               h=lambda x: 2 if x == 3 else x)
    rg = valid_in(tile, good)
    rb = valid_in(tile, bad)
    print("  in the identity-map model (a homomorphism):   valid =", rg.valid)
    print("  in the broken-map model (3 -> 2):             valid =", rb.valid,
          "  counterexample:", rb.counterexample,
          "(3 is idempotent, its image 2 is not)")

    rule("2. Quotation raises the reflection level")
    code = refl.quote({"diagram": "mul.assoc.certificate"},
                      kind="proof_certificate", source_level=0)
    print("  quoted a level-0 object -> code at level", code.code_level)
    print("  a level-1 checker may inspect it; a level-0 raw splice cannot.")

    rule("3. The membrane forbids exactly one thing: same-level total truth")
    forbidden = refl.InterfaceSpec("truth", 0, 0, total=True,
                                   representation_complete=True)
    ok = refl.membrane_check(forbidden)
    print("  same-level total, representation-complete truth interface:")
    print("    accepted =", ok.accepted)
    print("    reason  =", ok.reason)
    permitted = refl.InterfaceSpec("truth", 0, 1, total=True,
                                   representation_complete=True)
    print("  stratified truth about a lower level: accepted =",
          refl.membrane_check(permitted).accepted)

    rule("4. Why the membrane is right: the diagonal (Program E boundary)")
    ok2, info2 = refl.same_level_truth_is_impossible(2, exhaustive=True)
    print("  same-level representation-complete truth is impossible:", ok2)
    print("   ", info2)
    ok_s, info_s = refl.stratified_escape(3)
    print("  one level up escapes the barrier:", ok_s)
    print("   ", info_s)

    rule("5. Partial evaluation never fakes a Boolean")
    r_val = refl.eval_string_rewrite("aab", (("ab", "b"), ("b", "")), "ab")
    r_bot = refl.eval_string_rewrite("a", (("a", "aa"),), "a", budget=200)
    r_uns = refl.eval_string_rewrite("aXb", (("ab", "b"),), "ab")
    print("  terminating computation -> ", r_val.status, repr(r_val.value))
    print("  divergent computation   -> ", r_bot.status)
    print("  out-of-fragment symbol  -> ", r_uns.status)


if __name__ == "__main__":
    main()
