/-
Metasketch finite core, formalization target F3:
typed reflection-interface safety.

F3 formalizes the narrow reflection claim used by Metasketch's quotation
membrane.  It does NOT formalize Tarski's theorem, Lawvere's fixed-point
theorem, a universal evaluator, or a general truth predicate.

The source establishes three separate statements.

  1. The declared *safe interface grammar* has only level-raising quotation,
     strictly higher-level inspection, lower-level total truth, and same-level
     truth-shaped interfaces that explicitly surrender totality or predicate
     completeness.

  2. For every same-level Boolean evaluator e : A -> A -> Bool, its diagonal
     predicate x |-> not (e x x) is not represented by any row of e.  Therefore
     no same-level Boolean evaluator is representation-complete for predicates
     on its own code type.

  3. Typed predicate codes at level k+1 represent every Boolean predicate on a
     lower-level domain k.  The declared evaluator consumes a code at k+1 and
     an argument at k.  A direct `eval code code` call is rejected by Lean's
     type checker because its second argument has the wrong type.

This is a type-discipline theorem and a finite-interface diagonal theorem.  It
is not a claim that every possible same-level truth construction in every logic
has been formalized or excluded.

Target toolchain: Lean 4 v4.31.0, core only, no mathlib.
-/

namespace Metasketch

universe u

/-! ## 1. The safe reflection-interface grammar -/

/-- The five reflection capabilities distinguished by the Metasketch design. -/
inductive Capability where
  | quote
  | check
  | eval
  | sat
  | truth
  deriving DecidableEq, Repr

/--
Only membrane-approved interfaces are constructors of this type.

`truthLower k` is total and predicate-complete only about level `k`, while the
interface itself lives at level `k+1`.  The two same-level truth-shaped forms
make their escape route explicit: one is partial, the other incomplete.
-/
inductive SafeInterface : Type where
  | quote (k : Nat)
  | check (k : Nat)
  | eval (k : Nat)
  | sat (k : Nat)
  | truthLower (k : Nat)
  | truthSamePartial (k : Nat)
  | truthSameIncomplete (k : Nat)
  deriving Repr

namespace SafeInterface

/-- Capability carried by a safe interface. -/
def capability : SafeInterface -> Capability
  | .quote _ => .quote
  | .check _ => .check
  | .eval _ => .eval
  | .sat _ => .sat
  | .truthLower _ => .truth
  | .truthSamePartial _ => .truth
  | .truthSameIncomplete _ => .truth

/-- Level of the object being quoted, checked, evaluated, or discussed. -/
def sourceLevel : SafeInterface -> Nat
  | .quote k => k
  | .check k => k
  | .eval k => k
  | .sat k => k
  | .truthLower k => k
  | .truthSamePartial k => k
  | .truthSameIncomplete k => k

/-- Level at which the result or interface inhabitant is available. -/
def targetLevel : SafeInterface -> Nat
  | .quote k => Nat.succ k
  | .check k => Nat.succ k
  | .eval k => Nat.succ k
  | .sat k => Nat.succ k
  | .truthLower k => Nat.succ k
  | .truthSamePartial k => k
  | .truthSameIncomplete k => k

/-- Totality flag for truth-shaped interfaces.  It is deliberately false for
same-level partial truth. -/
def truthTotal : SafeInterface -> Prop
  | .truthLower _ => True
  | .truthSameIncomplete _ => True
  | _ => False

/-- Representation-completeness flag for truth-shaped interfaces.  It is
intentionally false for same-level incomplete truth. -/
def truthRepresentationComplete : SafeInterface -> Prop
  | .truthLower _ => True
  | .truthSamePartial _ => True
  | _ => False

end SafeInterface

/-- Quotation always raises the level by exactly one. -/
theorem quote_target_eq_next (k : Nat) :
    (SafeInterface.quote k).targetLevel = (SafeInterface.quote k).sourceLevel + 1 := rfl

/-- Syntactic checking is strictly higher-level inspection. -/
theorem check_strictly_higher (k : Nat) :
    (SafeInterface.check k).sourceLevel < (SafeInterface.check k).targetLevel :=
  Nat.lt_succ_self k

/-- Evaluation is strictly higher-level inspection in the declared API. -/
theorem eval_strictly_higher (k : Nat) :
    (SafeInterface.eval k).sourceLevel < (SafeInterface.eval k).targetLevel :=
  Nat.lt_succ_self k

/-- Model-relative satisfaction is strictly higher-level inspection. -/
theorem sat_strictly_higher (k : Nat) :
    (SafeInterface.sat k).sourceLevel < (SafeInterface.sat k).targetLevel :=
  Nat.lt_succ_self k

/-- Total, representation-complete truth in the safe grammar is only lower-level. -/
theorem lower_truth_strictly_higher (k : Nat) :
    (SafeInterface.truthLower k).sourceLevel <
      (SafeInterface.truthLower k).targetLevel :=
  Nat.lt_succ_self k

/-- The safe grammar contains no interface that is simultaneously truth-shaped,
same-level, total, and representation-complete. -/
theorem safeInterface_no_sameLevel_total_complete_truth (i : SafeInterface) :
    ¬ (i.capability = .truth ∧
       i.sourceLevel = i.targetLevel ∧
       i.truthTotal ∧
       i.truthRepresentationComplete) := by
  cases i with
  | quote k =>
      intro h
      cases h.1
  | check k =>
      intro h
      cases h.1
  | eval k =>
      intro h
      cases h.1
  | sat k =>
      intro h
      cases h.1
  | truthLower k =>
      intro h
      have hEq : k = Nat.succ k := by
        simpa [SafeInterface.sourceLevel, SafeInterface.targetLevel] using h.2.1
      exact (Nat.ne_of_lt (Nat.lt_succ_self k)) hEq
  | truthSamePartial k =>
      intro h
      have hFalse : False := by
        simpa [SafeInterface.truthTotal] using h.2.2.1
      exact hFalse.elim
  | truthSameIncomplete k =>
      intro h
      have hFalse : False := by
        simpa [SafeInterface.truthRepresentationComplete] using h.2.2.2
      exact hFalse.elim

/-! ## 2. Same-level diagonal incompleteness -/

/-- Boolean predicates on a code type. -/
abbrev Predicate (A : Type u) := A -> Bool

/-- A candidate same-level evaluator: code and argument live in one type A. -/
structure SameLevelEvaluator (A : Type u) where
  run : A -> A -> Bool

/-- One code `c` represents a predicate `p` if its evaluator row equals p. -/
def Represents {A : Type u} (e : SameLevelEvaluator A) (c : A)
    (p : Predicate A) : Prop :=
  ∀ x : A, e.run c x = p x

/-- Every predicate on the same code type has a representing row. -/
def RepresentationComplete {A : Type u} (e : SameLevelEvaluator A) : Prop :=
  ∀ p : Predicate A, ∃ c : A, Represents e c p

/-- The diagonal predicate associated with a same-level evaluator. -/
def diagonal {A : Type u} (e : SameLevelEvaluator A) : Predicate A :=
  fun x => Bool.not (e.run x x)

/-- No row of a same-level Boolean evaluator represents its own diagonal
predicate. -/
theorem diagonal_not_represented {A : Type u} (e : SameLevelEvaluator A)
    (c : A) :
    ¬ Represents e c (diagonal e) := by
  intro h
  have hc := h c
  change e.run c c = Bool.not (e.run c c) at hc
  cases hvalue : e.run c c <;> simp [hvalue] at hc

/-- The diagonal witness rules out representation completeness for every
same-level Boolean evaluator, with no finiteness assumption on A. -/
theorem sameLevel_not_representationComplete {A : Type u}
    (e : SameLevelEvaluator A) :
    ¬ RepresentationComplete e := by
  intro h
  obtain ⟨c, hc⟩ := h (diagonal e)
  exact diagonal_not_represented e c hc

/-! ## 3. Cross-level predicate codes -/

/-- A value explicitly tagged with its object level. -/
structure AtLevel (k : Nat) (A : Type u) where
  value : A

/-- A level-(k+1) code for a Boolean predicate whose arguments inhabit level k. -/
structure PredicateCode (k : Nat) (A : Type u) where
  run : Predicate A

/-- Quote a predicate from level k into a code token living at level k+1. -/
def quotePredicate {A : Type u} {k : Nat} (p : Predicate A) :
    AtLevel (Nat.succ k) (PredicateCode k A) :=
  ⟨⟨p⟩⟩

/-- The declared evaluator consumes a code at level k+1 and an argument at level
k.  Its output is available at level k+1. -/
def evalPredicate {A : Type u} {k : Nat}
    (code : AtLevel (Nat.succ k) (PredicateCode k A))
    (argument : AtLevel k A) : AtLevel (Nat.succ k) Bool :=
  ⟨code.value.run argument.value⟩

/-- Typed cross-level evaluation computes the represented predicate. -/
theorem evalPredicate_correct {A : Type u} {k : Nat}
    (p : Predicate A) (a : A) :
    (evalPredicate (quotePredicate (k := k) p)
      ({ value := a } : AtLevel k A)).value = p a := rfl

/-- Every predicate on the lower-level domain has a typed cross-level code. -/
theorem crossLevel_representation_complete {A : Type u} (k : Nat)
    (p : Predicate A) :
    ∃ code : AtLevel (Nat.succ k) (PredicateCode k A),
      ∀ argument : AtLevel k A,
        (evalPredicate code argument).value = p argument.value := by
  refine ⟨quotePredicate (k := k) p, ?_⟩
  intro argument
  cases argument
  rfl

/-! The expression

```
evalPredicate (quotePredicate p) (quotePredicate p)
```

is intentionally absent: Lean rejects it before theorem checking because the
second argument is required to have type `AtLevel k A`, while a predicate code
has type `AtLevel (k+1) (PredicateCode k A)`.  This static rejection is the F3
same-level self-application boundary.  It is not encoded as a theorem about all
possible arbitrary functions between unrelated types.
-/

/-! ## Small theorem-checked sanity instances -/

/-- A concrete same-level evaluator, included only as a test target for the
general diagonal theorem. -/
def falseEvaluator : SameLevelEvaluator Bool where
  run := fun _ _ => false

example : ¬ RepresentationComplete falseEvaluator :=
  sameLevel_not_representationComplete falseEvaluator

example :
    (evalPredicate (quotePredicate (k := 0) (fun b : Bool => b))
      ({ value := true } : AtLevel 0 Bool)).value = true := rfl

end Metasketch
