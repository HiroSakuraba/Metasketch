#!/bin/sh
# Compile the Metasketch finite-core formalizations and report their axiom
# footprints. Requires Lean 4 v4.31.0 (or compatible); no external dependencies.
#
# F1 was independently compiled in the v1.1 environment. F2 and F3 are added
# here so a Lean-equipped environment can recheck the whole finite-core trio.
set -e
lean -o MonoidNormalization.olean MonoidNormalization.lean
lean -o PointedRawReconstruction.olean PointedRawReconstruction.lean
lean -o ReflectionSafety.olean ReflectionSafety.lean
cat > _check_axioms.lean <<'LEAN'
import MonoidNormalization
import PointedRawReconstruction
import ReflectionSafety
open Metasketch
#print axioms step_decreases
#print axioms normal_rightComb
#print axioms normalization_sound
#print axioms normal_unique
#print axioms exists_normal
#print axioms confluence
#print axioms reconstruct_realizes_evidence
#print axioms reconstruct_unique
#print axioms pointed_reconstruct_unique
#print axioms reconstruct_erase
#print axioms safeInterface_no_sameLevel_total_complete_truth
#print axioms sameLevel_not_representationComplete
#print axioms evalPredicate_correct
#print axioms crossLevel_representation_complete
LEAN
LEAN_PATH=. lean _check_axioms.lean
rm -f _check_axioms.lean MonoidNormalization.olean PointedRawReconstruction.olean ReflectionSafety.olean
printf '%s\n' 'F1, F2, and F3 formalizations verified.'
