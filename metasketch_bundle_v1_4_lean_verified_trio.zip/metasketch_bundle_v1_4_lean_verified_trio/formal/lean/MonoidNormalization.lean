/-
Metasketch finite core, formalization target F1:
directed monoid normalization through the right-comb normal form,
with uniqueness of normal forms and confluence.

This file is dependency-free Lean 4 (no mathlib). It formalizes exactly the
theorem sequence declared in formal/README.md:

  step_decreases       : Step s t -> interp t < interp s
  normal_rightComb     : Normal (rightComb w)
  normalization_sound  : StepStar s n -> Normal n -> n = rightComb (flatten s)
  confluence           : StepStar s u -> StepStar s v ->
                           exists n, StepStar u n /\ StepStar v n

together with the supporting progress and existence lemmas. The Python kernel's
MonoidNormalizationCertificate checks concrete instances of normalization_sound;
this file proves the statement for every ground term over any atom type.

Author: Benjamin John Schulz
-/

namespace Metasketch

/-- Ground monoid terms over an atom type `α`: the unit `e`, atoms, and the
binary product `m`. This mirrors the Python fragment recognized by
`is_ground_monoid_term`. -/
inductive MTerm (α : Type) where
  | e : MTerm α
  | atom : α → MTerm α
  | m : MTerm α → MTerm α → MTerm α
deriving Repr, DecidableEq

variable {α : Type}

/-- One directed rewrite step: the three oriented monoid rules
`alpha`, `lam`, `rho` closed under congruence in both arguments of `m`. -/
inductive Step : MTerm α → MTerm α → Prop where
  | alpha (x y z : MTerm α) : Step (.m (.m x y) z) (.m x (.m y z))
  | lam (x : MTerm α) : Step (.m .e x) x
  | rho (x : MTerm α) : Step (.m x .e) x
  | congL {x x' : MTerm α} (y : MTerm α) : Step x x' → Step (.m x y) (.m x' y)
  | congR (x : MTerm α) {y y' : MTerm α} : Step y y' → Step (.m x y) (.m x y')

/-- Reflexive-transitive closure of `Step`. -/
inductive StepStar : MTerm α → MTerm α → Prop where
  | refl (t : MTerm α) : StepStar t t
  | tail {s t u : MTerm α} : StepStar s t → Step t u → StepStar s u

/-- A term is normal when no directed rule applies anywhere. -/
def Normal (t : MTerm α) : Prop := ∀ u, ¬ Step t u

/-- The unit-free leaf word of a ground term (Python: `flatten_word`). -/
def flatten : MTerm α → List α
  | .e => []
  | .atom a => [a]
  | .m x y => flatten x ++ flatten y

/-- The canonical right-associated product of a unit-free word
(Python: `right_comb`). -/
def rightComb : List α → MTerm α
  | [] => .e
  | [a] => .atom a
  | a :: b :: rest => .m (.atom a) (rightComb (b :: rest))

/-- The strict polynomial interpretation used for termination
(Python: `interp`): `I(e) = I(atom) = 1`, `I(m x y) = 2 I(x) + I(y)`. -/
def interp : MTerm α → Nat
  | .e => 1
  | .atom _ => 1
  | .m x y => 2 * interp x + interp y

theorem interp_pos (t : MTerm α) : 1 ≤ interp t := by
  induction t with
  | e => exact Nat.le_refl 1
  | atom a => exact Nat.le_refl 1
  | m x y ihx ihy => simp only [interp]; omega

/-- Theorem `step_decreases`: every directed rule strictly decreases the
polynomial interpretation, so the presentation terminates. -/
theorem step_decreases {s t : MTerm α} (h : Step s t) : interp t < interp s := by
  induction h with
  | alpha x y z =>
      have hx := interp_pos x
      simp only [interp]; omega
  | lam x => simp only [interp]; omega
  | rho x => have hx := interp_pos x; simp only [interp]; omega
  | congL y _ ih => simp only [interp]; omega
  | congR x _ ih => simp only [interp]; omega

/-- Every directed rule preserves the unit-free leaf word. -/
theorem flatten_step {s t : MTerm α} (h : Step s t) : flatten t = flatten s := by
  induction h with
  | alpha x y z => simp [flatten, List.append_assoc]
  | lam x => simp [flatten]
  | rho x => simp [flatten]
  | congL y _ ih => simp [flatten, ih]
  | congR x _ ih => simp [flatten, ih]

theorem flatten_stepStar {s t : MTerm α} (h : StepStar s t) :
    flatten t = flatten s := by
  induction h with
  | refl => rfl
  | tail _ hstep ih => rw [flatten_step hstep, ih]

/-- `e` and atoms are normal. -/
theorem normal_e : Normal (.e : MTerm α) := by
  intro u h; cases h

theorem normal_atom (a : α) : Normal (.atom a : MTerm α) := by
  intro u h; cases h

theorem rightComb_ne_e_of_cons (a : α) (rest : List α) :
    rightComb (a :: rest) ≠ (.e : MTerm α) := by
  cases rest with
  | nil => simp [rightComb]
  | cons b rest' => simp [rightComb]

/-- The key closure lemma: prefixing a normal non-unit term with one atom
under `m` stays normal. -/
theorem normal_m_atom (a : α) {y : MTerm α} (hy : Normal y) (hne : y ≠ .e) :
    Normal (.m (.atom a) y) := by
  intro u h
  cases h with
  | rho x => exact hne rfl
  | congL _ hstep => cases hstep
  | congR _ hstep => exact hy _ hstep

/-- Theorem `normal_rightComb`: every right comb is a normal form. -/
theorem normal_rightComb (w : List α) : Normal (rightComb w) := by
  induction w with
  | nil => exact normal_e
  | cons a rest ih =>
      cases rest with
      | nil => exact normal_atom a
      | cons b rest' =>
          exact normal_m_atom a ih (rightComb_ne_e_of_cons b rest')

/-- Progress: every term is normal or takes a step. Proved constructively,
mirroring the outermost-leftmost strategy of the Python normalizer. -/
theorem progress (s : MTerm α) : Normal s ∨ ∃ t, Step s t := by
  induction s with
  | e => exact Or.inl normal_e
  | atom a => exact Or.inl (normal_atom a)
  | m x y ihx ihy =>
      cases x with
      | e => exact Or.inr ⟨y, Step.lam y⟩
      | m x1 x2 => exact Or.inr ⟨.m x1 (.m x2 y), Step.alpha x1 x2 y⟩
      | atom a =>
          cases ihy with
          | inr hstep =>
              obtain ⟨y', hy'⟩ := hstep
              exact Or.inr ⟨.m (.atom a) y', Step.congR _ hy'⟩
          | inl hnormal =>
              by_cases he : y = .e
              · subst he; exact Or.inr ⟨.atom a, Step.rho _⟩
              · exact Or.inl (normal_m_atom a hnormal he)

theorem stepStar_head {s t u : MTerm α} (h1 : Step s t) (h2 : StepStar t u) :
    StepStar s u := by
  induction h2 with
  | refl => exact StepStar.tail (StepStar.refl s) h1
  | tail _ hstep ih => exact StepStar.tail ih hstep

/-- Existence: every term reduces to some normal form. Strong induction on the
polynomial interpretation, using `progress` and `step_decreases`. -/
theorem exists_normal (s : MTerm α) : ∃ n, StepStar s n ∧ Normal n := by
  cases progress s with
  | inl hnormal => exact ⟨s, StepStar.refl s, hnormal⟩
  | inr hstep =>
      obtain ⟨t, ht⟩ := hstep
      obtain ⟨n, hstar, hnormal⟩ := exists_normal t
      exact ⟨n, stepStar_head ht hstar, hnormal⟩
termination_by interp s
decreasing_by exact step_decreases ht

/-- Normal terms are exactly the right combs of their own leaf words. -/
theorem normal_eq_rightComb {n : MTerm α} (h : Normal n) :
    n = rightComb (flatten n) := by
  induction n with
  | e => rfl
  | atom a => rfl
  | m x y ihx ihy =>
      -- The left factor of a normal product must be an atom.
      cases x with
      | e => exact absurd (Step.lam y) (h _)
      | m x1 x2 => exact absurd (Step.alpha x1 x2 y) (h _)
      | atom a =>
          have hy : Normal y := fun u hu => h _ (Step.congR _ hu)
          have hyne : y ≠ .e := by
            intro he; subst he; exact h _ (Step.rho _)
          have hy_eq := ihy hy
          -- A normal non-unit term has a nonempty leaf word.
          have hflat : flatten y ≠ [] := by
            intro hnil
            rw [hnil] at hy_eq
            exact hyne hy_eq
          obtain ⟨b, rest, hcons⟩ : ∃ b rest, flatten y = b :: rest := by
            cases hf : flatten y with
            | nil => exact absurd hf hflat
            | cons b rest => exact ⟨b, rest, rfl⟩
          show MTerm.m (.atom a) y = rightComb (flatten (.m (.atom a) y))
          have : flatten (MTerm.m (.atom a) y) = a :: b :: rest := by
            simp [flatten, hcons]
          rw [this, rightComb, ← hcons, ← hy_eq]

/-- Theorem `normalization_sound`: any normal form reached from `s` is the
right comb of the unit-free leaf word of `s`. This is the statement checked
per instance by the Python `MonoidNormalizationCertificate`. -/
theorem normalization_sound {s n : MTerm α} (hstar : StepStar s n)
    (hnormal : Normal n) : n = rightComb (flatten s) := by
  rw [normal_eq_rightComb hnormal, flatten_stepStar hstar]

/-- Normal forms are unique. -/
theorem normal_unique {s n₁ n₂ : MTerm α} (h₁ : StepStar s n₁) (hn₁ : Normal n₁)
    (h₂ : StepStar s n₂) (hn₂ : Normal n₂) : n₁ = n₂ := by
  rw [normalization_sound h₁ hn₁, normalization_sound h₂ hn₂]

/-- Theorem `confluence`: any two reducts of a common source rejoin. Derived
from termination and uniqueness of the right-comb target, exactly the route
recommended in formal/README.md. -/
theorem confluence {s u v : MTerm α} (hu : StepStar s u) (hv : StepStar s v) :
    ∃ n, StepStar u n ∧ StepStar v n := by
  obtain ⟨nu, hu_star, hu_normal⟩ := exists_normal u
  obtain ⟨nv, hv_star, hv_normal⟩ := exists_normal v
  have : nu = nv := by
    have h1 : nu = rightComb (flatten u) := normalization_sound hu_star hu_normal
    have h2 : nv = rightComb (flatten v) := normalization_sound hv_star hv_normal
    rw [h1, h2, flatten_stepStar hu, flatten_stepStar hv]
  exact ⟨nu, hu_star, this ▸ hv_star⟩

/-! ## Fixture cross-checks

Concrete instances matching `formal/fixtures/finite_core_v1.json`. The pentagon
source `m(m(m(a,b),c),d)` over four distinct atoms, and `m(m(a,b),e)`. Both
right-comb targets are computed by `rfl`, tying the Lean definitions to the
Python fixture oracle. -/

section Fixtures

/-- Pentagon source over atoms 0,1,2,3 standing for a,b,c,d. -/
def pentagonSource : MTerm Nat :=
  .m (.m (.m (.atom 0) (.atom 1)) (.atom 2)) (.atom 3)

example : flatten pentagonSource = [0, 1, 2, 3] := rfl

example : rightComb (flatten pentagonSource) =
    .m (.atom 0) (.m (.atom 1) (.m (.atom 2) (.atom 3))) := rfl

/-- Second fixture source `m(m(a,b),e)` over atoms 0,1 standing for a,b. -/
def unitTailSource : MTerm Nat := .m (.m (.atom 0) (.atom 1)) .e

example : rightComb (flatten unitTailSource) = .m (.atom 0) (.atom 1) := rfl

end Fixtures

end Metasketch
