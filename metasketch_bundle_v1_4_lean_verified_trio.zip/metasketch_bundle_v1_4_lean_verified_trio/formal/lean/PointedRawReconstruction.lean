/-
Metasketch finite core, formalization target F2 (evidence core):
pointed raw-certificate reconstruction.

This dependency-free Lean 4 file isolates the mathematical kernel of the Python
Phase 6--7 checker. A raw certificate contributes three finite evidence sources:
relation-fact occurrences, hidden-witness binders, and pointed visible-boundary
assignments. Once every pattern variable has evidence and all evidence for a
fixed variable agrees, the certificate determines a unique assignment.

The file deliberately stops at the evidence-reconstruction layer. Relation
membership, raw proof-tree parsing, atom-index coverage, binder-spine shape, and
sort checking are validated by the Python front end before a certificate is
translated into this core. The main theorem here is therefore not a claim about
arbitrary regular-logic derivations. It proves the F2 uniqueness kernel used by
accepted finite pointed raw certificates.

Target statements:

  reconstruct_realizes_evidence
  reconstruct_unique
  reconstruct_realizes_atomEvidence
  reconstruct_realizes_binderEvidence
  reconstruct_realizes_boundaryEvidence
  reconstruct_erase

No external dependencies and no axioms beyond Lean's standard foundations.
-/

namespace Metasketch

universe u v

variable {Var : Type u} {Val : Type v}

/-- A finite multiset-like list of variable/value constraints. Repeated entries
are allowed: raw fact leaves can mention a variable in several atoms. -/
structure Evidence (Var : Type u) (Val : Type v) where
  entries : List (Var × Val)

/-- A candidate semantic witness assignment. -/
abbrev Assignment (Var : Type u) (Val : Type v) := Var → Val

/-- A variable/value pair occurs in an evidence bundle. -/
def Occurs (E : Evidence Var Val) (x : Var) (a : Val) : Prop :=
  (x, a) ∈ E.entries

/-- Every pattern variable is forced by at least one evidence entry. -/
def Covers (E : Evidence Var Val) : Prop :=
  ∀ x : Var, ∃ a : Val, Occurs E x a

/-- All evidence entries for one variable agree. -/
def Consistent (E : Evidence Var Val) : Prop :=
  ∀ {x : Var} {a b : Val}, Occurs E x a → Occurs E x b → a = b

/-- An assignment realizes an evidence bundle when it agrees with every entry. -/
def Realizes (E : Evidence Var Val) (μ : Assignment Var Val) : Prop :=
  ∀ {x : Var} {a : Val}, Occurs E x a → μ x = a

/-- Reconstruct an assignment by choosing the value supplied by coverage for each
variable. Consistency makes that choice independent of the selected occurrence. -/
noncomputable def reconstruct (E : Evidence Var Val) (hcover : Covers E) :
    Assignment Var Val :=
  fun x => Classical.choose (hcover x)

/-- The chosen reconstructed value is one of the raw evidence values. -/
theorem reconstruct_occurs (E : Evidence Var Val) (hcover : Covers E) (x : Var) :
    Occurs E x (reconstruct E hcover x) := by
  exact Classical.choose_spec (hcover x)

/-- F2 core, existence direction: reconstruction realizes every accepted piece
of evidence. -/
theorem reconstruct_realizes_evidence (E : Evidence Var Val)
    (hcover : Covers E) (hconsistent : Consistent E) :
    Realizes E (reconstruct E hcover) := by
  intro x a hoccurs
  exact hconsistent (reconstruct_occurs E hcover x) hoccurs

/-- F2 core, uniqueness direction: any assignment realizing the same complete,
consistent evidence must equal the reconstructed assignment. -/
theorem reconstruct_unique (E : Evidence Var Val)
    (hcover : Covers E) (_hconsistent : Consistent E)
    {μ : Assignment Var Val} (hμ : Realizes E μ) :
    μ = reconstruct E hcover := by
  funext x
  exact hμ (reconstruct_occurs E hcover x)

/-- A pointed raw certificate has the three evidence sources used by the Python
checker. The atom source is extracted from checked relation-fact leaves; the
binder source from one outer hidden-witness spine; and the boundary source from
visible variables that do not occur in the relation matrix. -/
structure PointedRawCertificate (Var : Type u) (Val : Type v) where
  atomEvidence : Evidence Var Val
  binderEvidence : Evidence Var Val
  boundaryEvidence : Evidence Var Val

/-- Forget source tags only for reconstruction. Source-specific realization
lemmas below preserve the distinction needed by the visual/proof layer. -/
def PointedRawCertificate.allEvidence (ρ : PointedRawCertificate Var Val) :
    Evidence Var Val :=
  ⟨(ρ.atomEvidence.entries ++ ρ.binderEvidence.entries) ++ ρ.boundaryEvidence.entries⟩

/-- An accepted raw certificate is precisely one whose combined evidence covers
all declared variables and is consistent. Structural front-end checks that
produce this record remain separate: relation membership, arities, sorts,
atom coverage, and outer-binder scope are intentionally not redefined here. -/
structure AcceptedPointedRawCertificate (Var : Type u) (Val : Type v) where
  raw : PointedRawCertificate Var Val
  covers : Covers raw.allEvidence
  consistent : Consistent raw.allEvidence

/-- The semantic witness reconstructed from an accepted pointed raw certificate. -/
noncomputable def AcceptedPointedRawCertificate.reconstruct
    (ρ : AcceptedPointedRawCertificate Var Val) : Assignment Var Val :=
  Metasketch.reconstruct ρ.raw.allEvidence ρ.covers

/-- Inclusion of source-specific atom evidence in the combined evidence. -/
theorem atomEvidence_in_all {ρ : PointedRawCertificate Var Val}
    {x : Var} {a : Val} (h : Occurs ρ.atomEvidence x a) :
    Occurs ρ.allEvidence x a := by
  simp only [Occurs, PointedRawCertificate.allEvidence, List.mem_append] at h ⊢
  exact Or.inl (Or.inl h)

/-- Inclusion of source-specific hidden-binder evidence in the combined evidence. -/
theorem binderEvidence_in_all {ρ : PointedRawCertificate Var Val}
    {x : Var} {a : Val} (h : Occurs ρ.binderEvidence x a) :
    Occurs ρ.allEvidence x a := by
  simp only [Occurs, PointedRawCertificate.allEvidence, List.mem_append] at h ⊢
  exact Or.inl (Or.inr h)

/-- Inclusion of source-specific visible-boundary evidence in the combined evidence. -/
theorem boundaryEvidence_in_all {ρ : PointedRawCertificate Var Val}
    {x : Var} {a : Val} (h : Occurs ρ.boundaryEvidence x a) :
    Occurs ρ.allEvidence x a := by
  simp only [Occurs, PointedRawCertificate.allEvidence, List.mem_append] at h ⊢
  exact Or.inr h

/-- The reconstructed witness realizes all combined evidence. -/
theorem pointed_reconstruct_realizes_all
    (ρ : AcceptedPointedRawCertificate Var Val) :
    Realizes ρ.raw.allEvidence ρ.reconstruct := by
  exact reconstruct_realizes_evidence ρ.raw.allEvidence ρ.covers ρ.consistent

/-- F2 source-specific evidence theorem: every accepted atom fact is realized by
reconstruction. Relation membership itself is a checked front-end premise. -/
theorem reconstruct_realizes_atomEvidence
    (ρ : AcceptedPointedRawCertificate Var Val)
    {x : Var} {a : Val} (h : Occurs ρ.raw.atomEvidence x a) :
    ρ.reconstruct x = a := by
  exact pointed_reconstruct_realizes_all ρ (atomEvidence_in_all h)

/-- Every accepted hidden witness is realized by reconstruction. -/
theorem reconstruct_realizes_binderEvidence
    (ρ : AcceptedPointedRawCertificate Var Val)
    {x : Var} {a : Val} (h : Occurs ρ.raw.binderEvidence x a) :
    ρ.reconstruct x = a := by
  exact pointed_reconstruct_realizes_all ρ (binderEvidence_in_all h)

/-- Every accepted pointed boundary value is realized by reconstruction. -/
theorem reconstruct_realizes_boundaryEvidence
    (ρ : AcceptedPointedRawCertificate Var Val)
    {x : Var} {a : Val} (h : Occurs ρ.raw.boundaryEvidence x a) :
    ρ.reconstruct x = a := by
  exact pointed_reconstruct_realizes_all ρ (boundaryEvidence_in_all h)

/-- F2 uniqueness theorem for pointed raw certificates. Any candidate witness
that realizes all atom, binder, and boundary evidence is the reconstructed
witness. -/
theorem pointed_reconstruct_unique
    (ρ : AcceptedPointedRawCertificate Var Val)
    {μ : Assignment Var Val} (hμ : Realizes ρ.raw.allEvidence μ) :
    μ = ρ.reconstruct := by
  exact reconstruct_unique ρ.raw.allEvidence ρ.covers ρ.consistent hμ

/-- Evidence emitted by canonically erasing one assignment over a variable list. -/
def evidenceOfAssignment (vars : List Var) (μ : Assignment Var Val) :
    Evidence Var Val :=
  ⟨vars.map (fun x => (x, μ x))⟩

/-- A source partition records where a canonical erasure places the value of each
pattern variable. It abstracts the Python distinction between values witnessed
in atom leaves, values named by hidden binders, and values carried at the visible
boundary. Disjointness is not required for uniqueness; repeated equal evidence
is allowed. -/
structure EvidencePartition (Var : Type u) where
  atomVars : List Var
  hiddenVars : List Var
  boundaryVars : List Var
  covers : ∀ x : Var,
    x ∈ atomVars ∨ x ∈ hiddenVars ∨ x ∈ boundaryVars

/-- Canonically erase an assignment into the three pointed raw evidence sources. -/
def erasePointed (part : EvidencePartition Var) (μ : Assignment Var Val) :
    PointedRawCertificate Var Val where
  atomEvidence := evidenceOfAssignment part.atomVars μ
  binderEvidence := evidenceOfAssignment part.hiddenVars μ
  boundaryEvidence := evidenceOfAssignment part.boundaryVars μ

/-- Every entry in assignment-generated evidence carries exactly the assigned
value. -/
theorem evidenceOfAssignment_value {vars : List Var} {μ : Assignment Var Val}
    {x : Var} {a : Val} (h : Occurs (evidenceOfAssignment vars μ) x a) :
    a = μ x := by
  change (x, a) ∈ vars.map (fun y => (y, μ y)) at h
  rw [List.mem_map] at h
  obtain ⟨y, hy, hpair⟩ := h
  cases hpair
  rfl

/-- Every entry in the three-source erasure carries exactly the original value. -/
theorem erasePointed_value (part : EvidencePartition Var) (μ : Assignment Var Val)
    {x : Var} {a : Val} (h : Occurs (erasePointed part μ).allEvidence x a) :
    a = μ x := by
  change (x, a) ∈
    ((part.atomVars.map (fun y => (y, μ y)) ++
      part.hiddenVars.map (fun y => (y, μ y))) ++
      part.boundaryVars.map (fun y => (y, μ y))) at h
  simp only [List.mem_append] at h
  rcases h with hab | hboundary
  · rcases hab with hatom | hhidden
    · exact evidenceOfAssignment_value hatom
    · exact evidenceOfAssignment_value hhidden
  · exact evidenceOfAssignment_value hboundary

/-- Erasure covers every declared variable. -/
theorem erasePointed_covers (part : EvidencePartition Var) (μ : Assignment Var Val) :
    Covers (erasePointed part μ).allEvidence := by
  intro x
  rcases part.covers x with hatom | hhidden | hboundary
  · refine ⟨μ x, ?_⟩
    change (x, μ x) ∈
      ((part.atomVars.map (fun y => (y, μ y)) ++
        part.hiddenVars.map (fun y => (y, μ y))) ++
        part.boundaryVars.map (fun y => (y, μ y)))
    simp only [List.mem_append, List.mem_map]
    exact Or.inl (Or.inl ⟨x, hatom, rfl⟩)
  · refine ⟨μ x, ?_⟩
    change (x, μ x) ∈
      ((part.atomVars.map (fun y => (y, μ y)) ++
        part.hiddenVars.map (fun y => (y, μ y))) ++
        part.boundaryVars.map (fun y => (y, μ y)))
    simp only [List.mem_append, List.mem_map]
    exact Or.inl (Or.inr ⟨x, hhidden, rfl⟩)
  · refine ⟨μ x, ?_⟩
    change (x, μ x) ∈
      ((part.atomVars.map (fun y => (y, μ y)) ++
        part.hiddenVars.map (fun y => (y, μ y))) ++
        part.boundaryVars.map (fun y => (y, μ y)))
    simp only [List.mem_append, List.mem_map]
    exact Or.inr ⟨x, hboundary, rfl⟩

/-- Erasure is consistent because all three sources were generated from one
assignment. -/
theorem erasePointed_consistent (part : EvidencePartition Var)
    (μ : Assignment Var Val) :
    Consistent (erasePointed part μ).allEvidence := by
  intro x a b ha hb
  exact (erasePointed_value part μ ha).trans (erasePointed_value part μ hb).symm

/-- Package a canonical erasure as an accepted pointed raw certificate. -/
noncomputable def eraseAccepted (part : EvidencePartition Var)
    (μ : Assignment Var Val) : AcceptedPointedRawCertificate Var Val where
  raw := erasePointed part μ
  covers := erasePointed_covers part μ
  consistent := erasePointed_consistent part μ

/-- F2 round-trip theorem: canonical erasure followed by pointed reconstruction
returns the original assignment. This is the Lean counterpart of the Python
`raw_certificate_from_proof` / `reconstruct_raw_match` identity, at the evidence
core after the front end has extracted atom, binder, and boundary assignments. -/
theorem reconstruct_erase (part : EvidencePartition Var) (μ : Assignment Var Val) :
    (eraseAccepted part μ).reconstruct = μ := by
  symm
  apply pointed_reconstruct_unique (eraseAccepted part μ)
  intro x a h
  exact (erasePointed_value part μ h).symm

/-! ## Small concrete sanity instances

These examples are theorem-checked terms, not finite exhaustive audits. They
mirror the two F2 shapes used by the Python tests: an anchored fact/binder case
and a purely pointed visible-boundary case. -/

section Examples

inductive ExampleVar where
  | p | c
  deriving DecidableEq, Repr

inductive ExampleVal where
  | u | v | city1
  deriving DecidableEq, Repr

open ExampleVar ExampleVal

/-- `p` is atom-anchored and `c` is hidden/binder-anchored. -/
def anchoredPartition : EvidencePartition ExampleVar where
  atomVars := [p]
  hiddenVars := [c]
  boundaryVars := []
  covers := by
    intro x
    cases x with
    | p => exact Or.inl (by simp)
    | c => exact Or.inr (Or.inl (by simp))

/-- A concrete candidate assignment. -/
def anchoredAssignment : Assignment ExampleVar ExampleVal
  | p => u
  | c => city1

example : (eraseAccepted anchoredPartition anchoredAssignment).reconstruct =
    anchoredAssignment := reconstruct_erase anchoredPartition anchoredAssignment

/-- `p` is a free visible input for the empty conjunction, hence its value lives
at the pointed boundary rather than in a relation-fact source. -/
def boundaryPartition : EvidencePartition ExampleVar where
  atomVars := []
  hiddenVars := []
  boundaryVars := [p, c]
  covers := by
    intro x
    cases x with
    | p => exact Or.inr (Or.inr (by simp))
    | c => exact Or.inr (Or.inr (by simp))

example : (eraseAccepted boundaryPartition anchoredAssignment).reconstruct =
    anchoredAssignment := reconstruct_erase boundaryPartition anchoredAssignment

end Examples

end Metasketch
