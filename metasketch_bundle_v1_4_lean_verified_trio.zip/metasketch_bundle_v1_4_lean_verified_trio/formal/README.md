# Metasketch finite-core formalization plan and F1 verification

Status as of v1.4: **F1, F2, and F3 are machine-checked in Lean 4** with no
external dependencies (v4.31.0, core only, no mathlib, no `sorry`). The proofs
live in `lean/MonoidNormalization.lean`, `lean/PointedRawReconstruction.lean`,
and `lean/ReflectionSafety.lean`; the compiler version, theorem lists, and
axiom footprints are recorded in `lean/VERIFICATION.txt`, and
`lean/verify.sh` reproduces the full three-file check. Each verification has a
declared scope: F1 covers the ground monoid fragment at full generality; F2
covers the evidence-reconstruction layer only, with relation membership, atom
coverage, binder-spine shape, arities, sorts, and finite-model enumeration
remaining Python front-end premises; F3 covers the declared interface grammar,
the same-level Boolean diagonal, and typed cross-level predicate codes. The
full F2 relation/model front end remains an open formalization target, and for
those front-end claims the Python certificate checkers remain the strongest
available evidence.

The runnable Python kernel supplies independently replayable finite certificates.
The companion JSON fixtures are language-neutral regression oracles; they are
not proof objects for a general theorem. As of v1.1 the shipped fixture file is
itself re-parsed and replayed by the Python regression suite, so the oracle
cannot silently drift from the checker.

## Formalization order

### F1. Directed monoid normalization (VERIFIED, Lean 4, v1.1)

Define ground terms:

\[
t ::= e \mid a \mid m(t,t),
\]

with the directed rewrite rules

\[
m(m(x,y),z)\to m(x,m(y,z)),\qquad m(e,x)\to x,\qquad m(x,e)\to x.
\]

Formalize:

```text
flatten    : MTerm α → List α
rightComb  : List α → MTerm α
Step       : MTerm α → MTerm α → Prop
Normal     : MTerm α → Prop
```

The theorem sequence is:

```text
step_decreases:
  Step s t → I t < I s

normal_rightComb:
  Normal (rightComb w)

normalization_sound:
  StepStar s n → Normal n → n = rightComb (flatten s)

confluence:
  StepStar s u → StepStar s v → ∃n, StepStar u n ∧ StepStar v n
```

A direct proof of `normalization_sound` through the `flatten` invariant is
simpler than importing a general critical-pair or Newman's-lemma library, and
this is the route the Lean development takes: `flatten` is a step invariant,
normal terms are exactly the right combs of their own leaf words, and
confluence follows because every normalizing path has the same right-comb
target. All four theorems above, plus `progress`, `exists_normal`, and
`normal_unique`, are proved in `lean/MonoidNormalization.lean` over an
arbitrary atom type. The Python `MonoidNormalizationCertificate` continues to
check concrete instances of the same statement.

### F2. Pointed raw-certificate reconstruction (VERIFIED at the evidence core, Lean 4, v1.4)

`lean/PointedRawReconstruction.lean` now formalizes the uniqueness kernel of
F2. It represents a pointed raw certificate as three source-tagged evidence
bundles: relation-fact occurrences, hidden-witness binders, and visible boundary
assignments. An accepted certificate has complete and consistent combined
evidence. The source proves:

```text
reconstruct_realizes_evidence
reconstruct_unique
reconstruct_realizes_atomEvidence
reconstruct_realizes_binderEvidence
reconstruct_realizes_boundaryEvidence
reconstruct_erase
```

This is intentionally the *evidence-reconstruction layer*. It proves that any
complete, consistent evidence package determines exactly one assignment and that
canonical three-source erasure round-trips. Relation membership, atom-index
coverage, raw-tree parsing, binder-spine scope, arity, sort checks, and finite
model enumeration remain in the Python front end. The source was compiled and
verified in the v1.4 environment after three proof-script repairs; see
`lean/F2_STATUS.txt` for the itemized repairs and axiom footprint.

The Python `PointedReconstructionCertificate` continues to recompute all finite
semantic realizers and requires singleton uniqueness for each concrete instance.

## Fixture contract

`fixtures/finite_core_v1.json` encodes two monoid-normalization certificates and
one pointed raw-reconstruction certificate. A formalization should parse the
fixture syntax into its own term and certificate types, then prove that each
fixture is accepted by the trusted checker. Fixtures validate translation and
implementation agreement. They do not substitute for quantifier-level proofs.

## Reflection boundary

The formalization should not start by encoding Program E or a total truth
predicate. Quotation and proof checking remain typed, level-raising interfaces.
The first reflection formalization goal is only a type-safety theorem:

```text
sameLevelTruthCallIsIllTyped : ¬ WellTyped (eval_k code_k argument_k)
```

when the code/argument levels do not match the declared `eval_{k+1→k}`
interface. This is a type-discipline theorem, not Tarski's theorem or Lawvere's
theorem.


### F3. Typed reflection-interface safety (VERIFIED, Lean 4, v1.4)

`lean/ReflectionSafety.lean` formalizes the narrow Program E boundary used by
the Metasketch membrane:

```text
safeInterface_no_sameLevel_total_complete_truth
sameLevel_not_representationComplete
evalPredicate_correct
crossLevel_representation_complete
```

The source separates three ideas that must not be conflated: a declared safe
interface grammar, the Boolean diagonal obstruction for a same-level
representation-complete evaluator, and legal predicate completeness across a
strict level gap.  It does not encode a universal evaluator, semantic truth,
Tarski's theorem, or Lawvere's theorem.  The source compiled as shipped and is
machine-checked; `evalPredicate_correct` and
`crossLevel_representation_complete` depend on no axioms at all.  See
`lean/F3_STATUS.txt`.
