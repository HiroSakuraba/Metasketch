"""Experimental raw abstract syntax.

This module deliberately exposes lightweight constructors for research
experiments.  Objects built here are *not* trusted automatically.  Pass them
through ``metasketch0.api`` before sending them to the renderer, quotation
layer, finite-model semantics, or theorem-facing certificate machinery.
"""

from .syntax import *  # noqa: F401,F403
