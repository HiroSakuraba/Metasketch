"""CLI for generating Metasketch v0.6.1 semantic-renderer showcase SVGs."""

from __future__ import annotations

import argparse
from pathlib import Path

from .showcases import write_showcase_gallery


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="rendered_examples", help="output directory")
    args = parser.parse_args()
    outputs = write_showcase_gallery(Path(args.out))
    for name, path in outputs.items():
        print(f"{name}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
