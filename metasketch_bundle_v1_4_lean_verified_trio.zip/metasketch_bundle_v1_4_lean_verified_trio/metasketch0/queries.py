"""Finite directed-graph pattern queries for Metasketch Phase 3.

A finite pattern graph P compiles to an existential-conjunctive query.  Its
visible vertices become free variables; its hidden vertices become existential
witnesses.  A graph-pattern match is a homomorphism P -> G.  This module keeps
those three descriptions aligned:

  pattern graph -> regular-logic predicate -> finite witness map.

The code intentionally handles only finite directed graphs and conjunctive
queries.  That is the regular-logic core needed for the first Phase 3 result.
"""

from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from typing import Dict, FrozenSet, Iterable, Mapping, Sequence, Tuple

from .semantics import FiniteModel
from .syntax import And, Context, Exists, Pred, Rel, Sort, Top, Var, v


@dataclass(frozen=True)
class PatternGraph:
    """A finite directed pattern with named visible vertices.

    Vertices are names local to the pattern.  A match need not be injective,
    exactly as for ordinary graph homomorphisms and conjunctive-query matches.
    """

    name: str
    vertices: Tuple[str, ...]
    edges: Tuple[Tuple[str, str], ...]
    visible: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("pattern must have a nonempty name")
        if len(set(self.vertices)) != len(self.vertices):
            raise ValueError("pattern vertices must have distinct names")
        if len(set(self.visible)) != len(self.visible):
            raise ValueError("visible vertices must have distinct names")
        vertices = set(self.vertices)
        if not set(self.visible) <= vertices:
            raise ValueError("every visible vertex must be a pattern vertex")
        for edge in self.edges:
            if len(edge) != 2 or edge[0] not in vertices or edge[1] not in vertices:
                raise ValueError(f"edge {edge!r} does not lie in the pattern vertex set")

    @property
    def hidden(self) -> Tuple[str, ...]:
        return tuple(vertex for vertex in self.vertices if vertex not in self.visible)


@dataclass(frozen=True)
class FiniteDirectedGraph:
    """A finite directed graph, represented by a vertex tuple and edge set."""

    name: str
    vertices: Tuple[object, ...]
    edges: FrozenSet[Tuple[object, object]]

    def __post_init__(self) -> None:
        if len(set(self.vertices)) != len(self.vertices):
            raise ValueError("graph vertices must be distinct and hashable")
        vertex_set = set(self.vertices)
        for edge in self.edges:
            if len(edge) != 2 or edge[0] not in vertex_set or edge[1] not in vertex_set:
                raise ValueError(f"edge {edge!r} is not a pair of graph vertices")


@dataclass(frozen=True)
class GraphHomomorphism:
    """A total edge-preserving map between finite directed graphs."""

    name: str
    source: FiniteDirectedGraph
    target: FiniteDirectedGraph
    mapping: Tuple[Tuple[object, object], ...]

    def __post_init__(self) -> None:
        names = [src for src, _ in self.mapping]
        if len(set(names)) != len(names):
            raise ValueError("graph homomorphism mapping has duplicate source vertices")
        source_set = set(self.source.vertices)
        if set(names) != source_set:
            raise ValueError("graph homomorphism must map every source vertex exactly once")
        target_set = set(self.target.vertices)
        table = self.as_dict()
        if any(value not in target_set for value in table.values()):
            raise ValueError("graph homomorphism maps outside its target graph")
        for u, vtx in self.source.edges:
            if (table[u], table[vtx]) not in self.target.edges:
                raise ValueError(
                    f"mapping is not edge-preserving: {(u, vtx)!r} maps to "
                    f"{(table[u], table[vtx])!r}"
                )

    def as_dict(self) -> Dict[object, object]:
        return dict(self.mapping)

    def apply(self, vertex: object) -> object:
        return self.as_dict()[vertex]


@dataclass(frozen=True)
class PatternMatch:
    """A graph homomorphism from one pattern graph into one finite graph."""

    pattern: PatternGraph
    graph: FiniteDirectedGraph
    mapping: Tuple[Tuple[str, object], ...]

    def __post_init__(self) -> None:
        labels = [label for label, _ in self.mapping]
        if len(set(labels)) != len(labels):
            raise ValueError("pattern match has duplicate pattern vertices")
        if set(labels) != set(self.pattern.vertices):
            raise ValueError("pattern match must assign every pattern vertex exactly once")
        table = self.as_dict()
        vertex_set = set(self.graph.vertices)
        if any(value not in vertex_set for value in table.values()):
            raise ValueError("pattern match maps outside the graph")
        for u, vtx in self.pattern.edges:
            if (table[u], table[vtx]) not in self.graph.edges:
                raise ValueError(
                    f"pattern edge {(u, vtx)!r} is not preserved by the match"
                )

    def as_dict(self) -> Dict[str, object]:
        return dict(self.mapping)

    def visible_assignment(self) -> Dict[str, object]:
        table = self.as_dict()
        return {label: table[label] for label in self.pattern.visible}


@dataclass(frozen=True)
class CompiledQuery:
    """One pattern graph compiled into a regular-logic predicate."""

    pattern: PatternGraph
    context: Context
    predicate: Pred
    vertex_variables: Tuple[Tuple[str, Var], ...]

    def var_for(self, vertex: str) -> Var:
        return dict(self.vertex_variables)[vertex]


def _fresh_name(stem: str, forbidden: Iterable[str]) -> str:
    forbidden_set = set(forbidden)
    candidate = stem
    index = 0
    while candidate in forbidden_set:
        candidate = f"{stem}_{index}"
        index += 1
    return candidate


def _and_all(predicates: Sequence[Pred]) -> Pred:
    if not predicates:
        return Top()
    current = predicates[0]
    for predicate in predicates[1:]:
        current = And(current, predicate)
    return current


def compile_conjunctive_query(
    pattern: PatternGraph,
    *,
    visible_vars: Mapping[str, Var],
    vertex_sort: Sort,
    edge_relation: str,
    witness_prefix: str = "w",
) -> CompiledQuery:
    """Compile a pattern to an existential-conjunctive graph query.

    `visible_vars` must assign exactly the visible pattern vertices.  Hidden
    vertices receive fresh variables of `vertex_sort`, then are existentially
    bound.  The order of binders is deterministic from `pattern.vertices`.
    """

    if set(visible_vars) != set(pattern.visible):
        raise ValueError("visible_vars must assign exactly the visible pattern vertices")
    if any(var.sort != vertex_sort for var in visible_vars.values()):
        raise ValueError("all visible query variables must have the graph vertex sort")
    if len({var.name for var in visible_vars.values()}) != len(visible_vars):
        raise ValueError("visible query variables must have distinct names")

    variables: Dict[str, Var] = dict(visible_vars)
    forbidden_names = {var.name for var in variables.values()}
    for label in pattern.hidden:
        name = _fresh_name(f"{witness_prefix}_{label}", forbidden_names)
        hidden_var = Var(name, vertex_sort)
        variables[label] = hidden_var
        forbidden_names.add(name)

    atoms = [
        Rel(edge_relation, (v(variables[left]), v(variables[right])))
        for left, right in pattern.edges
    ]
    predicate: Pred = _and_all(atoms)
    for label in reversed(pattern.hidden):
        predicate = Exists(variables[label], predicate)

    context = Context(tuple(visible_vars[label] for label in pattern.visible))
    return CompiledQuery(
        pattern=pattern,
        context=context,
        predicate=predicate,
        vertex_variables=tuple((label, variables[label]) for label in pattern.vertices),
    )


def find_matches(pattern: PatternGraph, graph: FiniteDirectedGraph) -> Tuple[PatternMatch, ...]:
    """Enumerate all pattern homomorphisms P -> G in deterministic order."""

    matches = []
    for values in product(graph.vertices, repeat=len(pattern.vertices)):
        mapping = tuple(zip(pattern.vertices, values))
        try:
            matches.append(PatternMatch(pattern, graph, mapping))
        except ValueError:
            continue
    return tuple(matches)


def matches_with_visible_assignment(
    pattern: PatternGraph,
    graph: FiniteDirectedGraph,
    assignment: Mapping[str, object],
) -> Tuple[PatternMatch, ...]:
    """Find matches whose visible vertices agree with a declared assignment."""

    if set(assignment) != set(pattern.visible):
        raise ValueError("assignment must specify exactly the visible pattern vertices")
    return tuple(
        match for match in find_matches(pattern, graph)
        if match.visible_assignment() == dict(assignment)
    )


def transport_match(match: PatternMatch, hom: GraphHomomorphism) -> PatternMatch:
    """Transport a pattern witness across an edge-preserving graph map."""

    if match.graph != hom.source:
        raise ValueError("match graph must be the source of the graph homomorphism")
    table = hom.as_dict()
    return PatternMatch(
        match.pattern,
        hom.target,
        tuple((label, table[value]) for label, value in match.mapping),
    )


def compose_graph_homomorphisms(
    second: GraphHomomorphism,
    first: GraphHomomorphism,
    *,
    name: str | None = None,
) -> GraphHomomorphism:
    """Compose `second` after `first`."""

    if first.target != second.source:
        raise ValueError("graph homomorphisms do not compose")
    second_table = second.as_dict()
    mapping = tuple((vertex, second_table[first.apply(vertex)]) for vertex in first.source.vertices)
    return GraphHomomorphism(name or f"{second.name}_after_{first.name}", first.source, second.target, mapping)


def graph_model(graph: FiniteDirectedGraph, *, vertex_sort: Sort, edge_relation: str) -> FiniteModel:
    """Interpret one finite graph as a one-sort relational finite model."""

    return FiniteModel(
        carriers={vertex_sort: graph.vertices},
        ops={},
        rels={edge_relation: frozenset(graph.edges)},
    )
