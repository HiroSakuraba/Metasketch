"""
Metasketch-0 reflection layer and the Program E boundary made executable.

This module implements the controlled-reflection design and, crucially, turns the
reflection-cost claims into concrete finite tests rather than slogans.

Four capabilities are kept separate, as the design demands:

  quote : raises a diagram to a code one level up (always level-raising).
  check : verifies a finite proof certificate at the next level (total, syntactic).
  eval  : runs a coded computation with explicit partiality (value,
          resource_exhausted, or unsupported), never coercing a failed
          computation into a Boolean.
  truth : a same-level, total, representation-complete Boolean evaluator. The
          finite diagonal routine below shows such an evaluator is incomplete
          on its own finite code set. General Tarski or Lawvere barriers need
          additional hypotheses and are not claimed by this module.

The load-bearing results:

  finite diagonal lemma (same-level representation is incomplete):
     For any finite code set C and any same-level evaluator table eval : C x C -> Bool,
     the diagonal predicate d(c) = not eval(c, c) is represented by no row of eval.
     Hence no same-level evaluator table is representation-complete for predicates
     on its own finite code set. This is a finite Cantor-Lawvere calculation.

  stratified escape (one level up is enough and safe):
     At level k+1 we can hold codes for EVERY predicate on the level-k code set,
     with a point-surjective evaluator eval_{k+1} : Code_{k+1} x C_k -> Bool. The
     diagonal cannot be formed, because it would require applying a level-k code to
     itself, and codes and arguments now live in different sets. So representation
     completeness across the level gap is available with no contradiction.

Together these give a finite design warning: a same-level Boolean evaluator cannot
represent every predicate of its own finite code set. The membrane checker blocks
that interface by construction. It does not by itself prove a general theorem.
"""

from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from typing import Dict, List, Optional, Tuple, Any


# ---------------------------------------------------------------------------
# Levels and quotation
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Code:
    """
    An immutable code token produced by quotation. It carries the serialized
    payload, the level of the object it quotes, and its own (strictly higher)
    code level. There is no operation that lowers a code back to a same-level
    raw diagram; only a typed higher-level interface may inspect it.
    """
    payload: Any            # serialized, immutable representation of the quoted object
    kind: str               # e.g. "diagram", "proof_certificate", "predicate"
    source_level: int
    code_level: int

    def __post_init__(self):
        if self.code_level != self.source_level + 1:
            raise ValueError(
                "Code invariant violated: code_level must be source_level + 1 "
                f"(got source={self.source_level}, code={self.code_level})"
            )


def quote(obj: Any, kind: str, source_level: int) -> Code:
    """Quotation raises the level by exactly one. This is enforced, not advised."""
    payload = _serialize(obj)
    return Code(payload=payload, kind=kind, source_level=source_level,
                code_level=source_level + 1)


def _serialize(obj: Any) -> Any:
    """A deterministic, hashable serialization (repr-based, sufficient here)."""
    return repr(obj)


# ---------------------------------------------------------------------------
# A minimal but genuine proof-certificate checker (check, sigma_check <= 1)
# ---------------------------------------------------------------------------
#
# A certificate is a finite list of lines. Each line states a rule, a conclusion,
# and the indices of earlier lines used as premises. Judgments are either
# Entail(P, R) meaning "P entails R", or TileJ(P, d, R) meaning a composed
# preservation tile. The checker verifies each line is a valid instance of its
# rule using only earlier lines, and reports the first error. It is total on
# finite certificates. It decides derivability of the supplied syntax; it does
# not decide truth.

@dataclass(frozen=True)
class Entail:
    p: Any
    r: Any


@dataclass(frozen=True)
class TileJ:
    p: Any
    d: Any
    r: Any


@dataclass(frozen=True)
class Line:
    rule: str
    conclusion: Any
    premises: Tuple[int, ...] = ()
    extra: Any = None  # rule-specific data (e.g. the axiom, or a term)


@dataclass
class CheckResult:
    accepted: bool
    error: Optional[str] = None
    error_line: Optional[int] = None


def check_certificate(cert: List[Line], axioms: Tuple[Any, ...]) -> CheckResult:
    """
    Verify a finite certificate against the declared rule set. Rules supported:

      AX          : conclusion must be one of the declared axioms.
      REFL        : conclusion Entail(P, Eq(t, t)) for the extra term t.
      CONJ_INTRO  : from Entail(P, A) and Entail(P, B) derive Entail(P, And(A, B)).
      CONJ_ELIM_L : from Entail(P, And(A, B)) derive Entail(P, A).
      CONJ_ELIM_R : from Entail(P, And(A, B)) derive Entail(P, B).
      COMPOSE     : from TileJ(P, d, Q) and TileJ(Q, e, R) derive TileJ(P, e.d, R).

    The And/Eq/compose shapes are checked structurally on the payloads. This is
    a syntactic verifier; it does not evaluate models.
    """
    from .syntax import And as SynAnd, Eq as SynEq, compose_diagrams

    lines_out: List[Any] = []

    def prem(i: int, idx: int):
        if not (0 <= idx < i):
            raise IndexError(f"line {i}: premise index {idx} is not an earlier line")
        return lines_out[idx]

    for i, line in enumerate(cert):
        try:
            if line.rule == "AX":
                if line.conclusion not in axioms:
                    return CheckResult(False, "AX: conclusion is not a declared axiom", i)

            elif line.rule == "REFL":
                t = line.extra
                if not (isinstance(line.conclusion, Entail)
                        and isinstance(line.conclusion.r, SynEq)
                        and line.conclusion.r.left == t
                        and line.conclusion.r.right == t):
                    return CheckResult(False, "REFL: conclusion must be Entail(P, Eq(t, t))", i)

            elif line.rule == "CONJ_INTRO":
                a = prem(i, line.premises[0])
                b = prem(i, line.premises[1])
                if not (isinstance(a, Entail) and isinstance(b, Entail) and a.p == b.p):
                    return CheckResult(False, "CONJ_INTRO: premises must share context P", i)
                want = Entail(a.p, SynAnd(a.r, b.r))
                if line.conclusion != want:
                    return CheckResult(False, "CONJ_INTRO: conclusion does not match And of premises", i)

            elif line.rule in ("CONJ_ELIM_L", "CONJ_ELIM_R"):
                a = prem(i, line.premises[0])
                if not (isinstance(a, Entail) and isinstance(a.r, SynAnd)):
                    return CheckResult(False, f"{line.rule}: premise must be Entail(P, And(..))", i)
                side = a.r.left if line.rule == "CONJ_ELIM_L" else a.r.right
                if line.conclusion != Entail(a.p, side):
                    return CheckResult(False, f"{line.rule}: conclusion does not match chosen conjunct", i)

            elif line.rule == "COMPOSE":
                t1 = prem(i, line.premises[0])
                t2 = prem(i, line.premises[1])
                if not (isinstance(t1, TileJ) and isinstance(t2, TileJ)):
                    return CheckResult(False, "COMPOSE: premises must be tile judgments", i)
                if t1.r != t2.p:
                    return CheckResult(False, "COMPOSE: middle predicates do not match", i)
                ecd = compose_diagrams(t2.d, t1.d)
                want = TileJ(t1.p, ecd, t2.r)
                if line.conclusion != want:
                    return CheckResult(False, "COMPOSE: conclusion does not match composed tile", i)

            else:
                return CheckResult(False, f"unknown rule {line.rule}", i)

        except (IndexError, AttributeError, KeyError) as exc:
            return CheckResult(False, f"line {i}: {exc}", i)

        lines_out.append(line.conclusion)

    return CheckResult(True)


# ---------------------------------------------------------------------------
# Partial evaluation (eval): value, resource exhaustion, or unsupported
# ---------------------------------------------------------------------------

RESOURCE_EXHAUSTED = ("resource_exhausted",)


@dataclass
class EvalResult:
    status: str          # "value" | "resource_exhausted" | "unsupported"
    value: Optional[Any] = None


def eval_string_rewrite(
    start: str,
    rules: Tuple[Tuple[str, str], ...],
    supported_alphabet: str,
    budget: int = 1000,
) -> EvalResult:
    """
    A tiny string-rewriting evaluator standing in for coded computation.

    Outcomes, mirroring the design's three controlled cases:
      - a symbol outside the supported alphabet -> "unsupported"
      - reaches a normal form within the budget  -> "value"
      - exhausts the resource budget              -> "resource_exhausted"

    Resource exhaustion is not a proof of divergence. It is deliberately never
    reported as a Boolean or an arbitrary normal form.
    """
    if any(ch not in supported_alphabet for ch in start):
        return EvalResult("unsupported")
    cur = start
    for _ in range(budget):
        applied = False
        for lhs, rhs in rules:
            idx = cur.find(lhs)
            if idx != -1:
                cur = cur[:idx] + rhs + cur[idx + len(lhs):]
                applied = True
                break
        if not applied:
            return EvalResult("value", cur)  # normal form
    return EvalResult("resource_exhausted")


# ---------------------------------------------------------------------------
# Membrane checker: the typed prohibition (Program E boundary enforced in code)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class InterfaceSpec:
    capability: str          # "quote" | "check" | "eval" | "sat" | "truth"
    source_level: int
    target_level: int
    total: bool = False
    representation_complete: bool = False


@dataclass
class MembraneVerdict:
    accepted: bool
    reason: str


def membrane_check(spec: InterfaceSpec) -> MembraneVerdict:
    cap = spec.capability
    if cap == "quote":
        ok = spec.target_level == spec.source_level + 1
        return MembraneVerdict(ok, "quote must raise level by exactly one")
    if cap in ("check", "eval", "sat"):
        ok = spec.target_level >= spec.source_level + 1
        return MembraneVerdict(
            ok,
            "reflective inspection must occur at a strictly higher level"
            if ok else "same-level inspection is rejected: no self-inspection port",
        )
    if cap == "truth":
        if spec.target_level == spec.source_level:
            if spec.total and spec.representation_complete:
                return MembraneVerdict(
                    False,
                    "prohibited by the membrane: finite diagonal testing shows a same-level "
                    "Boolean evaluator cannot represent every predicate of its own code set",
                )
            return MembraneVerdict(
                True,
                "same-level truth-shaped interface is permitted only when it explicitly "
                "gives up totality or representation completeness",
            )
        if spec.target_level >= spec.source_level + 1:
            return MembraneVerdict(True, "stratified truth about a strictly lower level is permitted")
        return MembraneVerdict(False, "truth cannot inspect a higher source from a lower target level")
    return MembraneVerdict(False, f"unknown capability {cap}")


# ---------------------------------------------------------------------------
# The diagonal: sigma_truth >= 1 (unstratified impossible) and stratified escape
# ---------------------------------------------------------------------------

def diagonal_predicate(eval_table: List[List[int]]) -> List[int]:
    """d(c) = not eval(c, c)."""
    n = len(eval_table)
    return [1 - eval_table[c][c] for c in range(n)]


def is_row_of(pred: List[int], eval_table: List[List[int]]) -> Optional[int]:
    """Return an index c whose row equals pred, or None if no row does."""
    for c, row in enumerate(eval_table):
        if list(row) == list(pred):
            return c
    return None


def finite_same_level_representation_is_incomplete(n: int, exhaustive: bool = True,
                                   samples: int = 2000) -> Tuple[bool, dict]:
    """
    For a finite code set of size n, verify that no same-level evaluator table
    eval : C x C -> Bool is representation-complete for predicates on C:
    the diagonal predicate d(c) = not eval(c, c) is never a row.

    For n = 2 we enumerate all 2^(n*n) tables exhaustively. For larger n we
    sample tables as a regression check. The diagonal is unrepresented,
    witnessed at index c by d(c) != eval(c, c).
    """
    import random
    checked = 0
    if exhaustive and n * n <= 9:
        cells = list(product([0, 1], repeat=n * n))
        tables = ([[bits[r * n + c] for c in range(n)] for r in range(n)] for bits in cells)
        for table in tables:
            d = diagonal_predicate(table)
            if is_row_of(d, table) is not None:
                return False, {"counterexample_table": table, "diagonal": d}
            checked += 1
    else:
        rng = random.Random(20260701)
        for _ in range(samples):
            table = [[rng.randint(0, 1) for _ in range(n)] for _ in range(n)]
            d = diagonal_predicate(table)
            if is_row_of(d, table) is not None:
                return False, {"counterexample_table": table, "diagonal": d}
            checked += 1
    return True, {"tables_checked": checked, "mode": "exhaustive" if (exhaustive and n * n <= 9) else "sampled"}


@dataclass(frozen=True)
class LevelElement:
    """An element tagged with the level of the domain it inhabits."""

    level: int
    value: int


@dataclass(frozen=True)
class PredicateCode:
    """A level-(k+1) code for a Boolean predicate on level-k elements."""

    argument_level: int
    bits: Tuple[int, ...]

    @property
    def code_level(self) -> int:
        return self.argument_level + 1


def eval_predicate_code(code: PredicateCode, argument: LevelElement) -> int:
    """Typed cross-level evaluation: Code[k+1, Pred[k]] x Element[k] -> Bool."""
    if not isinstance(argument, LevelElement):
        raise TypeError("a predicate code cannot be used as a level-k argument")
    if argument.level != code.argument_level:
        raise TypeError(
            f"evaluator expects a level-{code.argument_level} argument, "
            f"got level-{argument.level}"
        )
    if not (0 <= argument.value < len(code.bits)):
        raise IndexError("argument is outside the coded finite domain")
    return code.bits[argument.value]


def stratified_escape(n: int) -> Tuple[bool, dict]:
    """Demonstrate an explicitly typed cross-level predicate-code interface.

    At level k+1 there is one PredicateCode for every Boolean predicate on the
    n-element level-k domain. Attempting eval_predicate_code(code, code) raises a
    TypeError because a predicate code is not a level-k domain element. This is a
    real type check, not an argument from unequal set cardinalities.
    """
    predicates = [tuple(bits) for bits in product([0, 1], repeat=n)]
    codes = [PredicateCode(0, bits) for bits in predicates]
    covered = all(any(code.bits == pred for code in codes) for pred in predicates)
    # For an empty lower-level domain there is one predicate (the empty
    # function) and no legal argument to evaluate.  The evaluator law is
    # therefore vacuous, not false.
    typed_eval_works = (
        True if n == 0 else eval_predicate_code(codes[0], LevelElement(0, 0)) in (0, 1)
    )
    rejected = False
    try:
        eval_predicate_code(codes[0], codes[0])  # type: ignore[arg-type]
    except TypeError:
        rejected = True
    return (covered and typed_eval_works and rejected), {
        "num_level_k_elements": n,
        "num_level_k_plus_1_predicate_codes": len(codes),
        "point_surjective_across_gap": covered,
        "typed_cross_level_evaluation": typed_eval_works,
        "same_level_self_application_rejected_by_type_check": rejected,
    }



# Backward-compatible alias. New code should use the finite-specific name above.
same_level_truth_is_impossible = finite_same_level_representation_is_incomplete

# ---------------------------------------------------------------------------
# F3: safe reflection-interface constructors
# ---------------------------------------------------------------------------
#
# `InterfaceSpec` remains an audit-level record: tests and diagnostics can use
# it to ask whether a proposed interface is legal.  The constructors below are
# the supported construction boundary.  They only return interfaces accepted by
# the membrane policy, so normal clients do not need to construct a potentially
# illegal same-level truth interface merely to obtain a legal one.

@dataclass(frozen=True)
class SafeReflectionInterface:
    """A membrane-approved reflection interface.

    The wrapped specification has already passed ``membrane_check``.  This is a
    runtime mirror of F3's Lean ``SafeInterface`` grammar.  It does not claim
    that arbitrary Python code cannot manufacture raw ``InterfaceSpec`` values;
    the checked public API exports only these constructors.
    """

    spec: InterfaceSpec

    def __post_init__(self) -> None:
        verdict = membrane_check(self.spec)
        if not verdict.accepted:
            raise ValueError(f"unsafe reflection interface: {verdict.reason}")

    @property
    def capability(self) -> str:
        return self.spec.capability

    @property
    def source_level(self) -> int:
        return self.spec.source_level

    @property
    def target_level(self) -> int:
        return self.spec.target_level

    @property
    def total(self) -> bool:
        return self.spec.total

    @property
    def representation_complete(self) -> bool:
        return self.spec.representation_complete


def safe_quote_interface(level: int) -> SafeReflectionInterface:
    """The only supported quote interface: level ``k`` to level ``k + 1``."""
    return SafeReflectionInterface(InterfaceSpec("quote", level, level + 1))


def safe_check_interface(level: int) -> SafeReflectionInterface:
    """A total syntactic checker one level above its checked object."""
    return SafeReflectionInterface(InterfaceSpec("check", level, level + 1, total=True))


def safe_eval_interface(level: int) -> SafeReflectionInterface:
    """A contextual evaluator one level above its object-level argument."""
    return SafeReflectionInterface(InterfaceSpec("eval", level, level + 1))


def safe_satisfaction_interface(level: int) -> SafeReflectionInterface:
    """A model-relative satisfaction interface one level above its formula."""
    return SafeReflectionInterface(InterfaceSpec("sat", level, level + 1))


def safe_lower_truth_interface(level: int) -> SafeReflectionInterface:
    """Total, representation-complete truth only about a strictly lower level."""
    return SafeReflectionInterface(
        InterfaceSpec("truth", level, level + 1, total=True, representation_complete=True)
    )


def safe_same_level_partial_truth_interface(level: int) -> SafeReflectionInterface:
    """A same-level truth-shaped interface that explicitly gives up totality."""
    return SafeReflectionInterface(
        InterfaceSpec("truth", level, level, total=False, representation_complete=True)
    )


def safe_same_level_incomplete_truth_interface(level: int) -> SafeReflectionInterface:
    """A same-level truth-shaped interface that explicitly gives up completeness."""
    return SafeReflectionInterface(
        InterfaceSpec("truth", level, level, total=True, representation_complete=False)
    )


def reflection_interface_summary(interface: SafeReflectionInterface) -> Dict[str, Any]:
    """Canonical manifest fragment used by F3 tests and future renderers."""
    return {
        "capability": interface.capability,
        "source_level": interface.source_level,
        "target_level": interface.target_level,
        "total": interface.total,
        "representation_complete": interface.representation_complete,
        "membrane_approved": True,
    }
