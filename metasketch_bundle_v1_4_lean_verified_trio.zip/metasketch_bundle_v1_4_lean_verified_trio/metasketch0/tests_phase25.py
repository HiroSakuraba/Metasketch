"""
Metasketch-0 Phase 2.5 tests: coherence between structural rewriting and
logical transport at the preservation-tile layer.

Verifies, by computation:
  - the syntax-level structural rewriter agrees with the Phase 2 engine on the
    underlying monoid word;
  - transport commutes with structural normalization (the global statement) over
    a suite of diagrams and predicates;
  - the coherence square (the 3-cell) closes syntactically for single structural
    redexes, including the pentagon lifted into a tile;
  - the same square closes semantically in monoid models (models of the theory);
  - teeth: in a non-associative magma the two routes can differ, so the coherence
    cell is exactly the associativity axiom, not a triviality;
  - a valid preservation tile stays valid when its diagram is structurally
    rewritten, and the two reindexed predicates have equal extension.
"""

from __future__ import annotations
import random
from typing import List

from .syntax import (
    Sort, Var, Context, Diagram, VarTerm, OpTerm, Term,
    Eq, Rel, And, Top, op, v, reindex, validate_diagram, validate_pred,
)
from .semantics import FiniteModel, extension, tile_valid_in_model
from . import tile_coherence as tc
from . import coherence as ph2          # the Phase 2 engine, for cross-check
from .rewriting import normalize as rw_normalize
from .tests import Report


M = tc.M


# ---------------------------------------------------------------------------
# helpers to build random monoid terms on the syntax type
# ---------------------------------------------------------------------------

def gen_syn_term(rng: random.Random, leaves: List[Term], depth: int) -> Term:
    if depth <= 0 or rng.random() < 0.4:
        return rng.choice(leaves)
    return tc.m(gen_syn_term(rng, leaves, depth - 1), gen_syn_term(rng, leaves, depth - 1))


def syn_to_rw_term(t: Term):
    from .rewriting import Atom, App
    if isinstance(t, VarTerm):
        return Atom(t.var.name)
    if isinstance(t, OpTerm) and t.op == "e":
        return App("e")
    if isinstance(t, OpTerm) and t.op == "m":
        a, b = t.args
        return App("m", syn_to_rw_term(a), syn_to_rw_term(b))
    raise TypeError(f"cannot translate {t!r}")


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

def test_engine_agreement(rep: Report):
    """The syntax rewriter and the Phase 2 tuple engine agree on the word."""
    rng = random.Random(3)
    leaves = [v(Var("sa", M)), v(Var("sb", M)), v(Var("sc", M)), tc.E]
    bad = None
    for _ in range(300):
        t = gen_syn_term(rng, leaves, 4)
        nf_syn = tc.term_nf(t)
        rw = syn_to_rw_term(t)
        nf_rw, _ = rw_normalize(rw, ph2.MONOID_RULES)
        # compare underlying words
        word_syn = _word_syn(nf_syn)
        word_rw = _word_rw(nf_rw)
        if word_syn != word_rw:
            bad = f"{t!r}: syn word {word_syn} vs engine word {word_rw}"
            break
    rep.check("Phase2.5 syntax rewriter agrees with the Phase 2 engine on the word",
              bad is None, bad or "300 random terms")


def _word_syn(t: Term) -> List[str]:
    if isinstance(t, VarTerm):
        return [t.var.name]
    if isinstance(t, OpTerm) and t.op == "e":
        return []
    if isinstance(t, OpTerm) and t.op == "m":
        a, b = t.args
        return _word_syn(a) + _word_syn(b)
    raise TypeError


def _word_rw(t) -> List[str]:
    from .rewriting import is_atom, is_app, args_of
    if is_atom(t):
        return [t[1]]
    if is_app(t) and t[0] == "e":
        return []
    if is_app(t) and t[0] == "m":
        a, b = args_of(t)
        return _word_rw(a) + _word_rw(b)
    raise TypeError


def _random_diagram_and_pred(rng: random.Random):
    leaves = [v(Var("x", M)), tc.E]
    img = gen_syn_term(rng, leaves, 4)
    d = Diagram(Context((Var("x", M),)), tc.TGT, (("y", img),))
    y = v(Var("y", M))
    # Q must be a predicate over the target context (y) only.
    templates = [
        Eq(tc.m(y, y), y),
        Eq(y, y),
        Eq(tc.m(y, y), tc.m(y, y)),
        Eq(y, tc.m(y, y)),
    ]
    q = rng.choice(templates)
    return d, q


def test_transport_commutes(rep: Report):
    rng = random.Random(7)
    bad = None
    checked = 0
    for _ in range(400):
        d, q = _random_diagram_and_pred(rng)
        if not tc.transport_commutes_with_normalization(d, q):
            bad = f"commutation failed for d={d!r}, Q={q!r}"
            break
        checked += 1
    rep.check("Phase2.5 transport commutes with structural normalization",
              bad is None, bad or f"{checked} random (diagram, predicate) pairs")


def test_coherence_square_syntactic(rep: Report):
    rng = random.Random(11)
    bad = None
    squares = 0
    for _ in range(400):
        d, q = _random_diagram_and_pred(rng)
        if not tc.diagram_has_redex(d):
            continue
        sq = tc.CoherenceSquare(d, q)
        if not sq.coheres_syntactically() or not sq.cell.validate():
            bad = f"stored 3-cell did not validate: left={sq.left_nf!r} right={sq.right_nf!r}"
            break
        squares += 1
    rep.check("Phase2.5 coherence square closes syntactically (the 3-cell)",
              bad is None and squares > 0, bad or f"{squares} filled critical branchings")


def test_pentagon_in_tile(rep: Report):
    d = tc.pentagon_tile_diagram()
    q = tc.pentagon_tile_predicate()
    ok_global = tc.transport_commutes_with_normalization(d, q)
    sq = tc.CoherenceSquare(d, q)
    ok_syn = sq.coheres_syntactically()
    models_ok = all(
        sq.coheres_semantically(tc.monoid_model(n, k), tc.SRC4)
        for n, k in [(4, "add"), (5, "add"), (6, "mul"), (3, "add")]
    )
    rep.check("Phase2.5 pentagon lifted into a tile: transport commutes and square closes",
              ok_global and ok_syn and models_ok,
              f"global={ok_global}, syntactic={ok_syn}, semantic_in_monoids={models_ok}")


def test_semantic_coherence_in_monoids(rep: Report):
    rng = random.Random(13)
    ctx = Context((Var("x", M),))
    models = [tc.monoid_model(4, "add"), tc.monoid_model(5, "add"),
              tc.monoid_model(6, "mul"), tc.monoid_model(3, "add")]
    bad = None
    checked = 0
    for _ in range(300):
        d, q = _random_diagram_and_pred(rng)
        if not tc.diagram_has_redex(d):
            continue
        sq = tc.CoherenceSquare(d, q)
        for model in models:
            if not sq.coheres_semantically(model, ctx):
                bad = f"semantic mismatch in a monoid for d={d!r}, Q={q!r}"
                break
        if bad:
            break
        checked += 1
    rep.check("Phase2.5 coherence holds semantically in every monoid model",
              bad is None and checked > 0, bad or f"{checked} squares across 4 monoids")


def test_teeth_nonassociative_magma(rep: Report):
    """In a non-associative magma the two routes can differ. Find a witness."""
    magma = tc.magma_model()
    ctx = Context((Var("x", M),))
    x = v(Var("x", M))
    # d : y := (x x) x; one associativity step gives y := x (x x).
    d = Diagram(ctx, tc.TGT, (("y", tc.m(tc.m(x, x), x)),))
    templates = [
        Eq(v(Var("y", M)), tc.E),
        Eq(tc.m(v(Var("y", M)), v(Var("y", M))), v(Var("y", M))),
        Eq(v(Var("y", M)), tc.m(v(Var("y", M)), v(Var("y", M)))),
    ]
    witness = None
    for q in templates:
        sq = tc.CoherenceSquare(d, q)
        if not sq.coheres_semantically(magma, ctx):
            witness = q
            break
    rep.check("Phase2.5 teeth: in a non-associative magma the routes can differ",
              witness is not None,
              f"witness predicate Q = {witness!r}" if witness
              else "no witness found; coherence looked trivial (unexpected)")

    # and confirm that same square DOES cohere in a genuine monoid
    monoid = tc.monoid_model(6, "mul")
    coheres_in_monoid = all(
        tc.CoherenceSquare(d, q).coheres_semantically(monoid, ctx)
        for q in templates
    )
    rep.check("Phase2.5 teeth: the same squares cohere in a monoid model",
              coheres_in_monoid, "" if coheres_in_monoid else "unexpected failure in monoid")


def test_tile_validity_preserved(rep: Report):
    """A valid preservation tile stays valid when its diagram is rewritten."""
    ctx = Context((Var("x", M),))
    x = v(Var("x", M))
    y = v(Var("y", M))
    # d : y := (x x) x, structurally a redex. Let P=d^*Q. In a monoid the
    # rewritten diagram d2 has the same transported predicate, so P |- d2^*Q.
    d = Diagram(ctx, tc.TGT, (("y", tc.m(tc.m(x, x), x)),))
    d2 = tc.diagram_nf(d)  # y := x (x x)
    q = Eq(tc.m(y, y), y)
    models = [tc.monoid_model(4, "add"), tc.monoid_model(6, "mul"), tc.monoid_model(5, "add")]
    ok = True
    detail = ""
    p = reindex(d, q)
    for model in models:
        e1 = extension(p, ctx, model)
        e2 = extension(reindex(d2, q), ctx, model)
        if e1 != e2:
            ok = False
            detail = "reindexed predicates differ after structural rewrite in a monoid"
            break
        if not tile_valid_in_model(p, d2, q, model).valid:
            ok = False
            detail = "a valid tile did not remain valid after structural rewriting"
            break
    rep.check("Phase2.5 structural rewrite preserves a valid transported tile in selected monoids",
              ok, detail)


def _identity(ctx: Context) -> Diagram:
    return Diagram(ctx, ctx, tuple((xx.name, VarTerm(xx)) for xx in ctx.vars))


def test_phase25_static_well_formedness(rep: Report):
    rng = random.Random(29)
    d, q = _random_diagram_and_pred(rng)
    ok = True
    detail = ""
    try:
        validate_diagram(d, tc.MONOID_SIGNATURE)
        validate_pred(q, tc.MONOID_SIGNATURE, d.target)
        validate_pred(reindex(d, q), tc.MONOID_SIGNATURE, d.source)
    except Exception as exc:
        ok = False
        detail = repr(exc)
    rep.check("Phase2.5 random diagram and predicate pass the static monoid checker", ok, detail)


def run() -> int:
    rep = Report()
    test_phase25_static_well_formedness(rep)
    test_engine_agreement(rep)
    test_transport_commutes(rep)
    test_coherence_square_syntactic(rep)
    test_pentagon_in_tile(rep)
    test_semantic_coherence_in_monoids(rep)
    test_teeth_nonassociative_magma(rep)
    test_tile_validity_preserved(rep)

    print("=" * 72)
    print("Metasketch-0 Phase 2.5 test report (structure/logic coherence)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
