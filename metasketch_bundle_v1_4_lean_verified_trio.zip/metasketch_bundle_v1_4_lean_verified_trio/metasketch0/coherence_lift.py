"""Reusable coherence-lifting schema for Metasketch.

A structural 2-cell ``r : d => d'`` should act on transported predicates:

    Lift(r, Q) : reindex(d, Q) => reindex(d', Q).

For a convergent predicate-normalization strategy, both sides normalize to a
common predicate.  This module packages that construction without claiming that
all future structural theories share the monoid's implementation details.

The schema has explicit hypotheses supplied as callbacks:

* a structural one-step operation and its validator;
* a transport operation;
* a normalizer returning a trace-like object; and
* a trace validator.

The current monoid presentation is one instantiation.  Relational witness
transport remains a second instance of the broader idea, with composition cells
already supplied by ``WitnessTransportCoherenceCell3``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional


class CoherenceLiftError(ValueError):
    """Raised when a requested coherence lift has no valid structural branch."""


@dataclass(frozen=True)
class CoherenceLiftingSchema:
    """Data needed to construct a generic transport-normalization 3-cell."""

    name: str
    step: Callable[[Any], Optional[Any]]
    validate_step: Callable[[Any, Any], bool]
    transport: Callable[[Any, Any], Any]
    normalize: Callable[[Any], Any]
    validate_trace: Callable[[Any], bool]

    def lift(self, structural_source: Any, target_predicate: Any) -> "LiftedTransportCoherenceCell3":
        structural_target = self.step(structural_source)
        if structural_target is None:
            raise CoherenceLiftError(
                f"schema {self.name!r}: structural source has no liftable one-step rewrite"
            )
        before = self.transport(structural_source, target_predicate)
        after = self.transport(structural_target, target_predicate)
        left = self.normalize(before)
        right = self.normalize(after)
        cell = LiftedTransportCoherenceCell3(
            schema=self,
            structural_source=structural_source,
            structural_target=structural_target,
            target_predicate=target_predicate,
            transport_before=before,
            transport_after=after,
            left_normalization=left,
            right_normalization=right,
        )
        if not cell.validate():
            raise CoherenceLiftError(
                f"schema {self.name!r}: the proposed lift does not close at a common normal form"
            )
        return cell


@dataclass(frozen=True)
class LiftedTransportCoherenceCell3:
    """A stored generic 3-cell between two normalized transport branches."""

    schema: CoherenceLiftingSchema
    structural_source: Any
    structural_target: Any
    target_predicate: Any
    transport_before: Any
    transport_after: Any
    left_normalization: Any
    right_normalization: Any

    @property
    def common_normal_form(self) -> Any:
        return self.left_normalization.target

    def validate(self) -> bool:
        left_source = getattr(self.left_normalization, "source", None)
        left_target = getattr(self.left_normalization, "target", None)
        right_source = getattr(self.right_normalization, "source", None)
        right_target = getattr(self.right_normalization, "target", None)
        return (
            self.schema.validate_step(self.structural_source, self.structural_target)
            and self.transport_before
            == self.schema.transport(self.structural_source, self.target_predicate)
            and self.transport_after
            == self.schema.transport(self.structural_target, self.target_predicate)
            and left_source == self.transport_before
            and right_source == self.transport_after
            and self.schema.validate_trace(self.left_normalization)
            and self.schema.validate_trace(self.right_normalization)
            and left_target == right_target
        )


def monoid_reindex_lifting_schema() -> CoherenceLiftingSchema:
    """Return the Phase 2.5 monoid instance of the generic schema."""

    from . import tile_coherence as tc

    return CoherenceLiftingSchema(
        name="monoid_rewrite_reindex_normalization",
        step=tc.diagram_step,
        validate_step=lambda source, target: tc.diagram_step(source) == target,
        transport=tc.reindex,
        normalize=tc.pred_normalize,
        validate_trace=lambda trace: trace.validate(),
    )


@dataclass(frozen=True)
class WitnessTransportLiftingAdapter:
    """Adapter exposing relational witness transport as a coherence-lifting family.

    This is intentionally small.  It does not claim the predicate-normalization
    schema above covers all witness transports.  Instead it makes the common
    shape explicit: two compositional routes are lifted to a stored 3-cell and
    verified by a canonical normal form.
    """

    name: str = "relational_witness_transport_composition"

    def lift(self, source_proof: Any, first_hom: Any, second_hom: Any) -> Any:
        from .proofs import make_transport_coherence_cell

        return make_transport_coherence_cell(source_proof, first_hom, second_hom)

    def validate(self, cell: Any) -> bool:
        return bool(cell.validate())


__all__ = [
    "CoherenceLiftError",
    "CoherenceLiftingSchema",
    "LiftedTransportCoherenceCell3",
    "monoid_reindex_lifting_schema",
    "WitnessTransportLiftingAdapter",
]
