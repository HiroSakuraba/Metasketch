"""
Metasketch-0 example libraries: monoids (M0) and directed graphs (M1).

Each library builds a two-sorted finite model carrying a candidate map, so that
"a homomorphism preserves a property" becomes a preservation tile whose validity
is decided in the finite model. This is where the calculus is given teeth: a
genuine homomorphism validates the preservation tile, a non-homomorphism can
break it, and the semantics reports the counterexample.
"""

from __future__ import annotations
from typing import Callable, Dict, Tuple

from .syntax import (
    Sort, Var, Context, Diagram, VarTerm, OpTerm, Term,
    Top, Eq, Rel, And, Exists, op, v,
)
from .semantics import FiniteModel
from .tiles import Tile


def identity_diagram(ctx: Context) -> Diagram:
    return Diagram(
        source=ctx,
        target=ctx,
        mapping=tuple((x.name, VarTerm(x)) for x in ctx.vars),
    )


# ===========================================================================
# M0 : monoids and monoid homomorphisms
# ===========================================================================

M = Sort("M")
N = Sort("N")


def monoid_hom_model(
    m_elems: Tuple[object, ...], mul_m: Callable, unit_m: object,
    n_elems: Tuple[object, ...], mul_n: Callable, unit_n: object,
    h: Callable[[object], object],
) -> FiniteModel:
    return FiniteModel(
        carriers={M: tuple(m_elems), N: tuple(n_elems)},
        ops={
            "mulM": mul_m,
            "mulN": mul_n,
            "unitM": (lambda: unit_m),
            "unitN": (lambda: unit_n),
            "h": h,
        },
        rels={},
    )


# variables and contexts
xM = Var("x", M)
yM = Var("y", M)
yN = Var("y", N)

ctx_xM = Context((xM,))
ctx_xyM = Context((xM, yM))
ctx_yN = Context((yN,))


def idempotent_M() -> Eq:
    # x . x = x   in M
    return Eq(op("mulM", v(xM), v(xM)), v(xM))


def idempotent_N() -> Eq:
    # y . y = y   in N
    return Eq(op("mulN", v(yN), v(yN)), v(yN))


def diagram_h() -> Diagram:
    # d : (x:M) -> (y:N),  y := h(x)
    return Diagram(source=ctx_xM, target=ctx_yN, mapping=(("y", op("h", v(xM))),))


def tile_preserves_idempotence() -> Tile:
    # idempotent(x) |- d_h^* idempotent(y)
    return Tile(p=idempotent_M(), d=diagram_h(), q=idempotent_N())


def tile_preserves_multiplication() -> Tile:
    # Top |- id^* ( h(x.y) = h(x).h(y) )     over context (x:M, y:M)
    q = Eq(
        op("h", op("mulM", v(xM), v(yM))),
        op("mulN", op("h", v(xM)), op("h", v(yM))),
    )
    return Tile(p=Top(), d=identity_diagram(ctx_xyM), q=q)


# ===========================================================================
# M1 : directed graphs and graph homomorphisms
# ===========================================================================

V = Sort("V")
W = Sort("W")


def graph_hom_model(
    v_elems: Tuple[object, ...], edges_g: Tuple[Tuple[object, object], ...],
    w_elems: Tuple[object, ...], edges_h: Tuple[Tuple[object, object], ...],
    hv: Callable[[object], object],
) -> FiniteModel:
    return FiniteModel(
        carriers={V: tuple(v_elems), W: tuple(w_elems)},
        ops={"hv": hv},
        rels={
            "RV": frozenset(edges_g),  # edge relation of G
            "SW": frozenset(edges_h),  # edge relation of H
        },
    )


xV = Var("x", V)
zV = Var("z", V)
yV = Var("y", V)
aW = Var("a", W)
cW = Var("c", W)
bW = Var("b", W)

ctx_xzV = Context((xV, zV))
ctx_acW = Context((aW, cW))


def path2_G():
    # exists y. RV(x,y) & RV(y,z)
    return Exists(yV, And(Rel("RV", (v(xV), v(yV))), Rel("RV", (v(yV), v(zV)))))


def path2_H():
    # exists b. SW(a,b) & SW(b,c)
    return Exists(bW, And(Rel("SW", (v(aW), v(bW))), Rel("SW", (v(bW), v(cW)))))


def diagram_hh():
    # d : (x:V, z:V) -> (a:W, c:W),  a := hv(x), c := hv(z)
    return Diagram(
        source=ctx_xzV,
        target=ctx_acW,
        mapping=(("a", op("hv", v(xV))), ("c", op("hv", v(zV)))),
    )


def tile_preserves_path2() -> Tile:
    # path2_G |- d_hh^* path2_H
    return Tile(p=path2_G(), d=diagram_hh(), q=path2_H())


def tile_preserves_edges() -> Tile:
    # RV(x,z) |- d_hh^* SW(a,c)     (h is a graph homomorphism)
    return Tile(
        p=Rel("RV", (v(xV), v(zV))),
        d=diagram_hh(),
        q=Rel("SW", (v(aW), v(cW))),
    )
