"""
Metasketch-0 Phase 2 tests: higher-dimensional rewriting and coherence.

Verifies, by computation:
  - termination: the polynomial interpretation strictly decreases on every step,
    and normalization halts;
  - confluence: two different redex-selection strategies give the same normal
    form on random ground terms (operational confluence), consistent with
    Newman's lemma given termination and joinable critical pairs;
  - critical pairs: every critical pair of the monoid presentation is joinable,
    and they are enumerated;
  - the pentagon: the alpha-with-alpha critical pair has the directed
    rewrite-theoretic pentagon shape, with a 2-step and a 3-step route stored
    in one explicit confluence filler;
  - unit-related branchings: alpha/unit and unit/unit critical pairs are joinable;
  - decision procedure: the rewriting decides the free-monoid word problem, i.e.
    the normal form is the right comb of the underlying atom word, matching a
    flatten oracle.
"""

from __future__ import annotations
import random
from typing import List

from .rewriting import (
    Term, Rule, normalize, redexes, rewrite_at, critical_pairs, joinable,
    _order_outermost_leftmost, _order_innermost_rightmost,
    is_var, is_atom, is_app, args_of, pretty,
)
from .coherence import (
    m, E, a, b, c, d, MONOID_RULES, interp,
    pentagon_cell, critical_pair_filler, termination_argument,
    pentagon_source_term, pentagon_target_term,
)
from .tests import Report


# ---------------------------------------------------------------------------
# helpers: leaves, right comb, flatten oracle
# ---------------------------------------------------------------------------

def flatten_leaves(t: Term) -> List[Term]:
    """Underlying word: leaves left to right, dropping the unit e."""
    if is_var(t) or is_atom(t):
        return [t]
    if is_app(t) and t[0] == "e":
        return []
    if is_app(t) and t[0] == "m":
        l, r = args_of(t)
        return flatten_leaves(l) + flatten_leaves(r)
    raise ValueError(f"unexpected term {pretty(t)}")


def right_comb(leaves: List[Term]) -> Term:
    if not leaves:
        return E
    if len(leaves) == 1:
        return leaves[0]
    return m(leaves[0], right_comb(leaves[1:]))


def gen_term(rng: random.Random, depth: int) -> Term:
    if depth <= 0 or rng.random() < 0.4:
        return rng.choice([a, b, c, d, E])
    return m(gen_term(rng, depth - 1), gen_term(rng, depth - 1))


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

def test_termination(rep: Report):
    rng = random.Random(20260701)
    bad = None
    total_steps = 0
    for _ in range(500):
        t = gen_term(rng, 5)
        # step manually, checking the interpretation strictly decreases
        guard = 0
        while True:
            rl = redexes(t, MONOID_RULES)
            if not rl:
                break
            pos, rule = _order_outermost_leftmost(rl)[0]
            before = interp(t)
            t = rewrite_at(t, pos, rule)
            after = interp(t)
            if not (after < before):
                bad = f"interp did not decrease: {before} -> {after} via {rule.name}@{pos}"
                break
            guard += 1
            total_steps += 1
            if guard > 100000:
                bad = "normalization did not halt"
                break
        if bad:
            break
    rep.check("Phase2 termination: interpretation strictly decreases every tested step",
              bad is None, bad or f"{total_steps} reduction steps checked; {termination_argument()}")


def test_confluence(rep: Report):
    rng = random.Random(11)
    bad = None
    checked = 0
    for _ in range(500):
        t = gen_term(rng, 5)
        nf1, _ = normalize(t, MONOID_RULES, order=_order_outermost_leftmost)
        nf2, _ = normalize(t, MONOID_RULES, order=_order_innermost_rightmost)
        if nf1 != nf2:
            bad = f"strategy-dependent normal form on {pretty(t)}: {pretty(nf1)} vs {pretty(nf2)}"
            break
        checked += 1
    rep.check("Phase2 confluence: normal form is strategy-independent",
              bad is None, bad or f"{checked} random terms, two strategies each")


def test_critical_pairs(rep: Report):
    cps = critical_pairs(MONOID_RULES)
    results = []
    all_join = True
    all_fillers = True
    for cp in cps:
        ok, nfo, nfi = joinable(cp, MONOID_RULES)
        all_join = all_join and ok
        try:
            filler = critical_pair_filler(cp, MONOID_RULES)
            filler_ok = filler.validate(MONOID_RULES)
        except ValueError:
            filler_ok = False
        all_fillers = all_fillers and filler_ok
        results.append((cp, ok, nfo, filler_ok))
    detail_lines = []
    for cp, ok, nf, filler_ok in results:
        detail_lines.append(
            f"    {cp.rule1}/{cp.rule2}@{cp.position}: "
            f"{pretty(cp.overlap)}  ->  {pretty(cp.outer)}  |  {pretty(cp.inner)}  "
            f"=> {pretty(nf)}  [{'joinable' if ok else 'NOT joinable'}; "
            f"{'filler stored' if filler_ok else 'NO filler'}]"
        )
    rep.check(f"Phase2 critical pairs: all {len(cps)} joinable (local confluence)",
              all_join, "\n" + "\n".join(detail_lines))
    rep.check("Phase2 critical pairs: every joinability proof is stored as a validated 3-cell",
              all_fillers, "\n" + "\n".join(detail_lines))
    return results


def test_pentagon(rep: Report):
    # The alpha/alpha overlap has the directed pentagon shape.
    cps = critical_pairs(MONOID_RULES)
    pent = [cp for cp in cps if cp.rule1 == "alpha" and cp.rule2 == "alpha" and cp.position == (0,)]
    rep.check("Phase2 pentagon: the alpha/alpha overlap has the directed pentagon shape",
              len(pent) == 1,
              "" if len(pent) == 1 else f"found {len(pent)} alpha/alpha (0,) overlaps")

    if pent:
        cp = pent[0]
        ok, nfo, nfi = joinable(cp, MONOID_RULES)
        want = right_comb(flatten_leaves(cp.overlap))
        rep.check("Phase2 pentagon: both routes reach the right-comb normal form",
                  ok and nfo == want and nfi == want,
                  f"outer={pretty(nfo)}, inner={pretty(nfi)}, want={pretty(want)}")

    cell = pentagon_cell()
    valid = cell.validate(MONOID_RULES)
    same_boundary = (
        cell.source == pentagon_source_term()
        and cell.target == pentagon_target_term()
        and cell.left.target == cell.right.target
    )
    rep.check("Phase2 directed pentagon 3-cell: stored traces are valid and share a boundary",
              valid and same_boundary,
              f"short route length={len(cell.left)}, long route length={len(cell.right)}, "
              f"common endpoints={cell.left.target == cell.right.target}")


def test_unit_coherence(rep: Report):
    cps = critical_pairs(MONOID_RULES)
    unit_cps = [cp for cp in cps
                if {cp.rule1, cp.rule2} & {"lam", "rho"}]
    all_join = all(joinable(cp, MONOID_RULES)[0] for cp in unit_cps)
    kinds = sorted({(cp.rule1, cp.rule2) for cp in unit_cps})
    rep.check("Phase2 unit coherence: all alpha/unit and unit/unit critical pairs joinable",
              all_join and len(unit_cps) > 0,
              f"{len(unit_cps)} unit critical pairs, kinds={kinds}")


def test_decision_procedure(rep: Report):
    rng = random.Random(99)
    nf_bad = None
    word_bad = None
    for _ in range(600):
        t = gen_term(rng, 5)
        nf, _ = normalize(t, MONOID_RULES)
        want = right_comb(flatten_leaves(t))
        if nf != want:
            nf_bad = f"nf({pretty(t)}) = {pretty(nf)} but right-comb = {pretty(want)}"
            break
    for _ in range(600):
        t1 = gen_term(rng, 5)
        t2 = gen_term(rng, 5)
        nf1, _ = normalize(t1, MONOID_RULES)
        nf2, _ = normalize(t2, MONOID_RULES)
        same_nf = (nf1 == nf2)
        same_word = (flatten_leaves(t1) == flatten_leaves(t2))
        if same_nf != same_word:
            word_bad = f"nf-equality {same_nf} but word-equality {same_word}"
            break
    rep.check("Phase2 decision procedure: normal form is the right comb of the atom word",
              nf_bad is None, nf_bad or "")
    rep.check("Phase2 decision procedure: rewriting decides the free-monoid word problem",
              word_bad is None, word_bad or "nf-equality matches flatten-oracle on all pairs")


def run() -> int:
    rep = Report()
    test_termination(rep)
    test_confluence(rep)
    test_critical_pairs(rep)
    test_pentagon(rep)
    test_unit_coherence(rep)
    test_decision_procedure(rep)

    print("=" * 72)
    print("Metasketch-0 Phase 2 test report (higher-dimensional rewriting)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
