"""Semantic SVG rendering for Metasketch v0.6.1.

The renderer consumes checked, normalized Metasketch objects rather than freehand
layout data.  Every node, wire, region, and 3-cell carries a semantic reference;
every SVG embeds a canonical scene manifest and SHA-256 audit hash.

The module deliberately supports a small set of showcase objects:

* directed monoid confluence cells;
* finite relational witness proofs;
* direct-versus-sequential witness transport cells; and
* quoted proof certificates behind level-raising membranes.

It is not a visual editor.  It is an auditable projection of already-validated
syntax and proof objects.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from hashlib import sha256
from html import escape
from pathlib import Path
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple
import json

from .coherence import CoherenceCell3
from .proofs import (
    PatternWitnessProof,
    WitnessTransportCoherenceCell3,
    normalize_pattern_witness_proof,
    normalize_transport_proof,
)
from .reflection import Code, quote
from .rewriting import pretty
from .raw_certificates import (
    BoundaryAssignmentProof,
    RawPatternCertificate,
    canonical_proof_from_raw,
    validate_raw_certificate,
)


# ---------------------------------------------------------------------------
# Scene language
# ---------------------------------------------------------------------------

VALID_PORT_DIRECTIONS = {"in", "out", "code_in", "code_out"}
VALID_REGION_KINDS = {"witness", "membrane"}


@dataclass(frozen=True)
class ScenePort:
    """A typed attachment point on a semantic scene node."""

    id: str
    node_id: str
    label: str
    sort: str
    direction: str
    semantic_ref: str

    def __post_init__(self) -> None:
        if self.direction not in VALID_PORT_DIRECTIONS:
            raise ValueError(f"unknown port direction {self.direction!r}")
        if not self.semantic_ref:
            raise ValueError("scene ports require a semantic reference")


@dataclass(frozen=True)
class SceneNode:
    """A visual node with a direct reference to a checked semantic object."""

    id: str
    kind: str
    label: str
    semantic_ref: str
    x: int
    y: int
    width: int
    height: int
    parent_region: Optional[str] = None
    ports: Tuple[ScenePort, ...] = ()

    def __post_init__(self) -> None:
        if not self.semantic_ref:
            raise ValueError("scene nodes require a semantic reference")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("scene-node dimensions must be positive")
        for port in self.ports:
            if port.node_id != self.id:
                raise ValueError("scene port must name its owning node")


@dataclass(frozen=True)
class SceneRegion:
    """A scoped witness or quotation membrane region."""

    id: str
    kind: str
    label: str
    semantic_ref: str
    x: int
    y: int
    width: int
    height: int
    member_nodes: Tuple[str, ...]
    parent_region: Optional[str] = None
    bound_variable: Optional[str] = None
    binder_node_id: Optional[str] = None
    level: Optional[int] = None

    def __post_init__(self) -> None:
        if self.kind not in VALID_REGION_KINDS:
            raise ValueError(f"unsupported region kind {self.kind!r}")
        if not self.semantic_ref:
            raise ValueError("scene regions require a semantic reference")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("scene-region dimensions must be positive")
        if self.kind == "witness" and (not self.bound_variable or not self.binder_node_id):
            raise ValueError("witness regions require a bound variable and binder node")
        if self.kind == "membrane" and self.level is None:
            raise ValueError("quotation membranes require a level")


@dataclass(frozen=True)
class SceneEdge:
    """A semantic wire, rewrite, transport route, or code crossing."""

    id: str
    kind: str
    source_port: str
    target_port: str
    semantic_ref: str
    label: str = ""

    def __post_init__(self) -> None:
        if not self.semantic_ref:
            raise ValueError("scene edges require a semantic reference")


@dataclass(frozen=True)
class BoundaryTrace:
    """One 2-dimensional boundary path of a rendered 3-cell."""

    source_node: str
    target_node: str
    step_ids: Tuple[str, ...]
    semantic_ref: str

    def __post_init__(self) -> None:
        if not self.semantic_ref:
            raise ValueError("boundary traces require a semantic reference")


@dataclass(frozen=True)
class SceneCell3:
    """A filled 3-cell between parallel scene traces."""

    id: str
    label: str
    semantic_ref: str
    left: BoundaryTrace
    right: BoundaryTrace
    x: int
    y: int
    width: int
    height: int

    def __post_init__(self) -> None:
        if not self.semantic_ref:
            raise ValueError("3-cells require a semantic reference")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("3-cell dimensions must be positive")


@dataclass(frozen=True)
class RenderScene:
    """A validated, deterministic scene that can be serialized to SVG."""

    title: str
    width: int
    height: int
    nodes: Tuple[SceneNode, ...]
    regions: Tuple[SceneRegion, ...] = ()
    edges: Tuple[SceneEdge, ...] = ()
    cells3: Tuple[SceneCell3, ...] = ()
    semantic_root: str = ""

    def __post_init__(self) -> None:
        if self.width <= 0 or self.height <= 0:
            raise ValueError("scene dimensions must be positive")
        if not self.semantic_root:
            raise ValueError("every scene needs a semantic root")
        self.validate()

    def _node_table(self) -> Dict[str, SceneNode]:
        return {node.id: node for node in self.nodes}

    def _port_table(self) -> Dict[str, ScenePort]:
        return {
            port.id: port
            for node in self.nodes
            for port in node.ports
        }

    def _region_table(self) -> Dict[str, SceneRegion]:
        return {region.id: region for region in self.regions}

    def validate(self) -> None:
        """Validate the semantic topology before any SVG is emitted."""

        node_ids = [node.id for node in self.nodes]
        region_ids = [region.id for region in self.regions]
        edge_ids = [edge.id for edge in self.edges]
        cell_ids = [cell.id for cell in self.cells3]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("scene has duplicate node ids")
        if len(region_ids) != len(set(region_ids)):
            raise ValueError("scene has duplicate region ids")
        if len(edge_ids) != len(set(edge_ids)):
            raise ValueError("scene has duplicate edge ids")
        if len(cell_ids) != len(set(cell_ids)):
            raise ValueError("scene has duplicate 3-cell ids")
        if set(node_ids) & set(region_ids):
            raise ValueError("node and region ids must be globally distinct")

        nodes = self._node_table()
        ports = self._port_table()
        regions = self._region_table()
        if len(ports) != sum(len(node.ports) for node in self.nodes):
            raise ValueError("scene has duplicate port ids")

        for node in self.nodes:
            if node.parent_region is not None:
                if node.parent_region not in regions:
                    raise ValueError(f"node {node.id} names an unknown parent region")
                if node.id not in regions[node.parent_region].member_nodes:
                    raise ValueError(f"node {node.id} is missing from its parent region member list")
        for region in self.regions:
            if region.parent_region is not None and region.parent_region not in regions:
                raise ValueError(f"region {region.id} names an unknown parent region")
            for member in region.member_nodes:
                if member not in nodes:
                    raise ValueError(f"region {region.id} names unknown node {member}")
            if region.kind == "witness":
                if region.binder_node_id not in region.member_nodes:
                    raise ValueError("a witness binder must be inside its witness region")
                binder = nodes[region.binder_node_id]
                if binder.kind != "witness_binder":
                    raise ValueError("witness-region binder node must have kind witness_binder")

        # Edges must connect compatible ports.  Regular data wires run out -> in;
        # quotation crossings must run code_out -> code_in.
        for edge in self.edges:
            if edge.source_port not in ports or edge.target_port not in ports:
                raise ValueError(f"edge {edge.id} names an unknown port")
            source, target = ports[edge.source_port], ports[edge.target_port]
            if edge.kind == "code":
                if source.direction != "code_out" or target.direction != "code_in":
                    raise ValueError("code edges must connect code_out to code_in")
            else:
                if source.direction != "out" or target.direction != "in":
                    raise ValueError(f"ordinary edge {edge.id} must connect out to in")
                if source.sort != target.sort:
                    raise ValueError(
                        f"ordinary edge {edge.id} has incompatible sorts "
                        f"{source.sort!r} and {target.sort!r}"
                    )

        # A witness wire may only feed relation inputs within its own witness
        # scope.  This implements the visual binding discipline.
        for region in self.regions:
            if region.kind != "witness":
                continue
            binder = nodes[region.binder_node_id]
            binder_ports = {port.id for port in binder.ports if port.direction == "out"}
            for edge in self.edges:
                if edge.source_port in binder_ports:
                    target_node = ports[edge.target_port].node_id
                    if target_node not in region.member_nodes:
                        raise ValueError(
                            f"bound witness {region.bound_variable!r} escapes its region via {edge.id}"
                        )

        # A membrane may only be crossed by a code edge.  All ordinary wires must
        # stay wholly inside or wholly outside a quotation membrane.
        for region in self.regions:
            if region.kind != "membrane":
                continue
            members = set(region.member_nodes)
            for edge in self.edges:
                source_node = ports[edge.source_port].node_id
                target_node = ports[edge.target_port].node_id
                crosses = (source_node in members) != (target_node in members)
                if crosses and edge.kind != "code":
                    raise ValueError(
                        f"ordinary edge {edge.id} illegally crosses quotation membrane {region.id}"
                    )

        edge_table = {edge.id: edge for edge in self.edges}

        def validate_trace(trace: BoundaryTrace) -> None:
            if trace.source_node not in nodes or trace.target_node not in nodes:
                raise ValueError("3-cell boundary endpoints must be scene nodes")
            if not trace.step_ids:
                raise ValueError("3-cell boundaries must contain at least one edge")
            current = trace.source_node
            for step in trace.step_ids:
                if step not in edge_table:
                    raise ValueError(f"3-cell boundary names unknown edge {step}")
                edge = edge_table[step]
                if ports[edge.source_port].node_id != current:
                    raise ValueError(
                        f"3-cell boundary edge {step} does not continue from node {current}"
                    )
                current = ports[edge.target_port].node_id
            if current != trace.target_node:
                raise ValueError(
                    f"3-cell boundary ends at {current}, expected {trace.target_node}"
                )

        for cell in self.cells3:
            if cell.left.source_node != cell.right.source_node:
                raise ValueError("3-cell boundaries must share a source node")
            if cell.left.target_node != cell.right.target_node:
                raise ValueError("3-cell boundaries must share a target node")
            validate_trace(cell.left)
            validate_trace(cell.right)

    def semantic_manifest(self) -> Mapping[str, object]:
        """A label- and layout-independent canonical description of the scene."""

        def port_manifest(port: ScenePort) -> Mapping[str, object]:
            return {
                "id": port.id,
                "node": port.node_id,
                "sort": port.sort,
                "direction": port.direction,
                "semantic": port.semantic_ref,
            }

        return {
            "title": self.title,
            "semantic_root": self.semantic_root,
            "nodes": [
                {
                    "id": node.id,
                    "kind": node.kind,
                    "semantic": node.semantic_ref,
                    "parent_region": node.parent_region,
                    "ports": [port_manifest(port) for port in node.ports],
                }
                for node in sorted(self.nodes, key=lambda item: item.id)
            ],
            "regions": [
                {
                    "id": region.id,
                    "kind": region.kind,
                    "semantic": region.semantic_ref,
                    "members": sorted(region.member_nodes),
                    "parent_region": region.parent_region,
                    "bound_variable": region.bound_variable,
                    "binder_node": region.binder_node_id,
                    "level": region.level,
                }
                for region in sorted(self.regions, key=lambda item: item.id)
            ],
            "edges": [
                {
                    "id": edge.id,
                    "kind": edge.kind,
                    "source": edge.source_port,
                    "target": edge.target_port,
                    "semantic": edge.semantic_ref,
                }
                for edge in sorted(self.edges, key=lambda item: item.id)
            ],
            "cells3": [
                {
                    "id": cell.id,
                    "semantic": cell.semantic_ref,
                    "left": {
                        "source": cell.left.source_node,
                        "target": cell.left.target_node,
                        "steps": list(cell.left.step_ids),
                        "semantic": cell.left.semantic_ref,
                    },
                    "right": {
                        "source": cell.right.source_node,
                        "target": cell.right.target_node,
                        "steps": list(cell.right.step_ids),
                        "semantic": cell.right.semantic_ref,
                    },
                }
                for cell in sorted(self.cells3, key=lambda item: item.id)
            ],
        }

    def canonical_json(self) -> str:
        return json.dumps(self.semantic_manifest(), sort_keys=True, separators=(",", ":"), ensure_ascii=True)

    def audit_hash(self) -> str:
        return sha256(self.canonical_json().encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class RenderedArtifact:
    """A scene plus the deterministic SVG generated from it."""

    scene: RenderScene
    svg: str

    @property
    def audit_hash(self) -> str:
        return self.scene.audit_hash()

    def write_svg(self, path: Path | str) -> Path:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(self.svg, encoding="utf-8")
        return destination


# ---------------------------------------------------------------------------
# SVG serialization
# ---------------------------------------------------------------------------


def _attrs(**attrs: object) -> str:
    return " ".join(
        f'{name}="{escape(str(value), quote=True)}"'
        for name, value in attrs.items()
        if value is not None
    )


def _center_port(node: SceneNode, port: ScenePort) -> Tuple[int, int]:
    # Deterministic side placement.  Multiple ports of the same direction are
    # spread vertically over the node height.
    peers = [item for item in node.ports if item.direction == port.direction]
    index = peers.index(port)
    gap = node.height // (len(peers) + 1)
    y = node.y + gap * (index + 1)
    if port.direction in {"out", "code_out"}:
        return node.x + node.width, y
    return node.x, y


def _node_svg(node: SceneNode) -> str:
    kind_class = "node-" + node.kind
    lines = [
        f'<g {_attrs(id=node.id, **{"class": kind_class, "data-semantic": node.semantic_ref})}>',
        f'  <rect {_attrs(x=node.x, y=node.y, width=node.width, height=node.height, rx=10, ry=10)} />',
        f'  <text {_attrs(x=node.x + node.width // 2, y=node.y + 22, **{"text-anchor": "middle", "class": "node-label"})}>{escape(node.label)}</text>',
    ]
    for port in node.ports:
        x, y = _center_port(node, port)
        lines.append(
            f'  <circle {_attrs(id=port.id, cx=x, cy=y, r=4, **{"class": "port", "data-sort": port.sort, "data-direction": port.direction, "data-semantic": port.semantic_ref})} />'
        )
    lines.append("</g>")
    return "\n".join(lines)


def _region_svg(region: SceneRegion) -> str:
    klass = "region-" + region.kind
    dash = "8 6" if region.kind == "membrane" else "5 4"
    title = region.label
    if region.kind == "membrane" and region.level is not None:
        title += f"  level {region.level}"
    return "\n".join(
        [
            f'<g {_attrs(id=region.id, **{"class": klass, "data-semantic": region.semantic_ref})}>',
            f'  <rect {_attrs(x=region.x, y=region.y, width=region.width, height=region.height, rx=16, ry=16, **{"stroke-dasharray": dash})} />',
            f'  <text {_attrs(x=region.x + 12, y=region.y + 20, **{"class": "region-label"})}>{escape(title)}</text>',
            "</g>",
        ]
    )


def _edge_svg(edge: SceneEdge, nodes: Mapping[str, SceneNode], ports: Mapping[str, ScenePort]) -> str:
    source_port, target_port = ports[edge.source_port], ports[edge.target_port]
    sx, sy = _center_port(nodes[source_port.node_id], source_port)
    tx, ty = _center_port(nodes[target_port.node_id], target_port)
    mx = (sx + tx) // 2
    curve = max(28, abs(tx - sx) // 3)
    marker = "arrow-code" if edge.kind == "code" else "arrow"
    klass = "edge-" + edge.kind
    label = ""
    if edge.label:
        label = f'<text {_attrs(x=mx, y=(sy + ty) // 2 - 7, **{"class": "edge-label", "text-anchor": "middle"})}>{escape(edge.label)}</text>'
    return "\n".join(
        [
            f'<g {_attrs(id=edge.id, **{"class": klass, "data-semantic": edge.semantic_ref})}>',
            f'  <path {_attrs(d=f"M {sx} {sy} C {sx + curve} {sy}, {tx - curve} {ty}, {tx} {ty}", **{"marker-end": f"url(#{marker})"})} />',
            f"  {label}" if label else "",
            "</g>",
        ]
    )


def _cell_svg(cell: SceneCell3) -> str:
    return "\n".join(
        [
            f'<g {_attrs(id=cell.id, **{"class": "cell3", "data-semantic": cell.semantic_ref})}>',
            f'  <rect {_attrs(x=cell.x, y=cell.y, width=cell.width, height=cell.height, rx=12, ry=12)} />',
            f'  <text {_attrs(x=cell.x + cell.width // 2, y=cell.y + cell.height // 2 + 5, **{"class": "cell3-label", "text-anchor": "middle"})}>{escape(cell.label)}</text>',
            "</g>",
        ]
    )


def scene_to_svg(scene: RenderScene) -> str:
    """Serialize a validated scene to a self-auditing standalone SVG."""

    scene.validate()
    nodes = scene._node_table()
    ports = scene._port_table()
    metadata = json.dumps(
        {"audit_hash": scene.audit_hash(), "semantic_manifest": scene.semantic_manifest()},
        sort_keys=True,
        ensure_ascii=True,
    )
    styles = """
    .node-structure rect { fill: #f6f7fb; stroke: #313b59; stroke-width: 2; }
    .node-boundary rect { fill: #eef9f2; stroke: #2f7a56; stroke-width: 2; stroke-dasharray: 5 3; }
    .node-relation rect { fill: #f8fbef; stroke: #526b31; stroke-width: 2; }
    .node-witness_binder rect { fill: #fff7e8; stroke: #9d6b1d; stroke-width: 2; }
    .node-proof rect { fill: #f4f0ff; stroke: #624a91; stroke-width: 2; }
    .node-quote rect { fill: #effafd; stroke: #276d7c; stroke-width: 2; }
    .node-checker rect { fill: #effafd; stroke: #276d7c; stroke-width: 2; }
    .node-trace rect { fill: #f6f7fb; stroke: #313b59; stroke-width: 2; }
    .node-terminal rect { fill: #f6f7fb; stroke: #313b59; stroke-width: 2; }
    .node-label { font: 13px sans-serif; fill: #1c2331; }
    .region-witness rect { fill: #fffdf6; stroke: #9d6b1d; stroke-width: 2; }
    .region-membrane rect { fill: #f5fcfd; stroke: #276d7c; stroke-width: 3; }
    .region-label { font: 13px sans-serif; font-weight: 600; fill: #34405b; }
    .port { fill: #1f2937; stroke: #ffffff; stroke-width: 1; }
    .edge-term_wire path, .edge-rewrite path, .edge-transport path { fill: none; stroke: #3f4c6b; stroke-width: 2; }
    .edge-code path { fill: none; stroke: #276d7c; stroke-width: 3; stroke-dasharray: 7 4; }
    .edge-label { font: 11px sans-serif; fill: #34405b; }
    .cell3 rect { fill: #eee9fb; stroke: #624a91; stroke-width: 2; }
    .cell3-label { font: 12px sans-serif; font-weight: 600; fill: #49366e; }
    """
    body = []
    body.extend(_region_svg(region) for region in sorted(scene.regions, key=lambda item: item.width * item.height, reverse=True))
    body.extend(_edge_svg(edge, nodes, ports) for edge in scene.edges)
    body.extend(_node_svg(node) for node in scene.nodes)
    body.extend(_cell_svg(cell) for cell in scene.cells3)
    return "\n".join(
        [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg {_attrs(xmlns="http://www.w3.org/2000/svg", width=scene.width, height=scene.height, viewBox=f"0 0 {scene.width} {scene.height}", role="img", **{"aria-label": scene.title})}>',
            f"  <title>{escape(scene.title)}</title>",
            f"  <metadata id=\"metasketch-audit\">{escape(metadata)}</metadata>",
            "  <defs>",
            "    <marker id=\"arrow\" markerWidth=\"9\" markerHeight=\"9\" refX=\"8\" refY=\"4.5\" orient=\"auto\"><path d=\"M0,0 L9,4.5 L0,9 Z\" fill=\"#3f4c6b\" /></marker>",
            "    <marker id=\"arrow-code\" markerWidth=\"9\" markerHeight=\"9\" refX=\"8\" refY=\"4.5\" orient=\"auto\"><path d=\"M0,0 L9,4.5 L0,9 Z\" fill=\"#276d7c\" /></marker>",
            f"    <style>{styles}</style>",
            "  </defs>",
            *["  " + line if line else "" for item in body for line in item.splitlines()],
            "</svg>",
        ]
    )


# ---------------------------------------------------------------------------
# Semantic scene builders
# ---------------------------------------------------------------------------


def _make_port(node_id: str, suffix: str, label: str, sort: str, direction: str, semantic_ref: str) -> ScenePort:
    return ScenePort(f"{node_id}_{suffix}", node_id, label, sort, direction, semantic_ref)


def render_pattern_witness(
    proof: PatternWitnessProof,
    *,
    boundary_assignments: Mapping[str, BoundaryAssignmentProof] | None = None,
    title_override: str | None = None,
    semantic_root_override: str | None = None,
) -> RenderedArtifact:
    """Render a canonical finite relational witness proof as an SVG artifact.

    ``boundary_assignments`` marks visible values supplied by pointed external
    context evidence rather than relation atoms.  Those nodes stay outside every
    existential witness scope and are drawn with the ``boundary`` visual class.
    """

    normal = normalize_pattern_witness_proof(proof)
    boundary_assignments = dict(boundary_assignments or {})
    pattern = proof.pattern
    table = pattern.variable_table()
    values = dict(normal.assignments)
    nodes = []
    regions = []
    edges = []

    visible = list(pattern.visible)
    hidden = list(pattern.hidden)
    visible_nodes: Dict[str, SceneNode] = {}
    witness_nodes: Dict[str, SceneNode] = {}

    for index, label in enumerate(visible):
        variable = table[label]
        node_id = f"visible_{label}"
        boundary = boundary_assignments.get(label)
        kind = "boundary" if boundary is not None else "structure"
        shown = (
            f"input {label}:{variable.sort.name} = {values[label]!r}"
            if boundary is not None
            else f"{label}:{variable.sort.name} = {values[label]!r}"
        )
        semantic_ref = (
            f"boundary_assignment:{label}={values[label]!r}:display={boundary.display_label!r}"
            if boundary is not None
            else f"visible_assignment:{label}={values[label]!r}"
        )
        node = SceneNode(
            node_id,
            kind,
            shown,
            semantic_ref,
            35,
            100 + 90 * index,
            170 if boundary is not None else 150,
            48,
            ports=(_make_port(node_id, "out", label, variable.sort.name, "out", semantic_ref),),
        )
        nodes.append(node)
        visible_nodes[label] = node

    witness_members = []
    for index, label in enumerate(hidden):
        variable = table[label]
        node_id = f"witness_{label}"
        node = SceneNode(
            node_id,
            "witness_binder",
            f"∃ {label}:{variable.sort.name} = {values[label]!r}",
            f"existential_witness:{label}={values[label]!r}",
            255,
            120 + 100 * index,
            170,
            52,
            parent_region=f"scope_{label}",
            ports=(_make_port(node_id, "out", label, variable.sort.name, "out", f"witness:{label}"),),
        )
        nodes.append(node)
        witness_nodes[label] = node
        witness_members.append(node_id)

    # Relation boxes sit inside all witness scopes.  The nested regions are
    # rendered with the largest scope first, and each bound wire only targets
    # nodes in its own scope.
    relation_nodes = []
    atom_nodes: Dict[int, SceneNode] = {}
    base_y = 135
    for index, atom in enumerate(pattern.atoms):
        node_id = f"atom_{index}"
        args = ", ".join(f"{arg}={values[arg]!r}" for arg in atom.args)
        node = SceneNode(
            node_id,
            "relation",
            f"{atom.relation}({args})",
            f"atom:{index}:{atom.relation}{atom.args!r}",
            525,
            base_y + 75 * index,
            330,
            56,
            parent_region=f"scope_{hidden[-1]}" if hidden else None,
            ports=tuple(
                _make_port(
                    node_id,
                    f"in_{arg_index}",
                    arg,
                    table[arg].sort.name,
                    "in",
                    f"atom_argument:{index}:{arg_index}:{arg}",
                )
                for arg_index, arg in enumerate(atom.args)
            ),
        )
        nodes.append(node)
        relation_nodes.append(node_id)
        atom_nodes[index] = node

    # Create nested witness regions after relation nodes have been allocated.
    # The outermost witness region has the lowest hidden-variable index.
    for index, label in reversed(list(enumerate(hidden))):
        members = set(relation_nodes)
        members.add(f"witness_{label}")
        for later in hidden[index + 1:]:
            members.add(f"witness_{later}")
        regions.append(
            SceneRegion(
                id=f"scope_{label}",
                kind="witness",
                label=f"witness scope for ∃{label}",
                semantic_ref=f"existential_scope:{label}",
                x=205 + 20 * index,
                y=35 + 50 * index,
                width=700 - 40 * index,
                height=max(410 - 40 * index, 90 + 72 * len(pattern.atoms)),
                member_nodes=tuple(sorted(members)),
                parent_region=f"scope_{hidden[index - 1]}" if index > 0 else None,
                bound_variable=label,
                binder_node_id=f"witness_{label}",
            )
        )
    # Make actual parent-region assignments agree with nested member lists.
    # The innermost scope owns relation nodes.  Outer scopes contain the inner
    # witness binders but no node claims them as direct parent.
    if hidden:
        innermost = f"scope_{hidden[-1]}"
        repaired_nodes = []
        for node in nodes:
            if node.id in relation_nodes and node.parent_region != innermost:
                repaired_nodes.append(SceneNode(**{**node.__dict__, "parent_region": innermost}))
            else:
                repaired_nodes.append(node)
        nodes = repaired_nodes

    # Connect each variable occurrence to exactly one typed relation input.
    for index, atom in enumerate(pattern.atoms):
        target_node = atom_nodes[index]
        for arg_index, label in enumerate(atom.args):
            source_node = visible_nodes.get(label) or witness_nodes[label]
            source_port = next(port for port in source_node.ports if port.direction == "out")
            target_port = next(port for port in target_node.ports if port.label == label)
            edges.append(
                SceneEdge(
                    f"wire_{label}_to_{index}_{arg_index}",
                    "term_wire",
                    source_port.id,
                    target_port.id,
                    f"witness_argument:{label}->atom:{index}:{arg_index}",
                    label,
                )
            )

    scene = RenderScene(
        title=title_override or f"Metasketch witness certificate: {pattern.name}",
        width=910,
        height=max(500, 175 + 82 * len(pattern.atoms)),
        nodes=tuple(nodes),
        regions=tuple(regions),
        edges=tuple(edges),
        semantic_root=semantic_root_override or f"PatternWitnessProof:{normal.pattern}:{normal.assignments!r}",
    )
    return RenderedArtifact(scene, scene_to_svg(scene))



def render_raw_certificate(raw: RawPatternCertificate) -> RenderedArtifact:
    """Render a checked pointed raw certificate with explicit boundary evidence.

    The raw object has no stored semantic match.  Rendering first replays raw
    reconstruction, then projects the reconstructed canonical proof while
    preserving the raw boundary nodes as visible external input ports.
    """

    reconstruction = validate_raw_certificate(raw)
    proof = canonical_proof_from_raw(raw)
    boundaries = {item.variable: item for item in raw.boundary}
    return render_pattern_witness(
        proof,
        boundary_assignments=boundaries,
        title_override=f"Metasketch pointed raw certificate: {raw.pattern.name}",
        semantic_root_override=(
            f"RawPatternCertificate:{raw.pattern.name}:"
            f"boundary={tuple((item.variable, item.value) for item in raw.boundary)!r}:"
            f"reconstructed={reconstruction.match.mapping!r}"
        ),
    )

def render_transport_coherence(cell: WitnessTransportCoherenceCell3) -> RenderedArtifact:
    """Render direct and sequential witness transport plus a stored 3-cell."""

    if not cell.validate():
        raise ValueError("cannot render an invalid witness transport coherence cell")
    direct_nf = normalize_transport_proof(cell.direct)
    source_label = f"source witness\n{direct_nf.source.pattern}"
    target_label = f"target witness\n{direct_nf.target.pattern}"
    sort = "WitnessCertificate"

    source = SceneNode(
        "source_witness", "proof", source_label, "transport_source_witness",
        55, 190, 150, 58,
        ports=(_make_port("source_witness", "out", "w", sort, "out", "source_witness"),),
    )
    direct = SceneNode(
        "direct_transport", "trace", "direct transport\n(k ∘ h)", "direct_transport_map",
        350, 72, 170, 58,
        ports=(
            _make_port("direct_transport", "in", "w", sort, "in", "direct_transport_input"),
            _make_port("direct_transport", "out", "w", sort, "out", "direct_transport_output"),
        ),
    )
    first = SceneNode(
        "first_transport", "trace", "transport h", "sequential_transport_h",
        255, 330, 140, 58,
        ports=(
            _make_port("first_transport", "in", "w", sort, "in", "first_transport_input"),
            _make_port("first_transport", "out", "w", sort, "out", "first_transport_output"),
        ),
    )
    second = SceneNode(
        "second_transport", "trace", "transport k", "sequential_transport_k",
        495, 330, 140, 58,
        ports=(
            _make_port("second_transport", "in", "w", sort, "in", "second_transport_input"),
            _make_port("second_transport", "out", "w", sort, "out", "second_transport_output"),
        ),
    )
    target = SceneNode(
        "target_witness", "proof", target_label, "transport_target_witness",
        740, 190, 150, 58,
        ports=(_make_port("target_witness", "in", "w", sort, "in", "target_witness"),),
    )
    edges = (
        SceneEdge("edge_direct_in", "transport", source.ports[0].id, direct.ports[0].id, "transport:direct:input"),
        SceneEdge("edge_direct_out", "transport", direct.ports[1].id, target.ports[0].id, "transport:direct:output"),
        SceneEdge("edge_h_in", "transport", source.ports[0].id, first.ports[0].id, "transport:h:input"),
        SceneEdge("edge_h_out", "transport", first.ports[1].id, second.ports[0].id, "transport:h:output=k:input"),
        SceneEdge("edge_k_out", "transport", second.ports[1].id, target.ports[0].id, "transport:k:output"),
    )
    three_cell = SceneCell3(
        "transport_coherence_cell3",
        "3-cell: direct = sequential",
        "WitnessTransportCoherenceCell3",
        BoundaryTrace("source_witness", "target_witness", ("edge_direct_in", "edge_direct_out"), "direct_trace"),
        BoundaryTrace("source_witness", "target_witness", ("edge_h_in", "edge_h_out", "edge_k_out"), "sequential_trace"),
        555, 184, 145, 68,
    )
    scene = RenderScene(
        title="Metasketch witness-transport coherence",
        width=945,
        height=445,
        nodes=(source, direct, first, second, target),
        edges=edges,
        cells3=(three_cell,),
        semantic_root=f"WitnessTransportCoherenceCell3:{direct_nf!r}",
    )
    return RenderedArtifact(scene, scene_to_svg(scene))


def render_pentagon(cell: CoherenceCell3) -> RenderedArtifact:
    """Render the stored directed rewrite-theoretic pentagon confluence cell."""

    if not cell.validate(__import__("metasketch0.coherence", fromlist=["MONOID_RULES"]).MONOID_RULES):
        raise ValueError("cannot render an invalid directed confluence cell")
    source_term = pretty(cell.source)
    target_term = pretty(cell.target)
    sort = "MonoidTerm"
    source = SceneNode(
        "pentagon_source", "structure", source_term, "pentagon_source_term",
        35, 205, 200, 56,
        ports=(_make_port("pentagon_source", "out", "term", sort, "out", "source_term"),),
    )
    short = SceneNode(
        "pentagon_short", "trace", f"short route\n{len(cell.left.steps)} alpha steps", "pentagon_short_trace",
        350, 72, 180, 58,
        ports=(
            _make_port("pentagon_short", "in", "term", sort, "in", "short_input"),
            _make_port("pentagon_short", "out", "term", sort, "out", "short_output"),
        ),
    )
    long1 = SceneNode(
        "pentagon_long1", "trace", "long route step 1", "pentagon_long_step1",
        240, 345, 155, 54,
        ports=(
            _make_port("pentagon_long1", "in", "term", sort, "in", "long1_input"),
            _make_port("pentagon_long1", "out", "term", sort, "out", "long1_output"),
        ),
    )
    long2 = SceneNode(
        "pentagon_long2", "trace", f"long route\n{len(cell.right.steps)} alpha steps", "pentagon_long_trace",
        470, 345, 170, 54,
        ports=(
            _make_port("pentagon_long2", "in", "term", sort, "in", "long2_input"),
            _make_port("pentagon_long2", "out", "term", sort, "out", "long2_output"),
        ),
    )
    target = SceneNode(
        "pentagon_target", "terminal", target_term, "pentagon_target_term",
        745, 205, 205, 56,
        ports=(_make_port("pentagon_target", "in", "term", sort, "in", "target_term"),),
    )
    edges = (
        SceneEdge("p_short_in", "rewrite", source.ports[0].id, short.ports[0].id, "pentagon_short_input"),
        SceneEdge("p_short_out", "rewrite", short.ports[1].id, target.ports[0].id, "pentagon_short_output"),
        SceneEdge("p_long_in", "rewrite", source.ports[0].id, long1.ports[0].id, "pentagon_long_input"),
        SceneEdge("p_long_mid", "rewrite", long1.ports[1].id, long2.ports[0].id, "pentagon_long_middle"),
        SceneEdge("p_long_out", "rewrite", long2.ports[1].id, target.ports[0].id, "pentagon_long_output"),
    )
    c3 = SceneCell3(
        "directed_pentagon_cell3",
        "directed pentagon 3-cell",
        cell.name,
        BoundaryTrace("pentagon_source", "pentagon_target", ("p_short_in", "p_short_out"), "short_rewrite_trace"),
        BoundaryTrace("pentagon_source", "pentagon_target", ("p_long_in", "p_long_mid", "p_long_out"), "long_rewrite_trace"),
        565, 195, 145, 68,
    )
    scene = RenderScene(
        title="Metasketch directed associator-pentagon confluence filler",
        width=990,
        height=435,
        nodes=(source, short, long1, long2, target),
        edges=edges,
        cells3=(c3,),
        semantic_root=f"CoherenceCell3:{cell.name}:{source_term}->{target_term}",
    )
    return RenderedArtifact(scene, scene_to_svg(scene))


def render_quoted_proof(proof: PatternWitnessProof, *, source_level: int = 0) -> RenderedArtifact:
    """Render a quoted finite proof behind a strictly level-raising membrane."""

    normal = normalize_pattern_witness_proof(proof)
    code: Code = quote(normal, "proof_certificate", source_level)
    code_sort = f"Code[{code.code_level}:Proof[{code.source_level}]]"
    quote_node = SceneNode(
        "quoted_proof", "quote", f"⌜{normal.pattern} witness proof⌝", "quote:PatternWitnessProof",
        110, 145, 280, 62,
        parent_region="quote_membrane",
        ports=(_make_port("quoted_proof", "code_out", "code", code_sort, "code_out", "quoted_proof_code"),),
    )
    checker = SceneNode(
        "higher_checker", "checker", f"check at level {code.code_level}", "check:quoted_proof",
        620, 145, 220, 62,
        ports=(_make_port("higher_checker", "code_in", "code", code_sort, "code_in", "checker_code_input"),),
    )
    membrane = SceneRegion(
        "quote_membrane", "membrane", f"quotation membrane: proof level {source_level}",
        f"Code:{code.kind}:level:{code.code_level}",
        55, 85, 400, 190,
        member_nodes=("quoted_proof",),
        level=code.code_level,
    )
    edge = SceneEdge(
        "quoted_code_crossing", "code", quote_node.ports[0].id, checker.ports[0].id,
        f"typed_quote_check:{code.source_level}->{code.code_level}",
        "typed code port",
    )
    scene = RenderScene(
        title="Metasketch typed quotation membrane",
        width=900,
        height=340,
        nodes=(quote_node, checker),
        regions=(membrane,),
        edges=(edge,),
        semantic_root=f"Code:{code.kind}:source={code.source_level}:code={code.code_level}:{normal!r}",
    )
    return RenderedArtifact(scene, scene_to_svg(scene))


__all__ = [
    "BoundaryTrace",
    "RenderedArtifact",
    "RenderScene",
    "SceneCell3",
    "SceneEdge",
    "SceneNode",
    "ScenePort",
    "SceneRegion",
    "render_pentagon",
    "render_pattern_witness",
    "render_raw_certificate",
    "render_quoted_proof",
    "render_transport_coherence",
    "scene_to_svg",
]
