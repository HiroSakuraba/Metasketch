"""Metasketch-0 v0.8 finite prototype."""

"""Metasketch-0: a small, testable kernel for a stratified diagrammatic calculus.

Public code should start with :mod:`metasketch0.api`.  Internal and experimental
raw AST construction remains available in :mod:`metasketch0.unsafe_ast`.
"""

from . import api  # noqa: F401

__all__ = ["api"]
