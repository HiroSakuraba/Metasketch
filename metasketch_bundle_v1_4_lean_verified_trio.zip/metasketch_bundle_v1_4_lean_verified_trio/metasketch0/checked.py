"""Checked public-construction boundary for Metasketch.

The raw dataclasses in :mod:`metasketch0.syntax` remain available for internal
experiments and serialization tests, but they are not the supported API for
trusted construction.  Public clients should construct objects through this
module or :mod:`metasketch0.api`.

Every checked wrapper records the signature and context against which it was
validated.  The renderer, quotation layer, and theorem-facing certificate tools
accept checked or independently revalidated objects only.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Mapping, Sequence, Tuple

from .semantics import FiniteModel, validate_finite_model
from .syntax import (
    Context,
    Diagram,
    Pred,
    Signature,
    Sort,
    Term,
    Var,
    infer_term_sort,
    validate_diagram,
    validate_pred,
    validate_tile_syntax,
)
from .tiles import Tile


class PublicConstructionError(ValueError):
    """Raised when a public checked constructor receives ill-formed data."""


@dataclass(frozen=True)
class CheckedContext:
    """A context whose variables belong to one declared signature."""

    signature: Signature
    context: Context

    def __post_init__(self) -> None:
        for variable in self.context.vars:
            if variable.sort not in self.signature.sorts:
                raise PublicConstructionError(
                    f"context variable {variable!r} uses undeclared sort {variable.sort!r}"
                )


@dataclass(frozen=True)
class CheckedTerm:
    """A term validated against a signature and free-variable context."""

    signature: Signature
    context: Context
    term: Term
    sort: Sort

    def __post_init__(self) -> None:
        inferred = infer_term_sort(self.term, self.signature, self.context)
        if inferred != self.sort:
            raise PublicConstructionError(
                f"checked term declares sort {self.sort!r}, inferred {inferred!r}"
            )


@dataclass(frozen=True)
class CheckedPredicate:
    """A predicate validated in one declared context and signature."""

    signature: Signature
    context: Context
    predicate: Pred

    def __post_init__(self) -> None:
        validate_pred(self.predicate, self.signature, self.context)


@dataclass(frozen=True)
class CheckedDiagram:
    """A structural diagram validated against one declared signature."""

    signature: Signature
    diagram: Diagram

    def __post_init__(self) -> None:
        validate_diagram(self.diagram, self.signature)


@dataclass(frozen=True)
class CheckedTile:
    """A preservation tile whose syntax has passed the static checker."""

    signature: Signature
    tile: Tile

    def __post_init__(self) -> None:
        validate_tile_syntax(self.tile.p, self.tile.d, self.tile.q, self.signature)


@dataclass(frozen=True)
class CheckedModel:
    """A finite model exhaustively validated against one signature."""

    signature: Signature
    model: FiniteModel

    def __post_init__(self) -> None:
        validate_finite_model(self.model, self.signature)


# ---------------------------------------------------------------------------
# Public factories
# ---------------------------------------------------------------------------

def checked_context(signature: Signature, variables: Sequence[Var]) -> CheckedContext:
    """Construct and validate a public context."""

    return CheckedContext(signature, Context(tuple(variables)))


def checked_term(signature: Signature, context: Context, term: Term) -> CheckedTerm:
    """Validate a term and retain its inferred sort in the trusted wrapper."""

    return CheckedTerm(signature, context, term, infer_term_sort(term, signature, context))


def checked_predicate(signature: Signature, context: Context, predicate: Pred) -> CheckedPredicate:
    return CheckedPredicate(signature, context, predicate)


def checked_diagram(signature: Signature, diagram: Diagram) -> CheckedDiagram:
    return CheckedDiagram(signature, diagram)


def checked_tile(signature: Signature, tile: Tile) -> CheckedTile:
    return CheckedTile(signature, tile)


def checked_model(signature: Signature, model: FiniteModel) -> CheckedModel:
    return CheckedModel(signature, model)


def model_from_parts(
    signature: Signature,
    carriers: Mapping[Sort, Sequence[object]],
    operations: Mapping[str, Callable[..., object]],
    relations: Mapping[str, Sequence[Tuple[object, ...]]],
) -> CheckedModel:
    """Build a finite model and validate all carriers, arities, and codomains.

    This is the preferred programmatic frontend.  It is deliberately not a
    parser-only API: proof search and theorem-prover integrations need checked
    synthesis as well as checked parsing.
    """

    model = FiniteModel(
        carriers={sort: tuple(values) for sort, values in carriers.items()},
        ops=dict(operations),
        rels={name: frozenset(tuple(item) for item in values) for name, values in relations.items()},
    )
    return checked_model(signature, model)


__all__ = [
    "PublicConstructionError",
    "CheckedContext",
    "CheckedTerm",
    "CheckedPredicate",
    "CheckedDiagram",
    "CheckedTile",
    "CheckedModel",
    "checked_context",
    "checked_term",
    "checked_predicate",
    "checked_diagram",
    "checked_tile",
    "checked_model",
    "model_from_parts",
]
