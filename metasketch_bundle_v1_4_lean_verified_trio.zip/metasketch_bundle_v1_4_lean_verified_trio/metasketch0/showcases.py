"""Checked showcase inputs and artifact generation for Metasketch v0.6.1."""

from __future__ import annotations

from pathlib import Path
from typing import Dict

from .coherence import pentagon_cell
from .proofs import build_pattern_witness_proof, make_transport_coherence_cell
from .relational import find_relational_matches
from .render import (
    RenderedArtifact,
    render_pentagon,
    render_pattern_witness,
    render_raw_certificate,
    render_quoted_proof,
    render_transport_coherence,
)


def relational_witness_showcase(source=None):
    """Return the canonical Phase-4 commuter-pattern witness proof.

    When a source model is supplied it is used verbatim, which matters because
    relational transport intentionally checks model identity, not only equality.
    """
    from .tests_phase4 import commuter_friend_pattern, source_model

    pattern = commuter_friend_pattern()
    model = source if source is not None else source_model()
    match = find_relational_matches(pattern, model)[0]
    return build_pattern_witness_proof(match)


def transport_showcase_cell():
    """Return the checked direct-versus-sequential relational transport 3-cell."""
    from .tests_phase4 import hom_chain

    source, _, _, first, second = hom_chain()
    proof = relational_witness_showcase(source)
    return make_transport_coherence_cell(proof, first, second)


def pointed_boundary_showcase():
    """Return a raw pointed certificate with an external visible input node."""
    from .proofs import TruthProof
    from .raw_certificates import BoundaryAssignmentProof, RawPatternCertificate
    from .tests_phase7 import pointed_truth_pattern
    from .tests_phase4 import source_model

    return RawPatternCertificate(
        pointed_truth_pattern(),
        source_model(),
        TruthProof(),
        (BoundaryAssignmentProof("p", "u", "selected_person"),),
    )


def build_showcase_artifacts() -> Dict[str, RenderedArtifact]:
    proof = relational_witness_showcase()
    return {
        "directed_pentagon": render_pentagon(pentagon_cell()),
        "relational_witness": render_pattern_witness(proof),
        "transport_coherence": render_transport_coherence(transport_showcase_cell()),
        "quoted_proof_membrane": render_quoted_proof(proof, source_level=0),
        "pointed_boundary": render_raw_certificate(pointed_boundary_showcase()),
    }


def write_showcase_gallery(output_dir: str | Path) -> Dict[str, Path]:
    """Write auditable SVGs and a small static HTML gallery."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    artifacts = build_showcase_artifacts()
    output: Dict[str, Path] = {}
    for name, artifact in artifacts.items():
        output[name] = artifact.write_svg(destination / f"{name}.svg")

    rows = "\n".join(
        f'<section><h2>{name.replace("_", " ").title()}</h2>'
        f'<p><code>{artifact.audit_hash}</code></p>'
        f'<object type="image/svg+xml" data="{name}.svg" width="100%" height="520"></object></section>'
        for name, artifact in artifacts.items()
    )
    gallery = destination / "index.html"
    gallery.write_text(
        """<!doctype html>
<html><head><meta charset="utf-8"><title>Metasketch semantic renderer</title>
<style>body{font-family:system-ui,sans-serif;margin:2rem;max-width:1100px}section{margin:2rem 0;padding:1rem;border:1px solid #d7dce6;border-radius:10px}code{font-size:.8rem;word-break:break-all}</style>
</head><body><h1>Metasketch semantic renderer</h1>
<p>Each SVG embeds a canonical semantic manifest and audit hash. The scenes are generated from checked proof objects, not a drawing editor.</p>
""" + rows + "\n</body></html>\n",
        encoding="utf-8",
    )
    output["gallery"] = gallery
    return output
