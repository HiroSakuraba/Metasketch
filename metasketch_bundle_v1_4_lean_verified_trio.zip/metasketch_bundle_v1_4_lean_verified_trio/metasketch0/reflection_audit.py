"""Program E audit for real Metasketch proof objects.

This module does not try to prove Tarski's theorem or Lawvere's theorem.  It
answers a narrower engineering question for the current finite kernel:

    Does the actual quote/check/eval interface provide a bridge to weak
    point-surjectivity, or which premise is missing?

For the present fragment the answer is explicit.  Proof quotation is level
raising; proof checking is syntactic and higher level; bounded evaluation can
report a resource limit; and no total evaluator from proof codes to all
same-level predicates exists.  Therefore the decisive weak-point-surjectivity
premise is absent.  The result classifies the current escape routes rather than
turning an implementation convention into a claimed no-go theorem.
"""

from __future__ import annotations

from dataclasses import dataclass
import inspect
from typing import Any, Tuple

from .reflection import (
    Entail,
    InterfaceSpec,
    Line,
    check_certificate,
    eval_string_rewrite,
    finite_same_level_representation_is_incomplete,
    membrane_check,
    quote,
)


@dataclass(frozen=True)
class ReflectionFragmentAudit:
    """A typed record of the current Program E boundary for one proof object."""

    quoted_kind: str
    source_level: int
    code_level: int
    quote_level_raising: bool
    higher_level_checker_permitted: bool
    checker_is_syntactic_not_truth: bool
    bounded_evaluator_status: str
    bounded_evaluator_is_semantic_partiality: bool
    same_level_complete_truth_blocked: bool
    finite_diagonal_verified: bool
    universal_evaluator_present: bool
    weak_point_surjectivity_bridge: str
    escape_routes: Tuple[str, ...]

    @property
    def safe_by_design(self) -> bool:
        return (
            self.quote_level_raising
            and self.higher_level_checker_permitted
            and self.checker_is_syntactic_not_truth
            and not self.universal_evaluator_present
            and self.same_level_complete_truth_blocked
        )


def audit_reflective_fragment(proof_object: Any, *, source_level: int = 0) -> ReflectionFragmentAudit:
    """Audit quotation, checking, evaluation, and truth for a real proof object.

    ``proof_object`` is serialized by quotation.  The audit deliberately does
    not construct a semantic truth predicate for its own code set.  It reports
    the exact missing premise for a Lawvere-style bridge: no universal evaluator
    and no representation-complete code class for all predicates on proof codes.
    """

    code = quote(proof_object, "metasketch_proof", source_level)
    check_interface = membrane_check(
        InterfaceSpec("check", source_level, source_level + 1, total=True)
    )
    truth_interface = membrane_check(
        InterfaceSpec(
            "truth",
            source_level,
            source_level,
            total=True,
            representation_complete=True,
        )
    )

    # ``check_certificate`` receives no model and validates only declared rules
    # and earlier lines.  The accepted AX example demonstrates syntactic checking
    # without presenting it as semantic truth.
    syntactic_axiom = Entail("syntactic_context", "syntactic_conclusion")
    check_result = check_certificate([Line("AX", syntactic_axiom)], (syntactic_axiom,))

    bounded_eval = eval_string_rewrite("a", (("a", "aa"),), "a", budget=4)
    diagonal_ok, _details = finite_same_level_representation_is_incomplete(2, exhaustive=True)

    return ReflectionFragmentAudit(
        quoted_kind=code.kind,
        source_level=code.source_level,
        code_level=code.code_level,
        quote_level_raising=(code.code_level == code.source_level + 1),
        higher_level_checker_permitted=check_interface.accepted,
        checker_is_syntactic_not_truth=(
            check_result.accepted
            and "model" not in inspect.signature(check_certificate).parameters
        ),
        bounded_evaluator_status=bounded_eval.status,
        # A budget exhaustion is intentionally not interpreted as a proof of
        # divergence.  Thus it is not yet a semantic partiality escape route.
        bounded_evaluator_is_semantic_partiality=False,
        same_level_complete_truth_blocked=not truth_interface.accepted,
        finite_diagonal_verified=diagonal_ok,
        universal_evaluator_present=False,
        weak_point_surjectivity_bridge=(
            "not derivable: quoted proof certificates form a selected syntax class; "
            "the kernel has no total evaluator e : A -> Omega^A and no claim that "
            "every predicate on proof codes has a proof code"
        ),
        escape_routes=(
            "stratification",
            "representation incompleteness",
            "absence of a total universal evaluator",
        ),
    )


__all__ = ["ReflectionFragmentAudit", "audit_reflective_fragment"]
