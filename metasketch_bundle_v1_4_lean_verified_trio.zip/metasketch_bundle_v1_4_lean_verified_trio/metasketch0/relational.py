"""Finite relational patterns and homomorphisms for Metasketch Phase 4.

This module generalizes Phase 3 directed graph patterns to finite *relational*
signatures.  There are no operation symbols in the Phase 4 fragment.  A pattern
is a finite typed conjunction of relation atoms with selected visible variables;
its remaining variables are existential witnesses.

The central finite theorem implemented by the surrounding proof layer is:

    a relational homomorphism transports every pattern witness.

The module is intentionally finite and first-order.  It does not claim a general
regular-logic completeness theorem.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

from .semantics import FiniteModel, ModelValidationError, validate_finite_model
from .syntax import And, Context, Exists, Pred, Rel, Signature, Sort, Top, Var, v, validate_pred


@dataclass(frozen=True)
class RelationalAtom:
    """One typed relation atom written using pattern-variable names."""

    relation: str
    args: Tuple[str, ...]


@dataclass(frozen=True)
class RelationalPattern:
    """A finite typed existential-conjunctive pattern.

    `variables` determines the canonical normal-form order.  `visible` names
    free variables; all other variables are witness variables.
    """

    name: str
    signature: Signature
    variables: Tuple[Var, ...]
    visible: Tuple[str, ...]
    atoms: Tuple[RelationalAtom, ...]

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("relational pattern needs a nonempty name")
        if self.signature.ops:
            raise ValueError(
                "Phase 4 relational patterns require a relation-only signature; "
                "operation symbols belong to a later extension"
            )
        names = [var.name for var in self.variables]
        if len(set(names)) != len(names):
            raise ValueError("pattern variables need distinct names")
        if len(set(self.visible)) != len(self.visible):
            raise ValueError("visible pattern variables need distinct names")
        table = self.variable_table()
        if not set(self.visible) <= set(table):
            raise ValueError("every visible name must name a pattern variable")
        for atom in self.atoms:
            try:
                expected = self.signature.rel_sig(atom.relation)
            except KeyError as exc:
                raise ValueError(f"pattern uses unknown relation {atom.relation!r}") from exc
            if len(atom.args) != len(expected):
                raise ValueError(
                    f"relation {atom.relation!r} expects {len(expected)} pattern variables, "
                    f"got {len(atom.args)}"
                )
            for label, sort in zip(atom.args, expected):
                if label not in table:
                    raise ValueError(f"atom refers to unknown pattern variable {label!r}")
                if table[label].sort != sort:
                    raise ValueError(
                        f"pattern variable {label!r} has sort {table[label].sort}, "
                        f"but relation {atom.relation!r} requires {sort}"
                    )

    def variable_table(self) -> Dict[str, Var]:
        return {var.name: var for var in self.variables}

    @property
    def hidden(self) -> Tuple[str, ...]:
        return tuple(var.name for var in self.variables if var.name not in self.visible)


@dataclass(frozen=True)
class CompiledRelationalQuery:
    """A relational pattern compiled into a regular-logic predicate."""

    pattern: RelationalPattern
    context: Context
    predicate: Pred
    variables: Tuple[Tuple[str, Var], ...]

    def var_for(self, name: str) -> Var:
        return dict(self.variables)[name]


def _fresh_name(stem: str, forbidden: Iterable[str]) -> str:
    names = set(forbidden)
    candidate = stem
    index = 0
    while candidate in names:
        candidate = f"{stem}_{index}"
        index += 1
    return candidate


def _and_all(predicates: Sequence[Pred]) -> Pred:
    if not predicates:
        return Top()
    out = predicates[0]
    for predicate in predicates[1:]:
        out = And(out, predicate)
    return out


def compile_relational_query(
    pattern: RelationalPattern,
    *,
    visible_vars: Mapping[str, Var],
    witness_prefix: str = "w",
) -> CompiledRelationalQuery:
    """Compile a typed relational pattern to an existential-conjunctive query.

    Visible variables are supplied by the caller so a query can be placed in a
    chosen structural context.  Hidden variables receive fresh, typed binders.
    """

    if set(visible_vars) != set(pattern.visible):
        raise ValueError("visible_vars must assign exactly the visible pattern variables")
    table = pattern.variable_table()
    if len({var.name for var in visible_vars.values()}) != len(visible_vars):
        raise ValueError("visible query variables must have distinct names")
    for label, var in visible_vars.items():
        if var.sort != table[label].sort:
            raise ValueError(
                f"visible variable {label!r} has sort {var.sort}, expected {table[label].sort}"
            )

    variables: Dict[str, Var] = dict(visible_vars)
    forbidden = {var.name for var in variables.values()}
    for label in pattern.hidden:
        original = table[label]
        fresh = Var(_fresh_name(f"{witness_prefix}_{label}", forbidden), original.sort)
        variables[label] = fresh
        forbidden.add(fresh.name)

    atoms = tuple(
        Rel(atom.relation, tuple(v(variables[label]) for label in atom.args))
        for atom in pattern.atoms
    )
    predicate: Pred = _and_all(atoms)
    for label in reversed(pattern.hidden):
        predicate = Exists(variables[label], predicate)

    context = Context(tuple(visible_vars[label] for label in pattern.visible))
    validate_pred(predicate, pattern.signature, context)
    return CompiledRelationalQuery(
        pattern=pattern,
        context=context,
        predicate=predicate,
        variables=tuple((var.name, variables[var.name]) for var in pattern.variables),
    )


@dataclass(frozen=True)
class RelationalMatch:
    """A typed homomorphism from a pattern's canonical database into a model."""

    pattern: RelationalPattern
    model: FiniteModel
    mapping: Tuple[Tuple[str, object], ...]

    def __post_init__(self) -> None:
        validate_finite_model(self.model, self.pattern.signature)
        labels = [name for name, _ in self.mapping]
        if len(set(labels)) != len(labels):
            raise ValueError("relational match has duplicate pattern variables")
        table = self.as_dict()
        variables = self.pattern.variable_table()
        if set(table) != set(variables):
            raise ValueError("relational match must assign every pattern variable exactly once")
        for label, variable in variables.items():
            if table[label] not in self.model.carrier(variable.sort):
                raise ValueError(
                    f"match value {table[label]!r} for {label!r} is outside carrier {variable.sort}"
                )
        for atom in self.pattern.atoms:
            fact = tuple(table[label] for label in atom.args)
            if fact not in self.model.rels[atom.relation]:
                raise ValueError(
                    f"match does not satisfy {atom.relation}{atom.args!r}: missing fact {fact!r}"
                )

    def as_dict(self) -> Dict[str, object]:
        return dict(self.mapping)

    def visible_assignment(self) -> Dict[str, object]:
        table = self.as_dict()
        return {name: table[name] for name in self.pattern.visible}

    def hidden_assignment(self) -> Dict[str, object]:
        table = self.as_dict()
        return {name: table[name] for name in self.pattern.hidden}


def find_relational_matches(pattern: RelationalPattern, model: FiniteModel) -> Tuple[RelationalMatch, ...]:
    """Exhaustively enumerate pattern witnesses in a finite relational model."""

    validate_finite_model(model, pattern.signature)
    variables = pattern.variables
    carriers = [model.carrier(variable.sort) for variable in variables]
    matches = []
    for values in product(*carriers):
        try:
            matches.append(RelationalMatch(pattern, model, tuple(zip((v.name for v in variables), values))))
        except ValueError:
            continue
    return tuple(matches)


@dataclass(frozen=True)
class RawRelationalMap:
    """A total sort-respecting map candidate before relation preservation is checked."""

    name: str
    signature: Signature
    source: FiniteModel
    target: FiniteModel
    mapping: Tuple[Tuple[Sort, Tuple[Tuple[object, object], ...]], ...]

    def __post_init__(self) -> None:
        if self.signature.ops:
            raise ValueError("Phase 4 homomorphisms currently support relation-only signatures")
        validate_finite_model(self.source, self.signature)
        validate_finite_model(self.target, self.signature)
        seen_sorts = [sort for sort, _ in self.mapping]
        if len(set(seen_sorts)) != len(seen_sorts) or set(seen_sorts) != set(self.signature.sorts):
            raise ValueError("raw relational map must give exactly one total map for every signature sort")
        for sort, pairs in self.mapping:
            keys = [source_value for source_value, _ in pairs]
            if len(set(keys)) != len(keys) or set(keys) != set(self.source.carrier(sort)):
                raise ValueError(f"map for sort {sort} must map every source-carrier element exactly once")
            if any(target_value not in self.target.carrier(sort) for _, target_value in pairs):
                raise ValueError(f"map for sort {sort} maps outside its target carrier")

    def map_for(self, sort: Sort) -> Dict[object, object]:
        for candidate_sort, pairs in self.mapping:
            if candidate_sort == sort:
                return dict(pairs)
        raise KeyError(sort)

    def apply(self, sort: Sort, value: object) -> object:
        return self.map_for(sort)[value]

    def first_relation_violation(self) -> Optional[str]:
        for relation, argument_sorts in self.signature.rels:
            for source_fact in self.source.rels[relation]:
                target_fact = tuple(
                    self.apply(sort, value) for sort, value in zip(argument_sorts, source_fact)
                )
                if target_fact not in self.target.rels[relation]:
                    return (
                        f"relation {relation!r} does not preserve source fact {source_fact!r}; "
                        f"its image {target_fact!r} is absent"
                    )
        return None

    def is_homomorphism(self) -> bool:
        return self.first_relation_violation() is None


@dataclass(frozen=True)
class RelationalHomomorphism:
    """A checked finite relational homomorphism."""

    raw: RawRelationalMap

    def __post_init__(self) -> None:
        violation = self.raw.first_relation_violation()
        if violation is not None:
            raise ValueError(f"not a relational homomorphism: {violation}")

    @property
    def name(self) -> str:
        return self.raw.name

    @property
    def signature(self) -> Signature:
        return self.raw.signature

    @property
    def source(self) -> FiniteModel:
        return self.raw.source

    @property
    def target(self) -> FiniteModel:
        return self.raw.target

    def apply(self, sort: Sort, value: object) -> object:
        return self.raw.apply(sort, value)

    def map_for(self, sort: Sort) -> Dict[object, object]:
        return self.raw.map_for(sort)


def checked_relational_homomorphism(
    *,
    name: str,
    signature: Signature,
    source: FiniteModel,
    target: FiniteModel,
    mapping: Mapping[Sort, Mapping[object, object]],
) -> RelationalHomomorphism:
    """Build a checked relation-preserving map from convenient dictionaries."""

    raw = RawRelationalMap(
        name,
        signature,
        source,
        target,
        tuple(
            (sort, tuple(mapping[sort].items()))
            for sort in signature.sorts
        ),
    )
    return RelationalHomomorphism(raw)


def compose_relational_homomorphisms(
    second: RelationalHomomorphism,
    first: RelationalHomomorphism,
    *,
    name: Optional[str] = None,
) -> RelationalHomomorphism:
    """Compose `second` after `first` with a checked net map."""

    if first.signature != second.signature:
        raise ValueError("relational homomorphisms use different signatures")
    if first.target is not second.source:
        raise ValueError("relational homomorphisms do not share the same middle model object")
    mapping: Dict[Sort, Dict[object, object]] = {}
    for sort in first.signature.sorts:
        mapping[sort] = {
            value: second.apply(sort, first.apply(sort, value))
            for value in first.source.carrier(sort)
        }
    return checked_relational_homomorphism(
        name=name or f"{second.name}_after_{first.name}",
        signature=first.signature,
        source=first.source,
        target=second.target,
        mapping=mapping,
    )


def transport_relational_match(match: RelationalMatch, hom: RelationalHomomorphism) -> RelationalMatch:
    """Transport a concrete existential witness through a relational homomorphism."""

    if match.pattern.signature != hom.signature:
        raise ValueError("match and homomorphism use different signatures")
    if match.model is not hom.source:
        raise ValueError("match model must be the exact source model of the homomorphism")
    variables = match.pattern.variable_table()
    return RelationalMatch(
        match.pattern,
        hom.target,
        tuple(
            (label, hom.apply(variables[label].sort, value))
            for label, value in match.mapping
        ),
    )
