"""Phase 11: F2 evidence-core audits and formalization handoff integrity.

F2 is the pointed raw-certificate reconstruction theorem.  The Python kernel
already validates concrete relational certificates.  This phase adds a compact,
independent audit of the generic mathematical core used by the Lean handoff:
complete and consistent finite evidence determines exactly one assignment.

These tests do *not* claim Lean verification.  They keep the handoff source,
its stated scope, and the executable finite model in sync until Lean recompiles
``formal/lean/PointedRawReconstruction.lean``; compiled and verified in v1.4.
"""

from __future__ import annotations

from itertools import product
from pathlib import Path

from .tests import Report


ROOT = Path(__file__).resolve().parents[1]
F2_SOURCE = ROOT / "formal" / "lean" / "PointedRawReconstruction.lean"
F2_STATUS = ROOT / "formal" / "lean" / "F2_STATUS.txt"
VERIFY_SCRIPT = ROOT / "formal" / "lean" / "verify.sh"
FORMAL_README = ROOT / "formal" / "README.md"


def _covers(entries: tuple[tuple[str, int], ...], variables: tuple[str, ...]) -> bool:
    return all(any(name == variable for name, _ in entries) for variable in variables)


def _consistent(entries: tuple[tuple[str, int], ...]) -> bool:
    by_variable: dict[str, set[int]] = {}
    for name, value in entries:
        by_variable.setdefault(name, set()).add(value)
    return all(len(values) <= 1 for values in by_variable.values())


def _reconstruct(entries: tuple[tuple[str, int], ...], variables: tuple[str, ...]) -> dict[str, int]:
    return {
        variable: next(value for name, value in entries if name == variable)
        for variable in variables
    }


def _realizers(entries: tuple[tuple[str, int], ...], variables: tuple[str, ...], values: tuple[int, ...]):
    return tuple(
        assignment
        for assignment in product(values, repeat=len(variables))
        if all(assignment[variables.index(name)] == value for name, value in entries)
    )


def test_exhaustive_f2_evidence_uniqueness(rep: Report) -> None:
    """Every covered consistent evidence list over a tiny finite universe has one realizer."""

    variables = ("x", "z")
    values = (0, 1)
    pairs = tuple(product(variables, values))
    checked = 0
    bad = None
    # Length four includes repeated evidence, mirroring multiple atom occurrences.
    for length in range(2, 5):
        for entries in product(pairs, repeat=length):
            if not _covers(entries, variables) or not _consistent(entries):
                continue
            checked += 1
            realized = _realizers(entries, variables, values)
            reconstructed = _reconstruct(entries, variables)
            expected = tuple(reconstructed[variable] for variable in variables)
            if realized != (expected,):
                bad = f"entries={entries!r}, realizers={realized!r}, expected={expected!r}"
                break
        if bad:
            break
    rep.check(
        "Phase11 exhaustive finite audit: complete consistent evidence has exactly one realizing assignment",
        bad is None and checked > 0,
        bad or f"checked {checked} complete consistent evidence lists",
    )


def test_incomplete_or_inconsistent_evidence_is_not_uniquely_reconstructible(rep: Report) -> None:
    variables = ("x", "z")
    values = (0, 1)
    incomplete = (("x", 0),)
    inconsistent = (("x", 0), ("x", 1), ("z", 0))
    incomplete_realizers = _realizers(incomplete, variables, values)
    inconsistent_realizers = _realizers(inconsistent, variables, values)
    rep.check(
        "Phase11 incomplete evidence leaves more than one candidate assignment",
        len(incomplete_realizers) == 2,
        f"realizers={incomplete_realizers!r}",
    )
    rep.check(
        "Phase11 inconsistent evidence has no realizing assignment",
        len(inconsistent_realizers) == 0,
        f"realizers={inconsistent_realizers!r}",
    )


def test_three_source_partition_recombines_to_the_same_assignment(rep: Report) -> None:
    """Atom, binder, and boundary evidence are provenance tags, not extra freedom."""

    atom = (("x", 0), ("x", 0))
    binder = (("z", 1),)
    boundary = (("p", 2),)
    entries = atom + binder + boundary
    variables = ("x", "z", "p")
    mapping = _reconstruct(entries, variables)
    rep.check(
        "Phase11 atom, hidden-binder, and pointed-boundary sources recombine into one assignment",
        mapping == {"x": 0, "z": 1, "p": 2},
        f"mapping={mapping!r}",
    )


def test_f2_lean_source_has_required_theorems_and_no_placeholders(rep: Report) -> None:
    text = F2_SOURCE.read_text(encoding="utf-8") if F2_SOURCE.exists() else ""
    required = (
        "reconstruct_realizes_evidence",
        "reconstruct_unique",
        "reconstruct_realizes_atomEvidence",
        "reconstruct_realizes_binderEvidence",
        "reconstruct_realizes_boundaryEvidence",
        "reconstruct_erase",
    )
    forbidden = ("sorry", "admit", "axiom ", "unsafe ", "partial ")
    missing = [name for name in required if name not in text]
    present_forbidden = [token for token in forbidden if token in text]
    rep.check(
        "Phase11 F2 Lean source contains the declared theorem interface and no placeholders",
        bool(text) and not missing and not present_forbidden,
        f"missing={missing!r}, forbidden={present_forbidden!r}",
    )


def test_f2_status_is_honest_and_recheck_script_targets_all_files(rep: Report) -> None:
    status = F2_STATUS.read_text(encoding="utf-8") if F2_STATUS.exists() else ""
    script = VERIFY_SCRIPT.read_text(encoding="utf-8") if VERIFY_SCRIPT.exists() else ""
    readme = FORMAL_README.read_text(encoding="utf-8") if FORMAL_README.exists() else ""
    lowered = status.lower()
    # F2 was compiled and verified in the v1.4 environment. Honesty now means
    # recording the toolchain, the pre-verification repairs, and the retained
    # front-end scope limits, rather than claiming pending compilation.
    honest = (
        "machine-checked" in lowered
        and "lean 4 v4.31.0" in lowered
        and "repaired three compile errors" in lowered
        and "does not formalize relation membership" in lowered.replace("intentionally does not", "does not")
    )
    targets_all = all(
        name in script
        for name in (
            "MonoidNormalization.lean",
            "PointedRawReconstruction.lean",
            "ReflectionSafety.lean",
        )
    )
    scoped = "evidence-reconstruction layer" in readme.lower()
    rep.check(
        "Phase11 F2 status records verified compilation, its repairs, and the retained front-end scope",
        honest and targets_all and scoped,
        f"honest={honest}, targets_all={targets_all}, scoped={scoped}",
    )


def run() -> int:
    rep = Report()
    test_exhaustive_f2_evidence_uniqueness(rep)
    test_incomplete_or_inconsistent_evidence_is_not_uniquely_reconstructible(rep)
    test_three_source_partition_recombines_to_the_same_assignment(rep)
    test_f2_lean_source_has_required_theorems_and_no_placeholders(rep)
    test_f2_status_is_honest_and_recheck_script_targets_all_files(rep)
    print("=" * 72)
    print("Metasketch Phase 11 test report (F2 evidence-reconstruction core)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
