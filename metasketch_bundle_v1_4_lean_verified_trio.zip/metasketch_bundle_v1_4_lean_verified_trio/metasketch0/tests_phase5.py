"""Phase 5 tests: finite certificate--match adequacy."""

from __future__ import annotations

from .adequacy import (
    audit_certificate_match_adequacy,
    build_certificate,
    build_erase_identity,
    certificate_visible_assignments,
    erase_build_normal_form_identity,
    normalize_to_canonical,
    satisfying_visible_assignments,
)
from .proofs import build_pattern_witness_proof, normalize_pattern_witness_proof
from .relational import find_relational_matches
from .tests import Report
from .tests_phase4 import commuter_friend_pattern, open_route_pattern, source_model


def test_match_certificate_roundtrips(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    model = source_model()
    matches = find_relational_matches(pattern, model)
    all_build_erase = all(build_erase_identity(match) for match in matches)
    all_checked = all(build_certificate(match).match == match for match in matches)
    rep.check("Phase5 build then erase is the identity on every finite relational match", all_build_erase and all_checked, f"matches={len(matches)}")


def test_proof_presentation_erases_to_canonical_certificate(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    varied = build_pattern_witness_proof(
        match,
        atom_order=(3, 2, 1, 0),
        binder_order=("b", "a"),
        binder_display_names={"a": "alpha_left", "b": "alpha_right"},
    )
    canonical = normalize_to_canonical(varied)
    same_nf = normalize_pattern_witness_proof(varied) == canonical.normal_form
    rep.check("Phase5 erase and rebuild preserves a certificate exactly modulo witness normal form", erase_build_normal_form_identity(varied) and same_nf)


def test_visible_assignment_iff(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    model = source_model()
    query_rows = satisfying_visible_assignments(pattern, model)
    certificate_rows = certificate_visible_assignments(pattern, model)
    absent = ("u", "w")
    rep.check(
        "Phase5 visible assignment satisfies the compiled query iff an accepted certificate exists",
        query_rows == certificate_rows and absent not in query_rows and absent not in certificate_rows,
        f"query={query_rows}, certificates={certificate_rows}",
    )


def test_complete_finite_adequacy_audit(rep: Report) -> None:
    report = audit_certificate_match_adequacy(commuter_friend_pattern(), source_model())
    rep.check(
        "Phase5 finite certificate--match adequacy audit passes both round trips and the existential iff",
        report.valid,
        f"matches={report.match_count}, certificates={report.certificate_count}, visible={report.query_visible_assignments}",
    )

    empty_report = audit_certificate_match_adequacy(open_route_pattern(), source_model())
    rep.check("Phase5 adequacy also covers a unary relation and one existential witness", empty_report.valid, f"matches={empty_report.match_count}")


def run() -> int:
    rep = Report()
    test_match_certificate_roundtrips(rep)
    test_proof_presentation_erases_to_canonical_certificate(rep)
    test_visible_assignment_iff(rep)
    test_complete_finite_adequacy_audit(rep)
    print("=" * 72)
    print("Metasketch-0 Phase 5 test report (certificate--match adequacy)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
