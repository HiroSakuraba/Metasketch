"""Certificate--match adequacy for the finite relational Metasketch fragment.

The Phase 4 certificate language has two levels of syntax:

* many presentation-level proof trees for one finite witness; and
* one canonical witness normal form modulo alpha-renaming and conjunction AC.

This module makes the correspondence explicit.  It does **not** claim general
regular-logic completeness.  Its theorem-shaped result is deliberately finite:
for a fixed finite relation-only pattern and a fixed finite model,

    visible assignment satisfies the compiled conjunctive query
        iff
    some accepted canonical witness certificate has that visible assignment.

More sharply, normalized accepted certificates are in bijection with concrete
relational matches.  ``build`` and ``erase`` provide the two directions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping, Optional, Sequence, Tuple

from .proofs import (
    PatternWitnessProof,
    WitnessNormalForm,
    build_pattern_witness_proof,
    normalize_pattern_witness_proof,
    validate_pattern_witness_proof,
)
from .relational import (
    RelationalMatch,
    RelationalPattern,
    compile_relational_query,
    find_relational_matches,
)
from .semantics import FiniteModel, extension, validate_finite_model
from .syntax import Var


class AdequacyError(ValueError):
    """Raised when a certificate or match lies outside the finite adequacy scope."""


@dataclass(frozen=True)
class CanonicalWitnessCertificate:
    """The checked canonical certificate associated with one relational match."""

    proof: PatternWitnessProof
    normal_form: WitnessNormalForm

    def __post_init__(self) -> None:
        validate_pattern_witness_proof(self.proof)
        if normalize_pattern_witness_proof(self.proof) != self.normal_form:
            raise AdequacyError("canonical certificate normal form disagrees with its proof")

    @property
    def match(self) -> RelationalMatch:
        return self.proof.match


def build_certificate(match: RelationalMatch) -> CanonicalWitnessCertificate:
    """Build the fixed-order certificate for one semantic witness map."""

    proof = build_pattern_witness_proof(match)
    return CanonicalWitnessCertificate(proof, normalize_pattern_witness_proof(proof))


def erase_certificate(certificate: CanonicalWitnessCertificate) -> RelationalMatch:
    """Erase proof presentation to the concrete pattern match it certifies."""

    validate_pattern_witness_proof(certificate.proof)
    return certificate.proof.match


def normalize_to_canonical(proof: PatternWitnessProof) -> CanonicalWitnessCertificate:
    """Forget harmless proof presentation and rebuild the canonical certificate."""

    validate_pattern_witness_proof(proof)
    return build_certificate(proof.match)


def build_erase_identity(match: RelationalMatch) -> bool:
    """First round trip: erasing a built certificate returns the original match."""

    return erase_certificate(build_certificate(match)) == match


def erase_build_normal_form_identity(proof: PatternWitnessProof) -> bool:
    """Second round trip modulo certificate normalization.

    The original proof may vary in atom order, conjunction bracketing, and
    displayed binder names.  After erasure and canonical rebuilding, its normal
    form is unchanged.
    """

    validate_pattern_witness_proof(proof)
    return normalize_pattern_witness_proof(proof) == normalize_to_canonical(proof).normal_form


def _default_visible_vars(pattern: RelationalPattern, prefix: str = "q") -> Dict[str, Var]:
    table = pattern.variable_table()
    return {
        label: Var(f"{prefix}_{label}", table[label].sort)
        for label in pattern.visible
    }


def satisfying_visible_assignments(
    pattern: RelationalPattern,
    model: FiniteModel,
    *,
    visible_vars: Optional[Mapping[str, Var]] = None,
) -> Tuple[Tuple[object, ...], ...]:
    """Evaluate the compiled query and return visible assignments in pattern order."""

    validate_finite_model(model, pattern.signature)
    vars_map = dict(visible_vars or _default_visible_vars(pattern))
    compiled = compile_relational_query(pattern, visible_vars=vars_map, witness_prefix="adequacy")
    values = extension(compiled.predicate, compiled.context, model)
    return tuple(sorted(values, key=repr))


def certificate_visible_assignments(
    pattern: RelationalPattern,
    model: FiniteModel,
) -> Tuple[Tuple[object, ...], ...]:
    """Return visible assignments represented by accepted canonical certificates."""

    rows = {
        tuple(erase_certificate(build_certificate(match)).as_dict()[label] for label in pattern.visible)
        for match in find_relational_matches(pattern, model)
    }
    return tuple(sorted(rows, key=repr))


@dataclass(frozen=True)
class AdequacyReport:
    """Finite checkable instance of certificate--match correspondence."""

    pattern: str
    match_count: int
    certificate_count: int
    query_visible_assignments: Tuple[Tuple[object, ...], ...]
    certificate_visible_assignments: Tuple[Tuple[object, ...], ...]
    build_erase_ok: bool
    erase_build_normal_form_ok: bool

    @property
    def valid(self) -> bool:
        return (
            self.match_count == self.certificate_count
            and self.query_visible_assignments == self.certificate_visible_assignments
            and self.build_erase_ok
            and self.erase_build_normal_form_ok
        )


def audit_certificate_match_adequacy(
    pattern: RelationalPattern,
    model: FiniteModel,
) -> AdequacyReport:
    """Audit both directions of the finite certificate--match theorem.

    This computes the complete finite match set.  For each match it builds a
    certificate and checks ``erase(build(match)) = match``.  For every accepted
    canonical certificate it checks the converse modulo normal form.  Finally it
    compares the set of visible assignments from query semantics and from
    certificates, proving the existential ``iff`` for this finite instance.
    """

    matches = find_relational_matches(pattern, model)
    certificates = tuple(build_certificate(match) for match in matches)
    build_erase_ok = all(erase_certificate(certificate) == match for certificate, match in zip(certificates, matches))
    erase_build_ok = all(
        erase_build_normal_form_identity(certificate.proof)
        for certificate in certificates
    )
    return AdequacyReport(
        pattern=pattern.name,
        match_count=len(matches),
        certificate_count=len(certificates),
        query_visible_assignments=satisfying_visible_assignments(pattern, model),
        certificate_visible_assignments=certificate_visible_assignments(pattern, model),
        build_erase_ok=build_erase_ok,
        erase_build_normal_form_ok=erase_build_ok,
    )


__all__ = [
    "AdequacyError",
    "CanonicalWitnessCertificate",
    "build_certificate",
    "erase_certificate",
    "normalize_to_canonical",
    "build_erase_identity",
    "erase_build_normal_form_identity",
    "satisfying_visible_assignments",
    "certificate_visible_assignments",
    "AdequacyReport",
    "audit_certificate_match_adequacy",
]
