"""
Metasketch-0 finite-model semantics.

A finite model interprets each sort as a finite carrier set, each operation as a
function on carriers, and each relation as a set of tuples. From this we derive:

  - the interpretation of a term under an environment,
  - the extension of a predicate over a context (a subset of the finite product
    of carriers, i.e. the set of environments that satisfy it),
  - the interpretation of a structural diagram as a function on environments, and
  - semantic validity of a preservation tile P |- d^*Q in the model, which holds
    exactly when d sends the extension of P into the extension of Q.

The point of finite semantics is that every claim in the theorem program becomes
a decidable computation, so the design can be falsified rather than asserted.
"""

from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from typing import Dict, Callable, Tuple, FrozenSet, Optional

from .syntax import Signature

from .syntax import (
    Sort, Var, Context, Term, VarTerm, OpTerm,
    Pred, Top, Eq, Rel, And, Exists, Diagram,
)


Env = Dict[str, object]  # variable name -> carrier element


@dataclass
class FiniteModel:
    carriers: Dict[Sort, Tuple[object, ...]]
    ops: Dict[str, Callable[..., object]]
    rels: Dict[str, frozenset]  # relation name -> set of argument tuples

    def carrier(self, sort: Sort) -> Tuple[object, ...]:
        return self.carriers[sort]


def interpret_term(t: Term, env: Env, model: FiniteModel) -> object:
    if isinstance(t, VarTerm):
        return env[t.var.name]
    if isinstance(t, OpTerm):
        return model.ops[t.op](*[interpret_term(a, env, model) for a in t.args])
    raise TypeError(f"not a term: {t!r}")


def satisfies(p: Pred, env: Env, model: FiniteModel) -> bool:
    if isinstance(p, Top):
        return True
    if isinstance(p, Eq):
        return interpret_term(p.left, env, model) == interpret_term(p.right, env, model)
    if isinstance(p, Rel):
        vals = tuple(interpret_term(a, env, model) for a in p.args)
        return vals in model.rels[p.name]
    if isinstance(p, And):
        return satisfies(p.left, env, model) and satisfies(p.right, env, model)
    if isinstance(p, Exists):
        for val in model.carrier(p.var.sort):
            env2 = dict(env)
            env2[p.var.name] = val
            if satisfies(p.body, env2, model):
                return True
        return False
    raise TypeError(f"not a predicate: {p!r}")


def all_envs(ctx: Context, model: FiniteModel):
    """Enumerate every environment over the context (the finite product)."""
    carriers = [model.carrier(x.sort) for x in ctx.vars]
    names = [x.name for x in ctx.vars]
    for combo in product(*carriers):
        yield dict(zip(names, combo))


def env_key(ctx: Context, env: Env) -> Tuple:
    """Canonical hashable key for an environment over a context."""
    return tuple(env[x.name] for x in ctx.vars)


def extension(p: Pred, ctx: Context, model: FiniteModel) -> FrozenSet[Tuple]:
    """The subset of the context product satisfying p, as a set of keys."""
    return frozenset(
        env_key(ctx, env) for env in all_envs(ctx, model) if satisfies(p, env, model)
    )


def interpret_diagram(d: Diagram, env_source: Env, model: FiniteModel) -> Env:
    """Apply a structural diagram to a source environment, giving a target one."""
    out: Env = {}
    for target_name, term in d.mapping:
        out[target_name] = interpret_term(term, env_source, model)
    return out


@dataclass
class TileResult:
    valid: bool
    counterexample: Optional[Env] = None  # a source env satisfying P but not d^*Q


def tile_valid_in_model(p: Pred, d: Diagram, q: Pred, model: FiniteModel) -> TileResult:
    """
    Decide whether the preservation tile P |- d^*Q holds in the model.

    Structural reading: every source environment satisfying P is sent by d to a
    target environment satisfying Q. This is image containment d(ext P) subset ext Q.
    """
    for env_src in all_envs(d.source, model):
        if satisfies(p, env_src, model):
            env_tgt = interpret_diagram(d, env_src, model)
            if not satisfies(q, env_tgt, model):
                return TileResult(valid=False, counterexample=env_src)
    return TileResult(valid=True)


# ---------------------------------------------------------------------------
# Finite-model validation
# ---------------------------------------------------------------------------

class ModelValidationError(ValueError):
    """Raised when a finite model does not realize a declared signature."""


def validate_finite_model(model: FiniteModel, signature: Signature) -> None:
    """Validate carriers, total operations, and relation tuples exhaustively.

    The finite kernel makes this check practical.  Every declared operation is
    evaluated on the complete finite input product and must return an element of
    its declared output carrier.  Every relation tuple must have the declared
    arity and draw each coordinate from the matching carrier.
    """

    for sort in signature.sorts:
        if sort not in model.carriers:
            raise ModelValidationError(f"model is missing a carrier for sort {sort}")
        carrier = model.carriers[sort]
        if len(set(carrier)) != len(carrier):
            raise ModelValidationError(f"carrier for sort {sort} has duplicate elements")

    for name, input_sorts, output_sort in signature.ops:
        if name not in model.ops:
            raise ModelValidationError(f"model is missing operation {name!r}")
        operation = model.ops[name]
        input_carriers = [model.carrier(sort) for sort in input_sorts]
        for arguments in product(*input_carriers):
            try:
                value = operation(*arguments)
            except Exception as exc:  # pragma: no cover - detail preserved for callers
                raise ModelValidationError(
                    f"operation {name!r} failed on arguments {arguments!r}: {exc}"
                ) from exc
            if value not in model.carrier(output_sort):
                raise ModelValidationError(
                    f"operation {name!r} returns {value!r}, outside carrier {output_sort}"
                )

    for name, argument_sorts in signature.rels:
        if name not in model.rels:
            raise ModelValidationError(f"model is missing relation {name!r}")
        for item in model.rels[name]:
            if not isinstance(item, tuple) or len(item) != len(argument_sorts):
                raise ModelValidationError(
                    f"relation {name!r} contains ill-arity tuple {item!r}"
                )
            for value, sort in zip(item, argument_sorts):
                if value not in model.carrier(sort):
                    raise ModelValidationError(
                        f"relation {name!r} contains {value!r} outside carrier {sort}"
                    )
