"""Phase 7 tests: pointed boundary assignments for raw certificates.

Phase 6 reconstructed values for visible variables only when an atom occurrence
forced them.  Phase 7 adds a separate typed boundary-assignment node for visible
variables absent from the relation matrix.  The node is context evidence, not a
matrix formula leaf, so existential binders remain an outer prefix over the
matrix while visible inputs remain explicit at the certificate boundary.
"""

from __future__ import annotations

from .proofs import AtomFactProof, ExistsWitnessProof, TruthProof, build_pattern_witness_proof
from .raw_certificates import (
    BoundaryAssignmentProof,
    RawCertificateError,
    RawPatternCertificate,
    audit_raw_certificate_reconstruction,
    checked_raw_certificate,
    raw_certificate_from_proof,
    reconstruct_raw_match,
)
from .relational import (
    RelationalAtom,
    RelationalMatch,
    RelationalPattern,
    compile_relational_query,
    find_relational_matches,
)
from .reflection_audit import audit_reflective_fragment
from .semantics import extension
from .syntax import Var
from .tests import Report
from .tests_phase4 import CITY, PERSON, REL_SIGNATURE, commuter_friend_pattern, source_model


def pointed_truth_pattern() -> RelationalPattern:
    """A free visible Person variable with an empty conjunctive matrix."""

    p = Var("p", PERSON)
    return RelationalPattern(
        "pointed_truth",
        REL_SIGNATURE,
        (p,),
        ("p",),
        (),
    )


def boundary_and_witness_pattern() -> RelationalPattern:
    """An unanchored visible Person plus one hidden City constrained by Open."""

    p = Var("p", PERSON)
    c = Var("c", CITY)
    return RelationalPattern(
        "pointed_open_city",
        REL_SIGNATURE,
        (p, c),
        ("p",),
        (RelationalAtom("Open", ("c",)),),
    )


def _rejects(certificate: RawPatternCertificate) -> str:
    try:
        reconstruct_raw_match(certificate)
    except RawCertificateError as exc:
        return str(exc)
    return ""


def test_truth_pattern_reconstructs_from_boundary(rep: Report) -> None:
    pattern = pointed_truth_pattern()
    model = source_model()
    raw = RawPatternCertificate(
        pattern,
        model,
        TruthProof(),
        (BoundaryAssignmentProof("p", "u", "input_person"),),
    )
    checked = checked_raw_certificate(pattern, model, raw.root, boundary=raw.boundary)
    audit = audit_raw_certificate_reconstruction(raw)
    rep.check(
        "Phase7 boundary assignment reconstructs an unanchored visible value in an empty conjunction",
        checked.match.mapping == (("p", "u"),),
        f"mapping={checked.match.mapping}",
    )
    rep.check(
        "Phase7 pointed truth certificate has one finite semantic realizer",
        audit.valid and audit.evidence_match_count == 1 and audit.boundary_assignment_count == 1,
        f"report={audit}",
    )


def test_pointed_boundary_certificates_cover_truth_assignments(rep: Report) -> None:
    pattern = pointed_truth_pattern()
    model = source_model()
    matches = find_relational_matches(pattern, model)
    raw_assignments = {
        reconstruct_raw_match(raw_certificate_from_proof(build_pattern_witness_proof(match))).visible_assignment()["p"]
        for match in matches
    }
    compiled = compile_relational_query(
        pattern,
        visible_vars={"p": Var("query_p", PERSON)},
        witness_prefix="phase7",
    )
    semantic_assignments = {row[0] for row in extension(compiled.predicate, compiled.context, model)}
    rep.check(
        "Phase7 pointed raw certificates cover exactly the visible assignments satisfying the empty query",
        raw_assignments == semantic_assignments,
        f"raw={sorted(raw_assignments)!r}, semantics={sorted(semantic_assignments)!r}",
    )


def test_phase5_erasure_preserves_needed_boundary(rep: Report) -> None:
    pattern = pointed_truth_pattern()
    model = source_model()
    match = RelationalMatch(pattern, model, (("p", "v"),))
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    reconstructed = reconstruct_raw_match(raw)
    rep.check(
        "Phase7 erasing a stored-match proof emits the required pointed boundary node",
        raw.boundary == (BoundaryAssignmentProof("p", "v", "p"),),
        f"boundary={raw.boundary}",
    )
    rep.check(
        "Phase7 pointed boundary survives stored-match erasure and raw reconstruction",
        reconstructed == match,
        f"reconstructed={reconstructed.mapping}",
    )


def test_boundary_and_existential_witness_coexist(rep: Report) -> None:
    pattern = boundary_and_witness_pattern()
    model = source_model()
    root = ExistsWitnessProof("c", "open_city", 1, AtomFactProof(0, (1,)))
    raw = RawPatternCertificate(
        pattern,
        model,
        root,
        (BoundaryAssignmentProof("p", "w", "selected_person"),),
    )
    reconstructed = reconstruct_raw_match(raw)
    rep.check(
        "Phase7 keeps visible boundary assignments outside the existential binder spine",
        reconstructed.mapping == (("p", "w"), ("c", 1)),
        f"mapping={reconstructed.mapping}",
    )
    rep.check(
        "Phase7 boundary assignments remain valid quotation targets for the Program E audit",
        audit_reflective_fragment(raw).safe_by_design,
    )


def test_boundary_shape_rejections(rep: Report) -> None:
    model = source_model()
    truth = pointed_truth_pattern()
    missing = RawPatternCertificate(truth, model, TruthProof())
    duplicate = RawPatternCertificate(
        truth,
        model,
        TruthProof(),
        (BoundaryAssignmentProof("p", "u"), BoundaryAssignmentProof("p", "v")),
    )
    outside = RawPatternCertificate(
        truth,
        model,
        TruthProof(),
        (BoundaryAssignmentProof("p", "not_in_person_carrier"),),
    )
    missing_detail = _rejects(missing)
    duplicate_detail = _rejects(duplicate)
    outside_detail = _rejects(outside)
    rep.check(
        "Phase7 rejects an unanchored visible variable with no boundary assignment",
        "missing" in missing_detail and "boundary assignment" in missing_detail,
        missing_detail,
    )
    rep.check(
        "Phase7 rejects duplicate boundary assignments for one visible variable",
        "at most once" in duplicate_detail,
        duplicate_detail,
    )
    rep.check(
        "Phase7 rejects a boundary value outside its declared finite carrier",
        "outside carrier" in outside_detail,
        outside_detail,
    )


def test_boundary_only_for_unanchored_visible_variables(rep: Report) -> None:
    model = source_model()
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, model)[0]
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    forged = RawPatternCertificate(
        raw.pattern,
        raw.model,
        raw.root,
        (BoundaryAssignmentProof("s", "u"),),
    )
    detail = _rejects(forged)
    rep.check(
        "Phase7 rejects a redundant boundary assignment for an atom-anchored visible variable",
        "only for unanchored visible variables" in detail,
        detail,
    )


def run() -> int:
    rep = Report()
    test_truth_pattern_reconstructs_from_boundary(rep)
    test_pointed_boundary_certificates_cover_truth_assignments(rep)
    test_phase5_erasure_preserves_needed_boundary(rep)
    test_boundary_and_existential_witness_coexist(rep)
    test_boundary_shape_rejections(rep)
    test_boundary_only_for_unanchored_visible_variables(rep)
    print("=" * 72)
    print("Metasketch-0 Phase 7 test report (pointed raw boundaries)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
