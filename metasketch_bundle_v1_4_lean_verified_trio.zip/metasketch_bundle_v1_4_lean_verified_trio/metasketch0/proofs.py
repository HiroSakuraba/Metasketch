"""Witness-normalized proof terms for Metasketch Phase 4.

The proof language is deliberately restricted to finite relational patterns:

  atom fact
  conjunction introduction
  existential witness introduction
  reindex / witness transport along a relational homomorphism
  tile composition
  a 3-cell equating direct and sequential witness transport

A proof is accepted only after its atomic facts and witness values are checked in
one finite model.  Its normal form forgets alpha-renamed binder displays and the
binary bracketing/order of conjunction, retaining the canonical witness map and
net structural transport.  This is the executable, finite instance of the
Phase-4 witness-normalization claim.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping, Optional, Sequence, Tuple, Union

from .relational import (
    RelationalHomomorphism,
    RelationalMatch,
    RelationalPattern,
    RawRelationalMap,
    compose_relational_homomorphisms,
    find_relational_matches,
    transport_relational_match,
)


class ProofValidationError(ValueError):
    """Raised when a finite relational proof certificate is malformed or unsound."""


# ---------------------------------------------------------------------------
# Query-proof syntax
# ---------------------------------------------------------------------------

class QueryProofNode:
    """Base class for proof nodes in the existential-conjunctive fragment."""


@dataclass(frozen=True)
class TruthProof(QueryProofNode):
    """Proof of the empty conjunction."""


@dataclass(frozen=True)
class AtomFactProof(QueryProofNode):
    """A concrete relation fact for one indexed atom of a pattern."""

    atom_index: int
    values: Tuple[object, ...]


@dataclass(frozen=True)
class AndIntroProof(QueryProofNode):
    """Conjunction introduction.  Normalization later quotients its order/bracketing."""

    left: QueryProofNode
    right: QueryProofNode


@dataclass(frozen=True)
class ExistsWitnessProof(QueryProofNode):
    """An existential witness with a display binder.

    `variable` is the canonical pattern-variable name.  `display_binder` may be
    alpha-renamed; it is deliberately ignored by witness normal form.
    """

    variable: str
    display_binder: str
    witness: object
    body: QueryProofNode


@dataclass(frozen=True)
class PatternWitnessProof:
    """A proof that one finite relational pattern has one concrete witness map."""

    match: RelationalMatch
    root: QueryProofNode

    @property
    def pattern(self) -> RelationalPattern:
        return self.match.pattern


@dataclass(frozen=True)
class WitnessNormalForm:
    """Canonical finite witness form, modulo alpha and conjunction AC."""

    pattern: str
    assignments: Tuple[Tuple[str, object], ...]
    visible: Tuple[Tuple[str, object], ...]
    hidden: Tuple[Tuple[str, object], ...]
    atom_facts: Tuple[Tuple[str, Tuple[object, ...]], ...]


def _proof_atoms(node: QueryProofNode) -> Tuple[AtomFactProof, ...]:
    if isinstance(node, TruthProof):
        return ()
    if isinstance(node, AtomFactProof):
        return (node,)
    if isinstance(node, AndIntroProof):
        return _proof_atoms(node.left) + _proof_atoms(node.right)
    if isinstance(node, ExistsWitnessProof):
        return _proof_atoms(node.body)
    raise ProofValidationError(f"unsupported query-proof node {node!r}")


def _proof_binders(node: QueryProofNode) -> Tuple[ExistsWitnessProof, ...]:
    if isinstance(node, (TruthProof, AtomFactProof)):
        return ()
    if isinstance(node, AndIntroProof):
        return _proof_binders(node.left) + _proof_binders(node.right)
    if isinstance(node, ExistsWitnessProof):
        return (node,) + _proof_binders(node.body)
    raise ProofValidationError(f"unsupported query-proof node {node!r}")


def _canonical_atom_key(item: Tuple[str, Tuple[object, ...]]) -> Tuple[str, Tuple[str, ...]]:
    return item[0], tuple(repr(value) for value in item[1])


def validate_pattern_witness_proof(proof: PatternWitnessProof) -> None:
    """Check every atom fact, conjunction leaf, and witness against its match."""

    match = proof.match
    pattern = match.pattern
    mapping = match.as_dict()

    atoms = _proof_atoms(proof.root)
    expected_indices = set(range(len(pattern.atoms)))
    actual_indices = [atom.atom_index for atom in atoms]
    if len(actual_indices) != len(set(actual_indices)) or set(actual_indices) != expected_indices:
        raise ProofValidationError(
            "atom proof leaves must contain every pattern atom exactly once, "
            "up to conjunction reordering"
        )
    for atom_proof in atoms:
        atom = pattern.atoms[atom_proof.atom_index]
        expected_values = tuple(mapping[label] for label in atom.args)
        if atom_proof.values != expected_values:
            raise ProofValidationError(
                f"atom {atom_proof.atom_index} carries {atom_proof.values!r}, "
                f"expected witness fact {expected_values!r}"
            )
        if atom_proof.values not in match.model.rels[atom.relation]:
            raise ProofValidationError(
                f"atom fact {atom.relation}{atom_proof.values!r} is absent from the model"
            )

    binders = _proof_binders(proof.root)
    expected_hidden = set(pattern.hidden)
    actual_hidden = [binder.variable for binder in binders]
    if len(actual_hidden) != len(set(actual_hidden)) or set(actual_hidden) != expected_hidden:
        raise ProofValidationError(
            "existential introduction nodes must bind every hidden pattern variable exactly once"
        )
    for binder in binders:
        if binder.witness != mapping[binder.variable]:
            raise ProofValidationError(
                f"binder {binder.variable!r} uses {binder.witness!r}, "
                f"expected {mapping[binder.variable]!r}"
            )


def normalize_pattern_witness_proof(proof: PatternWitnessProof) -> WitnessNormalForm:
    """Normalize a valid proof to canonical witness data.

    This is intentionally insensitive to conjunction bracketing/order and to
    alpha-renamed display binders.  It is not a proof of general first-order
    normalization; it is an exact normalization procedure for this finite
    witness-certificate fragment.
    """

    validate_pattern_witness_proof(proof)
    pattern = proof.pattern
    mapping = proof.match.as_dict()
    assignments = tuple((variable.name, mapping[variable.name]) for variable in pattern.variables)
    visible = tuple((name, mapping[name]) for name in pattern.visible)
    hidden = tuple((name, mapping[name]) for name in pattern.hidden)
    atom_facts = tuple(
        sorted(
            (
                (atom.relation, tuple(mapping[label] for label in atom.args))
                for atom in pattern.atoms
            ),
            key=_canonical_atom_key,
        )
    )
    return WitnessNormalForm(pattern.name, assignments, visible, hidden, atom_facts)


def _build_conjunction(nodes: Sequence[QueryProofNode]) -> QueryProofNode:
    if not nodes:
        return TruthProof()
    current = nodes[0]
    for node in nodes[1:]:
        current = AndIntroProof(current, node)
    return current


def build_pattern_witness_proof(
    match: RelationalMatch,
    *,
    atom_order: Optional[Sequence[int]] = None,
    binder_order: Optional[Sequence[str]] = None,
    binder_display_names: Optional[Mapping[str, str]] = None,
) -> PatternWitnessProof:
    """Build one explicit certificate, allowing harmless syntactic variation."""

    pattern = match.pattern
    mapping = match.as_dict()
    order = tuple(atom_order) if atom_order is not None else tuple(range(len(pattern.atoms)))
    if set(order) != set(range(len(pattern.atoms))) or len(order) != len(pattern.atoms):
        raise ValueError("atom_order must be a permutation of pattern-atom indices")
    binder_labels = tuple(binder_order) if binder_order is not None else pattern.hidden
    if set(binder_labels) != set(pattern.hidden) or len(binder_labels) != len(pattern.hidden):
        raise ValueError("binder_order must be a permutation of hidden pattern variables")
    display = dict(binder_display_names or {})
    atoms = []
    for index in order:
        atom = pattern.atoms[index]
        atoms.append(AtomFactProof(index, tuple(mapping[label] for label in atom.args)))
    root: QueryProofNode = _build_conjunction(atoms)
    for label in binder_labels:
        root = ExistsWitnessProof(label, display.get(label, label), mapping[label], root)
    proof = PatternWitnessProof(match, root)
    validate_pattern_witness_proof(proof)
    return proof


# ---------------------------------------------------------------------------
# Tile / transport proof syntax
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class WitnessTransportProof:
    """Reindex/transport proof for one pointed preservation-tile instance."""

    source: PatternWitnessProof
    hom: RelationalHomomorphism
    target: PatternWitnessProof

    def validate(self) -> bool:
        try:
            validate_pattern_witness_proof(self.source)
            validate_pattern_witness_proof(self.target)
            expected = transport_relational_match(self.source.match, self.hom)
        except (ValueError, ProofValidationError):
            return False
        return self.target.match == expected


@dataclass(frozen=True)
class TileCompositionProof:
    """Composition of two pointed transport proofs along a shared witness."""

    first: WitnessTransportProof
    second: WitnessTransportProof

    def validate(self) -> bool:
        return (
            self.first.validate()
            and self.second.validate()
            and self.first.target.match == self.second.source.match
        )


@dataclass(frozen=True)
class TransportNormalForm:
    """Canonical transport trace: source witness, net map, target witness."""

    source: WitnessNormalForm
    net_map: Tuple[Tuple[str, Tuple[Tuple[object, object], ...]], ...]
    target: WitnessNormalForm


def _normal_map(hom: RelationalHomomorphism) -> Tuple[Tuple[str, Tuple[Tuple[object, object], ...]], ...]:
    return tuple(
        (
            sort.name,
            tuple((value, hom.apply(sort, value)) for value in hom.source.carrier(sort)),
        )
        for sort in hom.signature.sorts
    )


def normalize_transport_proof(
    proof: Union[WitnessTransportProof, TileCompositionProof],
) -> TransportNormalForm:
    """Normalize direct or composed transport to the same net witness trace."""

    if isinstance(proof, WitnessTransportProof):
        if not proof.validate():
            raise ProofValidationError("invalid direct witness transport proof")
        return TransportNormalForm(
            normalize_pattern_witness_proof(proof.source),
            _normal_map(proof.hom),
            normalize_pattern_witness_proof(proof.target),
        )
    if isinstance(proof, TileCompositionProof):
        if not proof.validate():
            raise ProofValidationError("invalid composed witness transport proof")
        net = compose_relational_homomorphisms(proof.second.hom, proof.first.hom)
        return TransportNormalForm(
            normalize_pattern_witness_proof(proof.first.source),
            _normal_map(net),
            normalize_pattern_witness_proof(proof.second.target),
        )
    raise ProofValidationError(f"unsupported transport proof {proof!r}")


@dataclass(frozen=True)
class WitnessTransportCoherenceCell3:
    """A 3-cell between direct and sequential relational witness transport."""

    direct: WitnessTransportProof
    sequential: TileCompositionProof

    def validate(self) -> bool:
        try:
            return (
                self.direct.validate()
                and self.sequential.validate()
                and normalize_transport_proof(self.direct)
                == normalize_transport_proof(self.sequential)
            )
        except ProofValidationError:
            return False


def make_witness_transport_proof(
    source: PatternWitnessProof,
    hom: RelationalHomomorphism,
    *,
    atom_order: Optional[Sequence[int]] = None,
    binder_order: Optional[Sequence[str]] = None,
    binder_display_names: Optional[Dict[str, str]] = None,
) -> WitnessTransportProof:
    target_match = transport_relational_match(source.match, hom)
    target = build_pattern_witness_proof(
        target_match,
        atom_order=atom_order,
        binder_order=binder_order,
        binder_display_names=binder_display_names,
    )
    proof = WitnessTransportProof(source, hom, target)
    if not proof.validate():
        raise RuntimeError("internally constructed witness transport proof did not validate")
    return proof


def compose_witness_transport_proofs(
    first: WitnessTransportProof,
    second: WitnessTransportProof,
) -> TileCompositionProof:
    proof = TileCompositionProof(first, second)
    if not proof.validate():
        raise ProofValidationError("transport proofs do not compose")
    return proof


def make_transport_coherence_cell(
    source: PatternWitnessProof,
    first: RelationalHomomorphism,
    second: RelationalHomomorphism,
) -> WitnessTransportCoherenceCell3:
    """Build a stored 3-cell between direct and sequential transport."""

    first_proof = make_witness_transport_proof(source, first)
    second_proof = make_witness_transport_proof(first_proof.target, second)
    sequential = compose_witness_transport_proofs(first_proof, second_proof)
    composite = compose_relational_homomorphisms(second, first)
    direct = make_witness_transport_proof(source, composite)
    cell = WitnessTransportCoherenceCell3(direct, sequential)
    if not cell.validate():
        raise RuntimeError("internally constructed transport coherence cell did not validate")
    return cell


@dataclass(frozen=True)
class FiniteRelationalTileProof:
    """Finite universal evidence that a homomorphism transports all pattern matches.

    This enumerates every source witness, so it is a finite-model certificate,
    not a replacement for a general syntactic proof of regular-logic soundness.
    """

    pattern: RelationalPattern
    hom: RelationalHomomorphism
    instances: Tuple[WitnessTransportProof, ...]

    def validate(self) -> bool:
        try:
            expected = find_relational_matches(self.pattern, self.hom.source)
        except ValueError:
            return False
        source_matches = tuple(instance.source.match for instance in self.instances)
        expected_keys = {match.mapping for match in expected}
        source_keys = {match.mapping for match in source_matches}
        return (
            source_keys == expected_keys
            and len(source_matches) == len(expected)
            and all(instance.validate() for instance in self.instances)
        )


def make_finite_relational_tile_proof(
    pattern: RelationalPattern,
    hom: RelationalHomomorphism,
) -> FiniteRelationalTileProof:
    instances = tuple(
        make_witness_transport_proof(build_pattern_witness_proof(match), hom)
        for match in find_relational_matches(pattern, hom.source)
    )
    proof = FiniteRelationalTileProof(pattern, hom, instances)
    if not proof.validate():
        raise RuntimeError("internally constructed finite relational tile proof did not validate")
    return proof


@dataclass(frozen=True)
class FailedRawTransportAttempt:
    """A diagnostic for a proposed transport map that is not relation-preserving."""

    source: PatternWitnessProof
    raw: RawRelationalMap

    def diagnostic(self) -> str:
        violation = self.raw.first_relation_violation()
        if violation is None:
            return "raw map is relation-preserving; construct a checked homomorphism instead"
        return violation

    def validates(self) -> bool:
        return False
