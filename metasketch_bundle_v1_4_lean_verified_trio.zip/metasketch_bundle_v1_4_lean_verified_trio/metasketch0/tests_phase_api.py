"""Phase 0.7 tests: validated public API boundary."""

from __future__ import annotations

from . import api
from .semantics import FiniteModel
from .syntax import OpTerm, Signature, Sort, Var, op, v
from .tests import Report


M = Sort("M")
SIG = Signature(sorts=(M,), ops=(("m", (M, M), M), ("e", (), M)), rels=(("R", (M,)),))


def test_checked_context_and_term(rep: Report) -> None:
    x = Var("x", M)
    ctx = api.checked_context(SIG, (x,))
    checked = api.checked_term(SIG, ctx.context, op("m", v(x), OpTerm("e", ())))
    rep.check("API checked construction validates a well-sorted term and retains its sort", checked.sort == M)

    rejected = False
    detail = ""
    try:
        api.checked_term(SIG, ctx.context, OpTerm("m", (v(x),)))
    except Exception as exc:
        rejected = True
        detail = str(exc)
    rep.check("API checked construction rejects an ill-arity raw AST term", rejected and "expects 2" in detail, detail)


def test_checked_model_boundary(rep: Report) -> None:
    model = api.model_from_parts(
        SIG,
        carriers={M: (0, 1)},
        operations={"m": lambda a, b: (a + b) % 2, "e": lambda: 0},
        relations={"R": ((0,),)},
    )
    rep.check("API model factory validates carriers, operations, and relation tuples", model.model.rels["R"] == frozenset({(0,)}))

    rejected = False
    detail = ""
    try:
        api.model_from_parts(
            SIG,
            carriers={M: (0, 1)},
            operations={"m": lambda a, b: (a + b) % 2, "e": lambda: 0},
            relations={"R": ((2,),)},
        )
    except Exception as exc:
        rejected = True
        detail = str(exc)
    rep.check("API model factory rejects a relation tuple outside its carrier", rejected and "outside carrier" in detail, detail)


def test_public_surface(rep: Report) -> None:
    # The safe surface intentionally exposes checked wrappers but not raw AST
    # constructors.  Raw syntax remains available under unsafe_ast for research.
    public_is_small = not hasattr(api, "OpTerm") and hasattr(api, "checked_model")
    from . import unsafe_ast

    raw_available_only_explicitly = hasattr(unsafe_ast, "OpTerm")
    rep.check("API exposes checked construction while raw AST is explicitly experimental", public_is_small and raw_available_only_explicitly)
    rep.check(
        "API exposes the typed pointed-boundary node only through the checked raw-certificate interface",
        hasattr(api, "BoundaryAssignmentProof") and hasattr(api, "checked_raw_certificate"),
    )


def run() -> int:
    rep = Report()
    test_checked_context_and_term(rep)
    test_checked_model_boundary(rep)
    test_public_surface(rep)
    print("=" * 72)
    print("Metasketch-0 Phase 0.7 test report (checked public API)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
