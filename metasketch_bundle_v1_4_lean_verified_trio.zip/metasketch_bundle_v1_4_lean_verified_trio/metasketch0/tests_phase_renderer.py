"""Metasketch v0.6.1 renderer tests.

The renderer is checked as a semantic projection, not as a screenshot generator.
The assertions cover canonical scene construction, typed ports, witness scopes,
parallel 3-cell boundaries, quotation membranes, embedded audit data, and static
showcase generation.
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from xml.etree import ElementTree as ET
import json

from .coherence import pentagon_cell
from .proofs import build_pattern_witness_proof
from .relational import find_relational_matches
from .render import (
    BoundaryTrace,
    RenderScene,
    SceneCell3,
    SceneEdge,
    SceneNode,
    ScenePort,
    SceneRegion,
    render_pentagon,
    render_pattern_witness,
    render_quoted_proof,
    render_transport_coherence,
)
from .showcases import build_showcase_artifacts, transport_showcase_cell, write_showcase_gallery
from .tests import Report
from .tests_phase4 import commuter_friend_pattern, source_model


def _proof_variants():
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    canonical = build_pattern_witness_proof(match)
    reordered = build_pattern_witness_proof(
        match,
        atom_order=(3, 1, 2, 0),
        binder_order=("b", "a"),
        binder_display_names={"a": "left_city", "b": "right_city"},
    )
    return canonical, reordered


def _port(node_id: str, suffix: str, direction: str) -> ScenePort:
    return ScenePort(f"{node_id}_{suffix}", node_id, suffix, "Token", direction, f"port:{node_id}:{suffix}")


def test_canonical_witness_scene(rep: Report) -> None:
    canonical, _ = _proof_variants()
    artifact = render_pattern_witness(canonical)
    scene = artifact.scene
    try:
        scene.validate()
        typed = all(
            next(port for node in scene.nodes for port in node.ports if port.id == edge.source_port).sort
            == next(port for node in scene.nodes for port in node.ports if port.id == edge.target_port).sort
            for edge in scene.edges
            if edge.kind != "code"
        )
        ok = typed and "metasketch-audit" in artifact.svg and artifact.audit_hash in artifact.svg
        detail = f"hash={artifact.audit_hash}, nodes={len(scene.nodes)}, edges={len(scene.edges)}"
    except Exception as exc:  # pragma: no cover - diagnostic path
        ok, detail = False, str(exc)
    rep.check("Renderer builds a validated typed scene from a canonical witness proof", ok, detail)


def test_alpha_and_conjunction_canonicality(rep: Report) -> None:
    canonical, reordered = _proof_variants()
    left = render_pattern_witness(canonical)
    right = render_pattern_witness(reordered)
    rep.check(
        "Renderer gives alpha-renamed and conjunction-reordered proofs one canonical scene graph",
        left.scene.canonical_json() == right.scene.canonical_json() and left.audit_hash == right.audit_hash,
        f"left={left.audit_hash}, right={right.audit_hash}",
    )


def test_witness_scope_boundary(rep: Report) -> None:
    canonical, _ = _proof_variants()
    scene = render_pattern_witness(canonical).scene
    nodes = {node.id: node for node in scene.nodes}
    ports = {port.id: port for node in scene.nodes for port in node.ports}
    okay = True
    detail = []
    for region in scene.regions:
        if region.kind != "witness":
            continue
        binder = nodes[region.binder_node_id]
        binder_ports = {port.id for port in binder.ports if port.direction == "out"}
        for edge in scene.edges:
            if edge.source_port in binder_ports:
                target_node = ports[edge.target_port].node_id
                if target_node not in region.member_nodes:
                    okay = False
                    detail.append(f"{region.bound_variable}->{target_node}")
    rep.check(
        "Renderer keeps every existential witness wire inside its declared witness scope",
        okay,
        ", ".join(detail) or "all bound witness wires remain scoped",
    )


def test_pentagon_cell_boundaries(rep: Report) -> None:
    scene = render_pentagon(pentagon_cell()).scene
    cell = scene.cells3[0]
    rep.check(
        "Renderer preserves the directed pentagon as a 3-cell with parallel typed boundaries",
        cell.left.source_node == cell.right.source_node
        and cell.left.target_node == cell.right.target_node
        and len(cell.left.step_ids) == 2
        and len(cell.right.step_ids) == 3,
        f"left={cell.left.step_ids}, right={cell.right.step_ids}",
    )


def test_transport_cell_boundaries(rep: Report) -> None:
    scene = render_transport_coherence(transport_showcase_cell()).scene
    cell = scene.cells3[0]
    rep.check(
        "Renderer preserves direct and sequential witness transport as parallel 3-cell boundaries",
        cell.left.source_node == cell.right.source_node
        and cell.left.target_node == cell.right.target_node
        and len(cell.left.step_ids) == 2
        and len(cell.right.step_ids) == 3,
        f"left={cell.left.step_ids}, right={cell.right.step_ids}",
    )


def test_quotation_membrane(rep: Report) -> None:
    canonical, _ = _proof_variants()
    scene = render_quoted_proof(canonical).scene
    membrane = next(region for region in scene.regions if region.kind == "membrane")
    code_edges = [edge for edge in scene.edges if edge.kind == "code"]
    ordinary_crossings = [edge for edge in scene.edges if edge.kind != "code"]
    rep.check(
        "Renderer uses a level-raising quotation membrane with only a typed code crossing",
        membrane.level == 1 and len(code_edges) == 1 and not ordinary_crossings,
        f"level={membrane.level}, code_edges={len(code_edges)}, ordinary_edges={len(ordinary_crossings)}",
    )


def test_audit_metadata(rep: Report) -> None:
    artifacts = build_showcase_artifacts()
    all_ok = True
    details = []
    namespace = {"svg": "http://www.w3.org/2000/svg"}
    for name, artifact in artifacts.items():
        root = ET.fromstring(artifact.svg)
        metadata = root.find("svg:metadata", namespace)
        if metadata is None:
            all_ok = False
            details.append(f"{name}: missing metadata")
            continue
        payload = json.loads(metadata.text or "{}")
        if payload.get("audit_hash") != artifact.audit_hash or "semantic_manifest" not in payload:
            all_ok = False
            details.append(f"{name}: bad audit payload")
    rep.check(
        "Every rendered SVG embeds its canonical semantic manifest and matching audit hash",
        all_ok,
        "; ".join(details) or ", ".join(artifacts),
    )


def test_gallery_writer(rep: Report) -> None:
    with TemporaryDirectory() as temp:
        outputs = write_showcase_gallery(Path(temp))
        expected = {"directed_pentagon", "relational_witness", "transport_coherence", "quoted_proof_membrane", "pointed_boundary", "gallery"}
        exists = set(outputs) == expected and all(path.exists() for path in outputs.values())
        svg_ok = all("metasketch-audit" in outputs[name].read_text(encoding="utf-8") for name in expected - {"gallery"})
        gallery_ok = "semantic renderer" in outputs["gallery"].read_text(encoding="utf-8")
    rep.check(
        "Renderer writes five auditable showcase SVGs and a static gallery",
        exists and svg_ok and gallery_ok,
        f"outputs={sorted(outputs)}",
    )


def test_illegal_membrane_crossing_rejected(rep: Report) -> None:
    inside = SceneNode(
        "inside", "proof", "inside", "inside",
        20, 20, 80, 40, parent_region="membrane",
        ports=(_port("inside", "out", "out"),),
    )
    outside = SceneNode(
        "outside", "proof", "outside", "outside",
        180, 20, 80, 40,
        ports=(_port("outside", "in", "in"),),
    )
    membrane = SceneRegion(
        "membrane", "membrane", "quote", "membrane",
        5, 5, 130, 110, member_nodes=("inside",), level=1,
    )
    rejected = False
    detail = ""
    try:
        RenderScene(
            "invalid crossing", 300, 140, (inside, outside), (membrane,),
            (SceneEdge("bad", "term_wire", "inside_out", "outside_in", "bad"),),
            semantic_root="invalid",
        )
    except ValueError as exc:
        rejected = "illegally crosses quotation membrane" in str(exc)
        detail = str(exc)
    rep.check("Renderer rejects an ordinary wire that crosses a quotation membrane", rejected, detail)


def test_nonparallel_cell_rejected(rep: Report) -> None:
    source = SceneNode("source", "proof", "source", "source", 10, 10, 70, 40, ports=(_port("source", "out", "out"),))
    left = SceneNode("left", "proof", "left", "left", 140, 10, 70, 40, ports=(_port("left", "in", "in"),))
    right = SceneNode("right", "proof", "right", "right", 140, 90, 70, 40, ports=(_port("right", "in", "in"),))
    edges = (
        SceneEdge("to_left", "term_wire", "source_out", "left_in", "to_left"),
        SceneEdge("to_right", "term_wire", "source_out", "right_in", "to_right"),
    )
    bad_cell = SceneCell3(
        "bad_cell", "bad", "bad",
        BoundaryTrace("source", "left", ("to_left",), "left_trace"),
        BoundaryTrace("source", "right", ("to_right",), "right_trace"),
        90, 50, 70, 30,
    )
    rejected = False
    detail = ""
    try:
        RenderScene("invalid cell", 250, 160, (source, left, right), (), edges, (bad_cell,), semantic_root="bad")
    except ValueError as exc:
        rejected = "share a target node" in str(exc)
        detail = str(exc)
    rep.check("Renderer rejects a proposed 3-cell whose boundaries are not parallel", rejected, detail)


def run() -> int:
    rep = Report()
    test_canonical_witness_scene(rep)
    test_alpha_and_conjunction_canonicality(rep)
    test_witness_scope_boundary(rep)
    test_pentagon_cell_boundaries(rep)
    test_transport_cell_boundaries(rep)
    test_quotation_membrane(rep)
    test_audit_metadata(rep)
    test_gallery_writer(rep)
    test_illegal_membrane_crossing_rejected(rep)
    test_nonparallel_cell_rejected(rep)
    print("=" * 72)
    print("Metasketch v0.6.1 renderer test report")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
