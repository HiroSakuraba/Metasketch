"""
Metasketch-0 Phase 2.5: structure/logic coherence at the preservation-tile layer.

A structural rewrite d -> d' and predicate transport along d form a critical
square. This module stores that square as a concrete finite 3-cell object rather
than only comparing normal forms:

  reindex(d, Q)          -- normalize -->  N
       | structural transport                 ^
       v                                      |
  reindex(d', Q)         -- normalize -->  N

For the monoid presentation, the filler is sound in monoid models because the
structural steps are instances of associativity or unit laws. A deliberately
non-associative magma can distinguish the two transported predicates, showing
that the square is theory-dependent rather than notation alone.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple

from .syntax import (
    And,
    Context,
    Diagram,
    Eq,
    Exists,
    OpTerm,
    Pred,
    Rel,
    Sort,
    Signature,
    Term,
    Top,
    Var,
    VarTerm,
    reindex,
    v,
)
from .semantics import FiniteModel, extension

M = Sort("M")
MONOID_SIGNATURE = Signature(
    sorts=(M,),
    ops=(("m", (M, M), M), ("e", (), M)),
    rels=(),
)


# ---------------------------------------------------------------------------
# monoid term constructors and directed structural normalization
# ---------------------------------------------------------------------------

def m(a: Term, b: Term) -> Term:
    return OpTerm("m", (a, b))


E: Term = OpTerm("e", ())


def is_m(t: Term) -> bool:
    return isinstance(t, OpTerm) and t.op == "m" and len(t.args) == 2


def is_e(t: Term) -> bool:
    return isinstance(t, OpTerm) and t.op == "e"


def root_rewrite(t: Term) -> Optional[Term]:
    if is_m(t):
        left, right = t.args
        if is_m(left):
            a, b = left.args
            return m(a, m(b, right))
        if is_e(left):
            return right
        if is_e(right):
            return left
    return None


def term_step(t: Term) -> Optional[Term]:
    """One outermost-leftmost monoid rewrite step in a term."""
    rewritten = root_rewrite(t)
    if rewritten is not None:
        return rewritten
    if isinstance(t, OpTerm):
        for i, arg in enumerate(t.args):
            child = term_step(arg)
            if child is not None:
                args = list(t.args)
                args[i] = child
                return OpTerm(t.op, tuple(args))
    return None


def term_nf(t: Term, cap: int = 100000) -> Term:
    count = 0
    while True:
        nxt = term_step(t)
        if nxt is None:
            return t
        t = nxt
        count += 1
        if count > cap:
            raise RuntimeError("term_nf exceeded the resource limit")


# ---------------------------------------------------------------------------
# diagram rewrites and predicate rewrite traces
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DiagramRewriteStep:
    source: Diagram
    target: Diagram
    component: str

    def validate(self) -> bool:
        return diagram_step(self.source) == self.target


@dataclass(frozen=True)
class PredicateRewriteStep:
    source: Pred
    target: Pred


@dataclass(frozen=True)
class PredicateRewriteTrace:
    source: Pred
    steps: Tuple[PredicateRewriteStep, ...]

    @property
    def target(self) -> Pred:
        return self.steps[-1].target if self.steps else self.source

    def is_composable(self) -> bool:
        current = self.source
        for step in self.steps:
            if step.source != current:
                return False
            current = step.target
        return True

    def validate(self) -> bool:
        if not self.is_composable():
            return False
        return all(pred_step(step.source) == step.target for step in self.steps)


def pred_step(p: Pred) -> Optional[Pred]:
    """One outermost-leftmost structural rewrite inside a predicate."""
    if isinstance(p, Top):
        return None
    if isinstance(p, Eq):
        left = term_step(p.left)
        if left is not None:
            return Eq(left, p.right)
        right = term_step(p.right)
        return Eq(p.left, right) if right is not None else None
    if isinstance(p, Rel):
        for i, arg in enumerate(p.args):
            rewritten = term_step(arg)
            if rewritten is not None:
                args = list(p.args)
                args[i] = rewritten
                return Rel(p.name, tuple(args))
        return None
    if isinstance(p, And):
        left = pred_step(p.left)
        if left is not None:
            return And(left, p.right)
        right = pred_step(p.right)
        return And(p.left, right) if right is not None else None
    if isinstance(p, Exists):
        body = pred_step(p.body)
        return Exists(p.var, body) if body is not None else None
    raise TypeError(f"not a predicate: {p!r}")


def pred_nf(p: Pred, cap: int = 100000) -> Pred:
    return pred_normalize(p, cap).target


def pred_normalize(p: Pred, cap: int = 100000) -> PredicateRewriteTrace:
    source = p
    steps = []
    count = 0
    while True:
        nxt = pred_step(p)
        if nxt is None:
            return PredicateRewriteTrace(source, tuple(steps))
        steps.append(PredicateRewriteStep(p, nxt))
        p = nxt
        count += 1
        if count > cap:
            raise RuntimeError("predicate normalization exceeded the resource limit")


def diagram_has_redex(d: Diagram) -> bool:
    return any(term_step(t) is not None for _, t in d.mapping)


def diagram_step(d: Diagram) -> Optional[Diagram]:
    """One outermost-leftmost structural rewrite in the image tuple of a diagram."""
    for i, (name, term) in enumerate(d.mapping):
        rewritten = term_step(term)
        if rewritten is not None:
            mapping = list(d.mapping)
            mapping[i] = (name, rewritten)
            return Diagram(d.source, d.target, tuple(mapping))
    return None


def diagram_nf(d: Diagram) -> Diagram:
    return Diagram(
        d.source,
        d.target,
        tuple((name, term_nf(term)) for name, term in d.mapping),
    )


# ---------------------------------------------------------------------------
# explicit structure/logic coherence filler
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TileCoherenceCell3:
    """A finite 3-cell filling one structural-transport critical square."""

    diagram_step: DiagramRewriteStep
    target_predicate: Pred
    transport_before: Pred
    transport_after: Pred
    left_normalization: PredicateRewriteTrace
    right_normalization: PredicateRewriteTrace

    @property
    def common_normal_form(self) -> Pred:
        return self.left_normalization.target

    def validate(self) -> bool:
        return (
            self.diagram_step.validate()
            and self.transport_before == reindex(self.diagram_step.source, self.target_predicate)
            and self.transport_after == reindex(self.diagram_step.target, self.target_predicate)
            and self.left_normalization.source == self.transport_before
            and self.right_normalization.source == self.transport_after
            and self.left_normalization.validate()
            and self.right_normalization.validate()
            and self.left_normalization.target == self.right_normalization.target
        )


class CoherenceSquare:
    """A constructed and validated Phase 2.5 coherence square."""

    def __init__(self, d: Diagram, q: Pred):
        stepped = diagram_step(d)
        if stepped is None:
            raise ValueError("diagram has no structural redex, so no coherence branching exists")
        self.d = d
        self.q = q
        self.d_stepped = stepped
        self.transport_then = reindex(d, q)
        self.structural_then = reindex(stepped, q)
        self.left_trace = pred_normalize(self.transport_then)
        self.right_trace = pred_normalize(self.structural_then)
        component = next(
            name for (name, before), (_, after) in zip(d.mapping, stepped.mapping)
            if before != after
        )
        self.cell = TileCoherenceCell3(
            DiagramRewriteStep(d, stepped, component),
            q,
            self.transport_then,
            self.structural_then,
            self.left_trace,
            self.right_trace,
        )
        self.left_nf = self.left_trace.target
        self.right_nf = self.right_trace.target

    def coheres_syntactically(self) -> bool:
        return self.cell.validate()

    def coheres_semantically(self, model: FiniteModel, ctx: Context) -> bool:
        return extension(self.transport_then, ctx, model) == extension(
            self.structural_then, ctx, model
        )


def transport_commutes_with_normalization(d: Diagram, q: Pred) -> bool:
    """Check equality of normalized transports along d and its normal form."""
    left = pred_nf(reindex(d, q))
    right = pred_nf(reindex(diagram_nf(d), pred_nf(q)))
    return left == right


# ---------------------------------------------------------------------------
# worked pentagon-in-a-tile example and finite models
# ---------------------------------------------------------------------------

sa, sb, sc, sd = Var("sa", M), Var("sb", M), Var("sc", M), Var("sd", M)
SRC4 = Context((sa, sb, sc, sd))
TGT = Context((Var("y", M),))


def pentagon_tile_diagram() -> Diagram:
    left_comb = m(m(m(v(sa), v(sb)), v(sc)), v(sd))
    return Diagram(SRC4, TGT, (("y", left_comb),))


def pentagon_tile_predicate() -> Pred:
    y = v(Var("y", M))
    return Eq(m(y, y), y)


def monoid_model(n: int, kind: str = "add") -> FiniteModel:
    elems = tuple(range(n))
    if kind == "add":
        mul = lambda a, b: (a + b) % n
        unit = 0
    elif kind == "mul":
        mul = lambda a, b: (a * b) % n
        unit = 1 % n
    else:
        raise ValueError(kind)
    return FiniteModel(
        carriers={M: elems}, ops={"m": mul, "e": (lambda: unit)}, rels={}
    )


def magma_model() -> FiniteModel:
    table = {
        (0, 0): 1, (0, 1): 2, (0, 2): 0,
        (1, 0): 0, (1, 1): 2, (1, 2): 1,
        (2, 0): 2, (2, 1): 0, (2, 2): 1,
    }
    return FiniteModel(
        carriers={M: (0, 1, 2)},
        ops={"m": (lambda a, b: table[(a, b)]), "e": (lambda: 0)},
        rels={},
    )
