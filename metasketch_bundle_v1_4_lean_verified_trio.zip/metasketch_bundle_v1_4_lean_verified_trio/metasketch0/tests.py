"""
Metasketch-0 test suite.

Every claim in the tested fragment is decided by computation. The suite reports
PASS or FAIL per item and a final summary, and the runner exits nonzero if any
item fails. Nothing here asserts a theorem it did not check.

Coverage:
  1. T1 preservation-tile composition is sound (constructed live tiles and a
     random property test), plus reindex functoriality and diagram composition.
  2. The monoid (M0) and graph (M1) libraries have teeth: genuine homomorphisms
     validate preservation tiles, non-homomorphisms break them with a witness.
  3. Reflection: quotation raises level; the certificate checker accepts valid
     and rejects invalid certificates; partial evaluation returns value, bottom,
     or unsupported; the membrane checker forbids same-level total truth.
  4. The Program E boundary: same-level representation-complete truth is
     impossible (sigma_truth >= 1) and one level of stratification escapes it.
"""

from __future__ import annotations
import random
from itertools import product
from typing import List, Tuple

from .syntax import (
    Sort, Var, Context, Diagram, VarTerm, OpTerm, Term,
    Top, Eq, Rel, And, Exists, Signature, StaticCheckError,
    op, v, compose_diagrams, reindex, subst_pred,
    validate_diagram, validate_pred, validate_tile_syntax,
)
from .semantics import (
    FiniteModel, tile_valid_in_model, interpret_diagram, all_envs,
    extension, env_key, satisfies,
)
from .tiles import Tile, compose, valid_in
from . import libraries as lib
from . import reflection as refl


# ---------------------------------------------------------------------------
# tiny test harness
# ---------------------------------------------------------------------------

class Report:
    def __init__(self):
        self.items: List[Tuple[str, bool, str]] = []

    def check(self, name: str, ok: bool, detail: str = ""):
        self.items.append((name, bool(ok), detail))

    def failures(self):
        return [it for it in self.items if not it[1]]

    def render(self) -> str:
        out = []
        for name, ok, detail in self.items:
            tag = "PASS" if ok else "FAIL"
            line = f"[{tag}] {name}"
            if detail and not ok:
                line += f"\n         {detail}"
            elif detail:
                line += f"  ({detail})"
            out.append(line)
        n = len(self.items)
        f = len(self.failures())
        out.append("")
        out.append(f"summary: {n - f}/{n} passed, {f} failed")
        return "\n".join(out)


# ---------------------------------------------------------------------------
# 0. Static validation and capture-avoiding substitution
# ---------------------------------------------------------------------------

def test_static_validation_and_hygiene(rep: Report):
    x = Var("x", A)
    y = Var("y", A)
    src = Context((x,))
    tgt = Context((y,))
    d = Diagram(src, tgt, (("y", v(x)),))

    # Q(y) = exists x. R(y, x). Pulling Q back along y := x must alpha-rename
    # the bound x to avoid producing exists x. R(x, x).
    bound_x = Var("x", A)
    q = Exists(bound_x, Rel("R", (v(y), v(bound_x))))
    pulled = reindex(d, q)
    hygienic = isinstance(pulled, Exists) and pulled.var.name != "x"

    model = FiniteModel(
        carriers={A: (0, 1)},
        ops={"f": lambda a, b: a, "u": lambda a: a},
        rels={"R": frozenset({(0, 1)})},
    )
    syntactic_extension = extension(pulled, src, model)
    semantic_preimage = frozenset(
        env_key(src, env) for env in all_envs(src, model)
        if satisfies(q, interpret_diagram(d, env, model), model)
    )

    static_ok = True
    detail = ""
    try:
        validate_diagram(d, A_SIGNATURE)
        validate_pred(q, A_SIGNATURE, tgt)
        validate_pred(pulled, A_SIGNATURE, src)
        validate_tile_syntax(Top(), d, q, A_SIGNATURE)
    except StaticCheckError as exc:
        static_ok = False
        detail = str(exc)

    invalid_rejected = False
    try:
        validate_pred(Eq(v(x), op("f", v(x))), A_SIGNATURE, src)
    except StaticCheckError:
        invalid_rejected = True

    rep.check("static checker accepts a well-sorted diagram and predicates", static_ok, detail)
    rep.check("static checker rejects an ill-formed operation application", invalid_rejected)
    rep.check("reindexing alpha-renames an existential binder to avoid capture", hygienic)
    rep.check(
        "capture-avoiding reindex equals the semantic preimage",
        syntactic_extension == semantic_preimage,
        f"syntactic={syntactic_extension}, semantic={semantic_preimage}",
    )


# ---------------------------------------------------------------------------
# 1. T1 composition, reindex functoriality, diagram composition
# ---------------------------------------------------------------------------

A = Sort("A")
A_SIGNATURE = Signature(
    sorts=(A,),
    ops=(
        ("f", (A, A), A),
        ("u", (A,), A),
    ),
    rels=(("R", (A, A)),),
)


def random_model(k: int, rng: random.Random) -> FiniteModel:
    elems = tuple(range(k))
    ftab = {(i, j): rng.randrange(k) for i in elems for j in elems}
    utab = {i: rng.randrange(k) for i in elems}
    R = frozenset((i, j) for i in elems for j in elems if rng.random() < 0.4)
    return FiniteModel(
        carriers={A: elems},
        ops={"f": (lambda a, b: ftab[(a, b)]), "u": (lambda a: utab[a])},
        rels={"R": R},
    )


def gen_term(vars_: List[Var], depth: int, rng: random.Random) -> Term:
    if depth <= 0 or rng.random() < 0.5:
        return v(rng.choice(vars_))
    choice = rng.random()
    if choice < 0.5:
        return op("u", gen_term(vars_, depth - 1, rng))
    return op("f", gen_term(vars_, depth - 1, rng), gen_term(vars_, depth - 1, rng))


def gen_pred(vars_: List[Var], depth: int, rng: random.Random):
    r = rng.random()
    if depth <= 0 or r < 0.4:
        if rng.random() < 0.5:
            return Eq(gen_term(vars_, 1, rng), gen_term(vars_, 1, rng))
        return Rel("R", (gen_term(vars_, 1, rng), gen_term(vars_, 1, rng)))
    if r < 0.7:
        return And(gen_pred(vars_, depth - 1, rng), gen_pred(vars_, depth - 1, rng))
    y = Var(f"w{rng.randrange(1000)}", A)
    return Exists(y, gen_pred(vars_ + [y], depth - 1, rng))


def gen_diagram(src: Context, tgt: Context, rng: random.Random) -> Diagram:
    src_vars = list(src.vars)
    mapping = tuple((x.name, gen_term(src_vars, 2, rng)) for x in tgt.vars)
    return Diagram(source=src, target=tgt, mapping=mapping)


def test_T1_and_reindex(rep: Report):
    rng = random.Random(20260701)
    pool = [Var("x0", A), Var("x1", A)]

    live_cases = 0
    t1_fail = None
    reindex_fail = None
    diagcomp_fail = None

    for _ in range(400):
        k = rng.choice([2, 3])
        model = random_model(k, rng)

        def rand_ctx():
            m = rng.choice([1, 2])
            return Context(tuple(pool[:m]))

        gamma, delta, theta = rand_ctx(), rand_ctx(), rand_ctx()
        d = gen_diagram(gamma, delta, rng)   # Gamma -> Delta
        e = gen_diagram(delta, theta, rng)   # Delta -> Theta
        R = gen_pred(list(theta.vars), 2, rng)

        # Construct guaranteed-valid tiles:
        #   Q := e^*R  makes  (Q |- e^*R) valid  (Q equals e^*R)
        #   P := d^*Q  makes  (P |- d^*Q) valid
        Q = reindex(e, R)
        P = reindex(d, Q)
        t1 = Tile(P, d, Q)
        t2 = Tile(Q, e, R)

        r1 = valid_in(t1, model).valid
        r2 = valid_in(t2, model).valid
        if r1 and r2:
            live_cases += 1
            comp = compose(t1, t2)
            if not valid_in(comp, model).valid:
                t1_fail = f"k={k}, P={P!r}, d={d!r}, e={e!r}, R={R!r}"
        else:
            # by construction these must be valid; if not, the machinery is wrong
            t1_fail = f"constructed tile not valid: r1={r1}, r2={r2}"

        # reindex functoriality: (e o d)^* R  ==  d^*(e^* R)   (as extensions over Gamma)
        lhs = reindex(compose_diagrams(e, d), R)
        rhs = reindex(d, reindex(e, R))
        if extension(lhs, gamma, model) != extension(rhs, gamma, model):
            reindex_fail = f"(e o d)^*R != d^*(e^*R): {lhs!r} vs {rhs!r}"

        # diagram composition agrees with function composition
        for env in all_envs(gamma, model):
            via_comp = interpret_diagram(compose_diagrams(e, d), env, model)
            via_seq = interpret_diagram(e, interpret_diagram(d, env, model), model)
            if via_comp != via_seq:
                diagcomp_fail = f"(e o d)(env) != e(d(env)) at {env}"
                break

        if t1_fail or reindex_fail or diagcomp_fail:
            break

    rep.check("T1 preservation-tile composition is sound", t1_fail is None,
              t1_fail or f"{live_cases} live composable tile pairs verified")
    rep.check("reindex is functorial: (e.d)^* = d^* . e^*", reindex_fail is None,
              reindex_fail or "")
    rep.check("diagram composition = function composition", diagcomp_fail is None,
              diagcomp_fail or "")

    # syntactic reindex agrees with semantic preimage on a concrete instance
    model = random_model(3, random.Random(7))
    gamma = Context((pool[0],))
    delta = Context((pool[0],))
    d = Diagram(gamma, delta, ((pool[0].name, op("u", v(pool[0]))),))
    Q = Rel("R", (v(pool[0]), v(pool[0])))
    syn = extension(reindex(d, Q), gamma, model)
    sem = frozenset(
        env_key(gamma, env) for env in all_envs(gamma, model)
        if satisfies(Q, interpret_diagram(d, env, model), model)
    )
    rep.check("syntactic d^*Q equals semantic preimage under d", syn == sem,
              "" if syn == sem else f"{syn} vs {sem}")


# ---------------------------------------------------------------------------
# 2. Library teeth: monoids (M0) and graphs (M1)
# ---------------------------------------------------------------------------

def test_monoid_library(rep: Report):
    Z6 = tuple(range(6))
    mul6 = lambda a, b: (a * b) % 6

    good = lib.monoid_hom_model(Z6, mul6, 1, Z6, mul6, 1, h=lambda x: x)               # identity: a hom
    bad = lib.monoid_hom_model(Z6, mul6, 1, Z6, mul6, 1, h=lambda x: 2 if x == 3 else x)  # sends idempotent 3 to non-idempotent 2

    idem_good = valid_in(lib.tile_preserves_idempotence(), good)
    idem_bad = valid_in(lib.tile_preserves_idempotence(), bad)
    mul_good = valid_in(lib.tile_preserves_multiplication(), good)
    mul_bad = valid_in(lib.tile_preserves_multiplication(), bad)

    rep.check("M0: homomorphism preserves idempotence (tile valid)", idem_good.valid)
    rep.check("M0: non-homomorphism breaks idempotence preservation (invalid, with witness)",
              (not idem_bad.valid) and idem_bad.counterexample is not None,
              f"counterexample env = {idem_bad.counterexample}")
    rep.check("M0: identity map preserves multiplication (hom tile valid)", mul_good.valid)
    rep.check("M0: non-homomorphism fails multiplication tile", not mul_bad.valid,
              f"counterexample env = {mul_bad.counterexample}")


def test_graph_library(rep: Report):
    Vg = (0, 1, 2)
    Eg = ((0, 1), (1, 2))
    Wh = ("a", "b", "c")
    Eh = (("a", "b"), ("b", "c"))

    good = lib.graph_hom_model(Vg, Eg, Wh, Eh, hv=lambda x: {0: "a", 1: "b", 2: "c"}[x])
    bad = lib.graph_hom_model(Vg, Eg, Wh, Eh, hv=lambda x: {0: "a", 1: "b", 2: "a"}[x])

    edge_good = valid_in(lib.tile_preserves_edges(), good)
    edge_bad = valid_in(lib.tile_preserves_edges(), bad)
    path_good = valid_in(lib.tile_preserves_path2(), good)
    path_bad = valid_in(lib.tile_preserves_path2(), bad)

    rep.check("M1: graph homomorphism preserves edges (tile valid)", edge_good.valid)
    rep.check("M1: non-homomorphism breaks edge preservation (invalid, with witness)",
              (not edge_bad.valid) and edge_bad.counterexample is not None,
              f"counterexample env = {edge_bad.counterexample}")
    rep.check("M1: homomorphism preserves length-2 paths (exists in regular logic)", path_good.valid)
    rep.check("M1: non-homomorphism breaks path-2 preservation", not path_bad.valid,
              f"counterexample env = {path_bad.counterexample}")


# ---------------------------------------------------------------------------
# 3. Reflection: quotation, checking, partial eval, membrane
# ---------------------------------------------------------------------------

def test_quotation(rep: Report):
    code = refl.quote({"diagram": "mul.assoc"}, kind="diagram", source_level=0)
    rep.check("quote raises level by exactly one",
              code.source_level == 0 and code.code_level == 1)

    raised = False
    try:
        refl.Code(payload="x", kind="diagram", source_level=0, code_level=0)
    except ValueError:
        raised = True
    rep.check("Code rejects a non-level-raising construction", raised)


def test_certificate_checker(rep: Report):
    from .reflection import Line, Entail, TileJ, check_certificate

    axP_A = Entail("P", "A")
    axP_B = Entail("P", "B")
    axioms = (axP_A, axP_B)

    # valid: introduce And(A,B), then eliminate left back to A
    good_cert = [
        Line("AX", axP_A),
        Line("AX", axP_B),
        Line("CONJ_INTRO", Entail("P", And("A", "B")), premises=(0, 1)),
        Line("CONJ_ELIM_L", Entail("P", "A"), premises=(2,)),
    ]
    good = check_certificate(good_cert, axioms)
    rep.check("check accepts a valid finite certificate", good.accepted,
              good.error or "")

    # invalid: eliminate a conjunct from something that is not a conjunction
    bad_cert = [
        Line("AX", axP_A),
        Line("CONJ_ELIM_L", Entail("P", "A"), premises=(0,)),
    ]
    bad = check_certificate(bad_cert, axioms)
    rep.check("check rejects an invalid certificate", not bad.accepted,
              f"reported: {bad.error} at line {bad.error_line}")


def test_partial_eval(rep: Report):
    # terminating: ab -> b, b -> (empty). normal form is empty string.
    term_rules = (("ab", "b"), ("b", ""))
    r1 = refl.eval_string_rewrite("aab", term_rules, supported_alphabet="ab")
    rep.check("eval returns a value on a terminating computation",
              r1.status == "value", f"value = {r1.value!r}")

    # growing rewrite: the fixed budget is exhausted. This is not a proof of divergence.
    div_rules = (("a", "aa"),)
    r2 = refl.eval_string_rewrite("a", div_rules, supported_alphabet="a", budget=200)
    rep.check("eval reports resource exhaustion rather than a Boolean",
              r2.status == "resource_exhausted")

    # unsupported: symbol outside the declared fragment
    r3 = refl.eval_string_rewrite("aXb", term_rules, supported_alphabet="ab")
    rep.check("eval returns unsupported for an out-of-fragment symbol",
              r3.status == "unsupported")


def test_membrane(rep: Report):
    Spec = refl.InterfaceSpec
    mc = refl.membrane_check

    rep.check("membrane accepts a level-raising quote",
              mc(Spec("quote", 0, 1)).accepted)
    rep.check("membrane rejects a same-level quote",
              not mc(Spec("quote", 0, 0)).accepted)
    rep.check("membrane accepts a higher-level checker",
              mc(Spec("check", 0, 1)).accepted)
    rep.check("membrane rejects a same-level checker",
              not mc(Spec("check", 0, 0)).accepted)

    forbidden = Spec("truth", 0, 0, total=True, representation_complete=True)
    v_forbidden = mc(forbidden)
    rep.check("membrane rejects same-level total representation-complete truth",
              not v_forbidden.accepted, v_forbidden.reason)
    rep.check("membrane accepts stratified truth about a lower level",
              mc(Spec("truth", 0, 1, total=True, representation_complete=True)).accepted)


# ---------------------------------------------------------------------------
# 4. Program E boundary: the diagonal
# ---------------------------------------------------------------------------

def test_program_E_boundary(rep: Report):
    ok2, info2 = refl.finite_same_level_representation_is_incomplete(2, exhaustive=True)
    rep.check("finite diagonal: no same-level Boolean table is complete (n=2, exhaustive)",
              ok2, f"{info2}")

    ok3, info3 = refl.finite_same_level_representation_is_incomplete(3, exhaustive=False, samples=4000)
    rep.check("finite diagonal regression check on sampled tables (n=3)",
              ok3, f"{info3}")

    for n in (2, 3, 4):
        ok, info = refl.stratified_escape(n)
        rep.check(f"stratified escape at n={n}: level k+1 represents all predicates on level k, "
                  f"diagonal ill-typed across the gap", ok, f"{info}")

    # the forbidden interface IS exactly the impossible configuration
    forbidden = refl.InterfaceSpec("truth", 0, 0, total=True, representation_complete=True)
    rejected = not refl.membrane_check(forbidden).accepted
    incomplete = refl.finite_same_level_representation_is_incomplete(2, exhaustive=True)[0]
    rep.check("the membrane blocks the finite-diagonal incomplete interface",
              rejected and incomplete)


# ---------------------------------------------------------------------------
# reflection-cost profile (demonstrated, not proved in general)
# ---------------------------------------------------------------------------

def reflection_cost_profile() -> str:
    rows = [
        ("wf     (well-formedness)", "<= 1", "checkable one level up on quoted syntax"),
        ("check  (proof certificate)", "<= 1", "demonstrated: checker accepts/rejects at level k+1"),
        ("eval   (contextual, partial)", "<= 1", "demonstrated: value / resource_exhausted / unsupported"),
        ("sat    (model-relative)", "<= 1", "model supplied as data at the higher level"),
        ("truth  (same-level, total, complete)", ">= 1", "finite diagonal demonstration of same-level incompleteness"),
    ]
    lines = ["reflection-cost profile for the finite tested fragment F:",
             "  capability                              sigma_X(F)   basis"]
    for cap, bound, basis in rows:
        lines.append(f"  {cap:<38} {bound:<11} {basis}")
    lines.append("  note: these are finite demonstrations, not general theorems.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------

def run() -> int:
    rep = Report()
    test_static_validation_and_hygiene(rep)
    test_T1_and_reindex(rep)
    test_monoid_library(rep)
    test_graph_library(rep)
    test_quotation(rep)
    test_certificate_checker(rep)
    test_partial_eval(rep)
    test_membrane(rep)
    test_program_E_boundary(rep)

    print("=" * 72)
    print("Metasketch-0 test report")
    print("=" * 72)
    print(rep.render())
    print()
    print(reflection_cost_profile())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
