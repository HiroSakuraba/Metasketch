"""Phase 10 tests: proof-carrying finite core and pointed-boundary rendering.

This phase adds independently replayable *instance certificates*.  It does not
claim machine-checked general theorems.  The tests exercise certificate replay,
bounded exhaustive corpora, tamper rejection, portable fixture emission, and the
new renderer convention that external pointed evidence is visually distinct from
an existential witness.
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import json

from .certified_core import (
    audit_finite_monoid_corpus,
    certify_monoid_normalization,
    certify_pointed_reconstruction,
    enumerate_ground_monoid_terms,
)
from .coherence import E, a, b, m, pentagon_source_term
from .formal_fixtures import (
    monoid_certificate_from_json,
    monoid_certificate_to_json,
    replay_fixture_bundle,
    write_fixture_bundle,
)
from .proofs import TruthProof, build_pattern_witness_proof
from .raw_certificates import BoundaryAssignmentProof, RawPatternCertificate, raw_certificate_from_proof
from .relational import find_relational_matches
from .render import render_raw_certificate
from .tests import Report
from .tests_phase4 import commuter_friend_pattern, source_model
from .tests_phase7 import pointed_truth_pattern


def test_monoid_certificate_replay_and_tamper_rejection(rep: Report) -> None:
    certificate = certify_monoid_normalization(pentagon_source_term())
    tampered = replace(certificate, normal_form=E)
    rep.check(
        "Phase10 independently replays a directed monoid-normalization certificate",
        certificate.validate() and len(certificate.trace) == 2 and certificate.word == (a, b, ("atom", "c"), ("atom", "d")),
        f"trace_steps={len(certificate.trace)}, normal={certificate.normal_form!r}",
    )
    rep.check(
        "Phase10 rejects a monoid certificate whose claimed normal form was tampered",
        not tampered.validate(),
        "tampered normal form fails independent replay",
    )


def test_bounded_monoid_corpus(rep: Report) -> None:
    audit = audit_finite_monoid_corpus(("a", "b"), max_depth=2)
    terms = enumerate_ground_monoid_terms(("a", "b"), 2)
    rep.check(
        "Phase10 exhaustively replays certificates for the declared bounded monoid corpus",
        audit.valid and audit.term_count == len(terms) and audit.term_count > 0,
        f"terms={audit.term_count}, max_trace={audit.maximum_trace_length}",
    )


def test_pointed_reconstruction_certificate(rep: Report) -> None:
    pattern = pointed_truth_pattern()
    raw = RawPatternCertificate(
        pattern,
        source_model(),
        TruthProof(),
        (BoundaryAssignmentProof("p", "u", "selected_person"),),
    )
    certificate = certify_pointed_reconstruction(raw)
    tampered = replace(certificate, reconstructed_mapping=(("p", "v"),))
    rep.check(
        "Phase10 independently replays unique pointed raw-certificate reconstruction",
        certificate.validate() and certificate.realizing_mappings == ((('p', 'u'),),),
        f"mapping={certificate.reconstructed_mapping}, realizers={certificate.realizing_mappings}",
    )
    rep.check(
        "Phase10 rejects a pointed reconstruction certificate with a forged witness map",
        not tampered.validate(),
        "forged reconstructed mapping disagrees with replayed evidence",
    )


def test_portable_fixture_bundle(rep: Report) -> None:
    monoid = certify_monoid_normalization(m(m(a, b), E))
    pattern = pointed_truth_pattern()
    pointed = certify_pointed_reconstruction(
        RawPatternCertificate(pattern, source_model(), TruthProof(), (BoundaryAssignmentProof("p", "v"),))
    )
    with TemporaryDirectory() as temp:
        path = write_fixture_bundle(Path(temp) / "fixtures.json", monoid_certificates=(monoid,), pointed_certificates=(pointed,))
        payload = json.loads(path.read_text(encoding="utf-8"))
    rep.check(
        "Phase10 writes language-neutral finite-core fixtures for a future formalization port",
        payload.get("schema") == "metasketch_finite_core_fixture_v1"
        and payload["monoid"][0]["kind"] == "monoid_normalization"
        and payload["pointed_reconstruction"][0]["kind"] == "pointed_raw_reconstruction",
        f"keys={sorted(payload)}",
    )


def test_shipped_fixture_replay(rep: Report) -> None:
    fixture = Path(__file__).resolve().parents[1] / "formal" / "fixtures" / "finite_core_v1.json"
    summary = replay_fixture_bundle(fixture)
    rep.check(
        "Phase10 independently replays every monoid certificate in the shipped fixture file",
        summary["monoid_replayed"] == 2 and summary["pointed_entries"] == 1,
        f"summary={summary}",
    )
    round_trip = monoid_certificate_from_json(
        monoid_certificate_to_json(certify_monoid_normalization(pentagon_source_term()))
    )
    tampered_json = monoid_certificate_to_json(certify_monoid_normalization(pentagon_source_term()))
    tampered_json = dict(tampered_json)
    tampered_json["normal_form"] = {"tag": "app", "symbol": "e", "args": []}
    rep.check(
        "Phase10 fixture JSON round trip preserves replayability and rejects tampering",
        round_trip.validate() and not monoid_certificate_from_json(tampered_json).validate(),
        f"round_trip_steps={len(round_trip.trace)}",
    )


def test_boundary_renderer(rep: Report) -> None:
    raw = RawPatternCertificate(
        pointed_truth_pattern(),
        source_model(),
        TruthProof(),
        (BoundaryAssignmentProof("p", "u", "selected_person"),),
    )
    artifact = render_raw_certificate(raw)
    boundary_nodes = [node for node in artifact.scene.nodes if node.kind == "boundary"]
    all_outside_scopes = all(node.parent_region is None for node in boundary_nodes)
    manifest = artifact.scene.semantic_manifest()
    manifest_has_boundary = any(
        node["semantic"].startswith("boundary_assignment:p=")
        for node in manifest["nodes"]
    )
    rep.check(
        "Phase10 renders pointed boundary evidence as an external typed input rather than an existential witness",
        len(boundary_nodes) == 1 and all_outside_scopes and manifest_has_boundary,
        f"boundary_nodes={[node.id for node in boundary_nodes]}, hash={artifact.audit_hash}",
    )
    rep.check(
        "Phase10 raw-boundary SVG manifest records raw proof provenance and reconstructed witness data",
        "RawPatternCertificate:pointed_truth" in artifact.svg and "reconstructed" in artifact.svg,
        f"root={artifact.scene.semantic_root}",
    )


def test_anchored_visible_stays_structural(rep: Report) -> None:
    match = find_relational_matches(commuter_friend_pattern(), source_model())[0]
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    artifact = render_raw_certificate(raw)
    rep.check(
        "Phase10 relation-anchored visible variables remain structural nodes, not redundant boundary nodes",
        not [node for node in artifact.scene.nodes if node.kind == "boundary"],
        f"node_kinds={[node.kind for node in artifact.scene.nodes]}",
    )


def run() -> int:
    rep = Report()
    test_monoid_certificate_replay_and_tamper_rejection(rep)
    test_bounded_monoid_corpus(rep)
    test_pointed_reconstruction_certificate(rep)
    test_portable_fixture_bundle(rep)
    test_shipped_fixture_replay(rep)
    test_boundary_renderer(rep)
    test_anchored_visible_stays_structural(rep)
    print("=" * 72)
    print("Metasketch v1.1 Phase 10 test report (proof-carrying finite core)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
