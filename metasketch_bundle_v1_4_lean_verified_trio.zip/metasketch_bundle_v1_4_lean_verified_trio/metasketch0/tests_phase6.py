"""Phase 6 tests: reconstruct a semantic witness map from raw certificate syntax.

The Phase-6 raw certificate has no ``RelationalMatch`` field.  These tests
exercise the deliberately restricted reconstruction theorem:

    accepted raw certificate -> unique normalized witness map.

The restriction is that every visible pattern variable occurs in at least one
atom.  Hidden values are supplied by explicit existential binders.  This is a
finite witness-certificate result, not arbitrary first-order proof recovery.
"""

from __future__ import annotations

from .proofs import AndIntroProof, AtomFactProof, ExistsWitnessProof, TruthProof, build_pattern_witness_proof
from .raw_certificates import (
    RawCertificateError,
    RawPatternCertificate,
    audit_raw_certificate_reconstruction,
    canonical_proof_from_raw,
    checked_raw_certificate,
    matches_realizing_raw_certificate,
    normalize_raw_certificate,
    raw_certificate_from_proof,
    reconstruct_raw_match,
    validate_raw_certificate,
)
from .relational import RelationalAtom, RelationalPattern, find_relational_matches
from .reflection_audit import audit_reflective_fragment
from .syntax import Var
from .tests import Report
from .tests_phase4 import PERSON, REL_SIGNATURE, commuter_friend_pattern, open_route_pattern, source_model


def test_raw_certificate_erases_match_field_and_reconstructs(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    model = source_model()
    match = find_relational_matches(pattern, model)[0]
    varied = build_pattern_witness_proof(
        match,
        atom_order=(3, 2, 1, 0),
        binder_order=("b", "a"),
        binder_display_names={"a": "alpha_left", "b": "alpha_right"},
    )
    raw = raw_certificate_from_proof(varied)
    reconstructed = reconstruct_raw_match(raw)
    checked = validate_raw_certificate(raw)
    rep.check(
        "Phase6 raw certificate contains no stored semantic match field",
        not raw.has_explicit_match_field() and not hasattr(raw, "match"),
    )
    rep.check(
        "Phase6 reconstructs exactly the original relational match from fact and binder evidence",
        reconstructed == match and checked.match == match,
        f"reconstructed={reconstructed.mapping}",
    )
    rep.check(
        "Phase6 raw reconstruction preserves the Phase5 canonical witness normal form",
        checked.normal_form == normalize_raw_certificate(raw),
    )


def test_checked_raw_certificate_public_boundary(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    checked = checked_raw_certificate(raw.pattern, raw.model, raw.root)
    rep.check(
        "Phase6 checked public constructor revalidates raw proof syntax and returns its reconstructed witness",
        checked.match == match and checked.certificate == raw,
    )


def test_raw_certificate_is_a_real_program_e_quotation_target(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    audit = audit_reflective_fragment(raw)
    rep.check(
        "Phase6 Program E quotation applies to a raw proof tree with no stored match field",
        audit.quote_level_raising and audit.quoted_kind == "metasketch_proof" and not raw.has_explicit_match_field(),
    )


def test_raw_certificate_unique_finite_semantic_realizer(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    realizing = matches_realizing_raw_certificate(raw)
    audit = audit_raw_certificate_reconstruction(raw)
    rep.check(
        "Phase6 exactly one finite relational match realizes all raw certificate evidence",
        realizing == (match,),
        f"realizers={[candidate.mapping for candidate in realizing]}",
    )
    rep.check(
        "Phase6 raw-certificate adequacy audit passes unique reconstruction and normalized round trip",
        audit.valid,
        f"realizers={audit.evidence_match_count}, reconstructed={audit.reconstructed_mapping}",
    )


def test_raw_certificate_alpha_and_conjunction_presentation_are_ignored(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    canonical_raw = raw_certificate_from_proof(build_pattern_witness_proof(match))
    varied_raw = raw_certificate_from_proof(
        build_pattern_witness_proof(
            match,
            atom_order=(1, 3, 0, 2),
            binder_order=("b", "a"),
            binder_display_names={"a": "left_city", "b": "right_city"},
        )
    )
    rebuilt = canonical_proof_from_raw(varied_raw)
    rep.check(
        "Phase6 alpha-renamed and conjunction-reordered raw certificates reconstruct one normal witness map",
        normalize_raw_certificate(canonical_raw) == normalize_raw_certificate(varied_raw),
    )
    rep.check(
        "Phase6 reconstruction rebuilds a checked canonical Phase5 proof",
        rebuilt.match == match and normalize_raw_certificate(varied_raw) == normalize_raw_certificate(raw_certificate_from_proof(rebuilt)),
    )


def test_raw_certificate_rejects_inconsistent_cross_atom_evidence(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    model = source_model()
    # Knows(u,v), Lives(u,0), Lives(v,1), Road(0,2).  Every fact is true, but
    # b is forced to both 1 and 2.  This isolates reconstruction consistency,
    # rather than simple relation-fact absence.
    leaves = AndIntroProof(
        AtomFactProof(0, ("u", "v")),
        AndIntroProof(
            AtomFactProof(1, ("u", 0)),
            AndIntroProof(
                AtomFactProof(2, ("v", 1)),
                AtomFactProof(3, (0, 2)),
            ),
        ),
    )
    root = ExistsWitnessProof("a", "a", 0, ExistsWitnessProof("b", "b", 1, leaves))
    raw = RawPatternCertificate(pattern, model, root)
    rejected = False
    detail = ""
    try:
        reconstruct_raw_match(raw)
    except RawCertificateError as exc:
        rejected = True
        detail = str(exc)
    rep.check(
        "Phase6 rejects a raw certificate whose true atom facts force incompatible values for one variable",
        rejected and "inconsistent evidence" in detail and "b" in detail,
        detail,
    )


def test_raw_certificate_rejects_nonprefix_existential_scope(rep: Report) -> None:
    pattern = open_route_pattern()
    model = source_model()
    # Both facts are true for p=v and c=1, but the existential binder sits in
    # only the left conjunction branch.  This is not a proof tree for
    # exists c. (Lives(p,c) and Open(c)).
    root = AndIntroProof(
        ExistsWitnessProof("c", "c", 1, AtomFactProof(0, ("v", 1))),
        AtomFactProof(1, (1,)),
    )
    raw = RawPatternCertificate(pattern, model, root)
    rejected = False
    detail = ""
    try:
        reconstruct_raw_match(raw)
    except RawCertificateError as exc:
        rejected = True
        detail = str(exc)
    rep.check(
        "Phase6 rejects an existential witness whose scope does not cover the full conjunction matrix",
        rejected and "outer prefix" in detail,
        detail,
    )


def test_raw_certificate_rejects_missing_hidden_binder(rep: Report) -> None:
    pattern = open_route_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    proof = build_pattern_witness_proof(match)
    # Strip all existential binders while preserving genuine fact leaves.
    root = proof.root
    while isinstance(root, ExistsWitnessProof):
        root = root.body
    raw = RawPatternCertificate(pattern, source_model(), root)
    rejected = False
    detail = ""
    try:
        reconstruct_raw_match(raw)
    except RawCertificateError as exc:
        rejected = True
        detail = str(exc)
    rep.check(
        "Phase6 rejects a raw certificate missing an explicit hidden-variable witness binder",
        rejected and "bind every hidden" in detail,
        detail,
    )


def test_raw_certificate_reports_unanchored_visible_boundary(rep: Report) -> None:
    p = Var("p", PERSON)
    pattern = RelationalPattern(
        "unanchored_visible_truth",
        REL_SIGNATURE,
        (p,),
        ("p",),
        (),
    )
    raw = RawPatternCertificate(pattern, source_model(), TruthProof())
    rejected = False
    detail = ""
    try:
        reconstruct_raw_match(raw)
    except RawCertificateError as exc:
        rejected = True
        detail = str(exc)
    rep.check(
        "Phase6 exposes the deliberate boundary: a visible value absent from all facts needs a separate boundary-assignment node",
        rejected and "unanchored" in detail,
        detail,
    )


def run() -> int:
    rep = Report()
    test_raw_certificate_erases_match_field_and_reconstructs(rep)
    test_checked_raw_certificate_public_boundary(rep)
    test_raw_certificate_is_a_real_program_e_quotation_target(rep)
    test_raw_certificate_unique_finite_semantic_realizer(rep)
    test_raw_certificate_alpha_and_conjunction_presentation_are_ignored(rep)
    test_raw_certificate_rejects_inconsistent_cross_atom_evidence(rep)
    test_raw_certificate_rejects_nonprefix_existential_scope(rep)
    test_raw_certificate_rejects_missing_hidden_binder(rep)
    test_raw_certificate_reports_unanchored_visible_boundary(rep)
    print("=" * 72)
    print("Metasketch-0 Phase 6 test report (raw certificate reconstruction)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
