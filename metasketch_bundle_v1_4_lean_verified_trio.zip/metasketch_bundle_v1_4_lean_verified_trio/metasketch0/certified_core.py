"""Proof-carrying finite certificates for the Metasketch v1.0 baseline.

This module does not replace a proof assistant.  It provides independently
replayable certificates for two finite kernel claims:

1. A concrete ground monoid term normalizes to the right comb of its unit-free
   leaf word through a trace whose every step is checked and decreases the
   declared polynomial interpretation.
2. A pointed raw relational certificate reconstructs one and only one finite
   relational match.  The checker recomputes all semantic realizers rather than
   trusting a stored witness map.

The certificates are deliberately small and serializable by surrounding tools.
They establish instance-level facts.  The general metatheorems remain stated in
the accompanying conventional proof notes and formalization-portability plan.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Tuple

from .coherence import E, MONOID_RULES, interp, m
from .raw_certificates import (
    RawPatternCertificate,
    RawReconstruction,
    matches_realizing_raw_certificate,
    validate_raw_certificate,
)
from .rewriting import (
    Atom,
    RewriteTrace,
    Term,
    args_of,
    is_app,
    is_atom,
    is_var,
    normalize,
    pretty,
    redexes,
    validate_rewrite_trace,
)


class CertificateValidationError(ValueError):
    """Raised when an independently replayed finite certificate is invalid."""


# ---------------------------------------------------------------------------
# Directed monoid normalization certificates
# ---------------------------------------------------------------------------


def is_ground_monoid_term(term: Term) -> bool:
    """Recognize the finite ground fragment used by the monoid certificate."""

    if is_var(term):
        return False
    if is_atom(term):
        return True
    if is_app(term) and term[0] == "e" and len(term) == 1:
        return True
    if is_app(term) and term[0] == "m" and len(term) == 3:
        return is_ground_monoid_term(term[1]) and is_ground_monoid_term(term[2])
    return False


def flatten_word(term: Term) -> Tuple[Term, ...]:
    """Return the unit-free leaf word of a ground monoid term."""

    if not is_ground_monoid_term(term):
        raise CertificateValidationError(f"not a ground monoid term: {pretty(term)}")
    if is_atom(term):
        return (term,)
    if is_app(term) and term[0] == "e":
        return ()
    left, right = args_of(term)
    return flatten_word(left) + flatten_word(right)


def right_comb(word: Sequence[Term]) -> Term:
    """Build the canonical right-associated product of a unit-free word."""

    if not word:
        return E
    current = word[-1]
    for item in reversed(word[:-1]):
        current = m(item, current)
    return current


@dataclass(frozen=True)
class MonoidNormalizationCertificate:
    """A replayable instance certificate for one directed normalization run."""

    source: Term
    trace: RewriteTrace
    word: Tuple[Term, ...]
    normal_form: Term
    interpretation_pairs: Tuple[Tuple[int, int], ...]

    def validate(self) -> bool:
        """Replay every rewrite and check the canonical target independently."""

        try:
            if not is_ground_monoid_term(self.source):
                return False
            if self.trace.source != self.source:
                return False
            if self.trace.target != self.normal_form:
                return False
            if not validate_rewrite_trace(self.trace, MONOID_RULES):
                return False
            if self.word != flatten_word(self.source):
                return False
            if self.normal_form != right_comb(self.word):
                return False
            if redexes(self.normal_form, MONOID_RULES):
                return False
            observed_pairs = tuple((interp(step.source), interp(step.target)) for step in self.trace.steps)
            if observed_pairs != self.interpretation_pairs:
                return False
            if any(before <= after for before, after in observed_pairs):
                return False
            return True
        except (ValueError, CertificateValidationError):
            return False

    def require_valid(self) -> "MonoidNormalizationCertificate":
        if not self.validate():
            raise CertificateValidationError("invalid monoid-normalization certificate")
        return self


def certify_monoid_normalization(term: Term) -> MonoidNormalizationCertificate:
    """Produce a certificate from the kernel normalizer, then replay-check it."""

    if not is_ground_monoid_term(term):
        raise CertificateValidationError("monoid normalization certificates require ground terms")
    normal_form, trace = normalize(term, MONOID_RULES)
    certificate = MonoidNormalizationCertificate(
        source=term,
        trace=trace,
        word=flatten_word(term),
        normal_form=normal_form,
        interpretation_pairs=tuple((interp(step.source), interp(step.target)) for step in trace.steps),
    )
    return certificate.require_valid()


def enumerate_ground_monoid_terms(atom_names: Sequence[str] = ("a", "b"), max_depth: int = 2) -> Tuple[Term, ...]:
    """Exhaustively enumerate distinct ground terms whose tree depth is bounded.

    This is a finite audit generator, not an induction principle.  It deliberately
    retains all terms of depth at most ``max_depth`` so certificates can be replayed
    against a fixed, transparent corpus.
    """

    if max_depth < 0:
        raise ValueError("max_depth must be nonnegative")
    base = {E, *(Atom(name) for name in atom_names)}
    accumulated = set(base)
    for _ in range(max_depth):
        new_terms = {
            m(left, right)
            for left in accumulated
            for right in accumulated
        }
        accumulated |= new_terms
    return tuple(sorted(accumulated, key=repr))


@dataclass(frozen=True)
class FiniteMonoidCorpusAudit:
    """Summary of exhaustive certificate replay over one bounded corpus."""

    atom_names: Tuple[str, ...]
    max_depth: int
    term_count: int
    certificate_count: int
    maximum_trace_length: int

    @property
    def valid(self) -> bool:
        return self.term_count == self.certificate_count


def audit_finite_monoid_corpus(
    atom_names: Sequence[str] = ("a", "b"), max_depth: int = 2
) -> FiniteMonoidCorpusAudit:
    """Build and independently replay certificates for a complete bounded corpus."""

    terms = enumerate_ground_monoid_terms(atom_names, max_depth)
    certificates = tuple(certify_monoid_normalization(term) for term in terms)
    if not all(certificate.validate() for certificate in certificates):
        raise CertificateValidationError("bounded monoid corpus contains an unreplayable certificate")
    return FiniteMonoidCorpusAudit(
        atom_names=tuple(atom_names),
        max_depth=max_depth,
        term_count=len(terms),
        certificate_count=len(certificates),
        maximum_trace_length=max((len(certificate.trace) for certificate in certificates), default=0),
    )


# ---------------------------------------------------------------------------
# Pointed raw-certificate reconstruction certificates
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PointedReconstructionCertificate:
    """A replayable certificate for unique finite raw-proof reconstruction.

    The raw proof contains no stored ``RelationalMatch``.  This wrapper stores the
    reconstructed mapping and expects the checker to recompute both the mapping
    and the complete finite set of matches realizing the raw evidence.
    """

    raw: RawPatternCertificate
    reconstructed_mapping: Tuple[Tuple[str, object], ...]
    realizing_mappings: Tuple[Tuple[Tuple[str, object], ...], ...]
    evidence: Tuple[Tuple[str, Tuple[Tuple[str, object], ...]], ...]

    def validate(self) -> bool:
        try:
            reconstruction: RawReconstruction = validate_raw_certificate(self.raw)
            realizing = matches_realizing_raw_certificate(self.raw)
            observed_mappings = tuple(match.mapping for match in realizing)
            if reconstruction.match.mapping != self.reconstructed_mapping:
                return False
            if observed_mappings != self.realizing_mappings:
                return False
            if reconstruction.evidence != self.evidence:
                return False
            if len(realizing) != 1:
                return False
            if realizing[0].mapping != self.reconstructed_mapping:
                return False
            return True
        except (ValueError, CertificateValidationError):
            return False

    def require_valid(self) -> "PointedReconstructionCertificate":
        if not self.validate():
            raise CertificateValidationError("invalid pointed reconstruction certificate")
        return self


def certify_pointed_reconstruction(raw: RawPatternCertificate) -> PointedReconstructionCertificate:
    """Construct a unique-reconstruction certificate and replay it immediately."""

    reconstruction = validate_raw_certificate(raw)
    realizing = matches_realizing_raw_certificate(raw)
    certificate = PointedReconstructionCertificate(
        raw=raw,
        reconstructed_mapping=reconstruction.match.mapping,
        realizing_mappings=tuple(match.mapping for match in realizing),
        evidence=reconstruction.evidence,
    )
    return certificate.require_valid()


__all__ = [
    "CertificateValidationError",
    "is_ground_monoid_term",
    "flatten_word",
    "right_comb",
    "MonoidNormalizationCertificate",
    "certify_monoid_normalization",
    "enumerate_ground_monoid_terms",
    "FiniteMonoidCorpusAudit",
    "audit_finite_monoid_corpus",
    "PointedReconstructionCertificate",
    "certify_pointed_reconstruction",
]
