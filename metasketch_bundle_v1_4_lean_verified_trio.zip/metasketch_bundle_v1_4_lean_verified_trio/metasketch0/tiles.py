"""
Metasketch-0 preservation tiles and their composition.

A preservation tile is the central primitive of the design. It is the judgment

    P |- d^*Q

for a structural diagram d : Gamma -> Delta, a predicate P over Gamma, and a
predicate Q over Delta. It has two readings at once:

  Structural: every input satisfying P is mapped by d to an output satisfying Q.
  Logical:    P entails the substitution of Q along d.

Theorem T1 (preservation-tile composition, the first milestone in the design):

    (P |- d^*Q) and (Q |- e^*R)  implies  (P |- (e o d)^*R).

Here we build the composite tile and, in the test suite, check by finite-model
computation that composition preserves validity. That computation is the actual
content: T1 is not assumed, it is verified on every model in the library.
"""

from __future__ import annotations
from dataclasses import dataclass

from .syntax import Pred, Diagram, compose_diagrams
from .semantics import FiniteModel, tile_valid_in_model, TileResult


@dataclass(frozen=True)
class Tile:
    """The judgment P |- d^*Q, i.e. source predicate P, diagram d, target Q."""
    p: Pred      # predicate over d.source
    d: Diagram   # d : source -> target
    q: Pred      # predicate over d.target

    def __repr__(self) -> str:
        return f"({self.p!r}) |- d^*({self.q!r})  with d = {self.d!r}"


def valid_in(tile: Tile, model: FiniteModel) -> TileResult:
    return tile_valid_in_model(tile.p, tile.d, tile.q, model)


def compose(t1: Tile, t2: Tile) -> Tile:
    """
    Compose two tiles that meet at the middle predicate.

      t1 : P |- d^*Q     with d : Gamma -> Delta
      t2 : Q |- e^*R     with e : Delta -> Theta
      result : P |- (e o d)^*R   with e o d : Gamma -> Theta

    Requires t1.q == t2.p (the shared middle) and e.source == d.target.
    """
    if t1.q != t2.p:
        raise ValueError(
            "compose: middle predicates do not match; "
            f"t1.q = {t1.q!r}, t2.p = {t2.p!r}"
        )
    if t2.d.source != t1.d.target:
        raise ValueError("compose: t2 diagram source must equal t1 diagram target")
    e_after_d = compose_diagrams(t2.d, t1.d)
    return Tile(p=t1.p, d=e_after_d, q=t2.q)
