"""Metasketch-0 Phase 3 tests: conjunctive-query transport.

Phase 3 is the first non-monoid result that uses all three active layers:

  - a finite graph homomorphism as structural data;
  - an existential-conjunctive pattern query as regular logic; and
  - an explicit 3-cell equating direct with sequential transport of a concrete
    existential witness.

Every statement is finite and executable.  The module does not claim a general
completeness theorem for conjunctive queries or graph homomorphisms.
"""

from __future__ import annotations
from itertools import product

from .checked import checked_diagram, checked_predicate, checked_tile
from .queries import (
    CompiledQuery,
    FiniteDirectedGraph,
    GraphHomomorphism,
    PatternGraph,
    PatternMatch,
    compile_conjunctive_query,
    find_matches,
    graph_model,
    matches_with_visible_assignment,
)
from .query_transport import make_query_transport_coherence_cell
from .semantics import FiniteModel, ModelValidationError, extension, validate_finite_model
from .syntax import (
    And,
    Context,
    Diagram,
    Exists,
    Rel,
    Signature,
    Sort,
    Var,
    reindex,
    op,
    v,
    validate_pred,
)
from .tests import Report
from .tiles import Tile, compose, valid_in


VG = Sort("VG")
VH = Sort("VH")
VK = Sort("VK")

CHAIN_SIGNATURE = Signature(
    sorts=(VG, VH, VK),
    ops=(
        ("h", (VG,), VH),
        ("k", (VH,), VK),
    ),
    rels=(
        ("EG", (VG, VG)),
        ("EH", (VH, VH)),
        ("EK", (VK, VK)),
    ),
)

ONE_GRAPH_SIGNATURE = Signature(
    sorts=(VG,),
    ops=(),
    rels=(("EG", (VG, VG)),),
)


def _patterns() -> tuple[PatternGraph, ...]:
    return (
        PatternGraph("edge", ("s", "t"), (("s", "t"),), ("s", "t")),
        PatternGraph("path2", ("s", "m", "t"), (("s", "m"), ("m", "t")), ("s", "t")),
        PatternGraph("fork", ("s", "l", "r"), (("s", "l"), ("s", "r")), ("s",)),
        PatternGraph(
            "diamond",
            ("s", "l", "r", "t"),
            (("s", "l"), ("s", "r"), ("l", "t"), ("r", "t")),
            ("s", "t"),
        ),
        PatternGraph("triangle", ("a", "b", "c"), (("a", "b"), ("b", "c"), ("c", "a")), ("a", "b", "c")),
    )


def _source_graph() -> FiniteDirectedGraph:
    # Diamond, plus a 0 -> 1 -> 2 -> 0 triangle.
    return FiniteDirectedGraph(
        "G",
        (0, 1, 2, 3),
        frozenset({(0, 1), (0, 2), (1, 3), (2, 3), (1, 2), (2, 0)}),
    )


def _target_graph() -> FiniteDirectedGraph:
    return FiniteDirectedGraph(
        "H",
        ("a", "b", "c", "d"),
        frozenset({("a", "b"), ("a", "c"), ("b", "d"), ("c", "d"), ("b", "c"), ("c", "a")}),
    )


def _third_graph() -> FiniteDirectedGraph:
    # `b` and `c` deliberately merge.  Homomorphisms and conjunctive-query
    # matches need not be injective.
    return FiniteDirectedGraph(
        "K",
        ("A", "B", "D"),
        frozenset({("A", "B"), ("B", "D"), ("B", "A"), ("B", "B")}),
    )


def _hom_chain() -> tuple[GraphHomomorphism, GraphHomomorphism]:
    g, h, k = _source_graph(), _target_graph(), _third_graph()
    gh = GraphHomomorphism("h", g, h, ((0, "a"), (1, "b"), (2, "c"), (3, "d")))
    hk = GraphHomomorphism("k", h, k, (("a", "A"), ("b", "B"), ("c", "B"), ("d", "D")))
    return gh, hk


def _compiled(pattern: PatternGraph, sort: Sort, relation: str, prefix: str) -> CompiledQuery:
    visible = {label: Var(f"{prefix}_{label}", sort) for label in pattern.visible}
    return compile_conjunctive_query(
        pattern,
        visible_vars=visible,
        vertex_sort=sort,
        edge_relation=relation,
        witness_prefix=f"{prefix}_w",
    )


def _chain_model() -> FiniteModel:
    g, h, k = _source_graph(), _target_graph(), _third_graph()
    gh, hk = _hom_chain()
    h_table, k_table = gh.as_dict(), hk.as_dict()
    return FiniteModel(
        carriers={VG: g.vertices, VH: h.vertices, VK: k.vertices},
        ops={"h": lambda x: h_table[x], "k": lambda x: k_table[x]},
        rels={"EG": g.edges, "EH": h.edges, "EK": k.edges},
    )


def _diagram_for_h(source: CompiledQuery, target: CompiledQuery) -> Diagram:
    return Diagram(
        source.context,
        target.context,
        tuple(
            (target.var_for(label).name, op("h", v(source.var_for(label))))
            for label in source.pattern.visible
        ),
    )


def _diagram_for_k(source: CompiledQuery, target: CompiledQuery) -> Diagram:
    return Diagram(
        source.context,
        target.context,
        tuple(
            (target.var_for(label).name, op("k", v(source.var_for(label))))
            for label in source.pattern.visible
        ),
    )


def test_checked_public_boundary_and_model_validation(rep: Report) -> None:
    pattern = next(item for item in _patterns() if item.name == "diamond")
    compiled = _compiled(pattern, VG, "EG", "g")
    model = graph_model(_source_graph(), vertex_sort=VG, edge_relation="EG")

    checked_ok = True
    try:
        checked_predicate(ONE_GRAPH_SIGNATURE, compiled.context, compiled.predicate)
        validate_finite_model(model, ONE_GRAPH_SIGNATURE)
    except Exception as exc:  # pragma: no cover - diagnostic path
        checked_ok = False
        detail = str(exc)
    else:
        detail = ""
    rep.check("Phase3 checked public boundary accepts a compiled pattern query", checked_ok, detail)

    malformed = FiniteModel(
        carriers={VG: (0, 1)},
        ops={},
        rels={"EG": frozenset({(0, 2)})},
    )
    rejected = False
    try:
        validate_finite_model(malformed, ONE_GRAPH_SIGNATURE)
    except ModelValidationError:
        rejected = True
    rep.check("Phase3 finite-model checker rejects a relation tuple outside its carrier", rejected)


def test_nested_hygiene_under_simultaneous_substitution(rep: Report) -> None:
    x, y, a, b = Var("x", VG), Var("y", VG), Var("a", VG), Var("b", VG)
    source, target = Context((x, y)), Context((a, b))
    swap = Diagram(source, target, (("a", v(y)), ("b", v(x))))

    # Both bound names would be captured by the simultaneous a:=y, b:=x map
    # without alpha-renaming.
    bx, by = Var("x", VG), Var("y", VG)
    query = Exists(
        bx,
        Exists(
            by,
            And(Rel("EG", (v(a), v(bx))), Rel("EG", (v(b), v(by)))),
        ),
    )
    pulled = reindex(swap, query)
    hygienic = isinstance(pulled, Exists) and isinstance(pulled.body, Exists)
    names = (pulled.var.name, pulled.body.var.name) if hygienic else ()
    no_capture = hygienic and set(names).isdisjoint({"x", "y"})

    graph = FiniteDirectedGraph("tiny", (0, 1), frozenset({(0, 1), (1, 0)}))
    model = graph_model(graph, vertex_sort=VG, edge_relation="EG")
    semantic = frozenset()
    # Compare pullback extension with direct substitution semantics.  Because the
    # query is over target variables a,b and swap maps a:=y, b:=x, the semantic
    # preimage is evaluated with a target environment induced from each source.
    from .semantics import all_envs, env_key, interpret_diagram, satisfies
    semantic = frozenset(
        env_key(source, env)
        for env in all_envs(source, model)
        if satisfies(query, interpret_diagram(swap, env, model), model)
    )
    static_ok = True
    try:
        validate_pred(query, ONE_GRAPH_SIGNATURE, target)
        validate_pred(pulled, ONE_GRAPH_SIGNATURE, source)
    except Exception:
        static_ok = False

    rep.check("Phase3 simultaneous substitution alpha-renames nested existential binders", no_capture, f"binders={names}")
    rep.check("Phase3 nested capture-avoiding substitution matches its semantic preimage", extension(pulled, source, model) == semantic)
    rep.check("Phase3 nested hygienic pullback passes the static checker", static_ok)


def test_pattern_compilation_matches_witness_enumeration(rep: Report) -> None:
    graph = _source_graph()
    model = graph_model(graph, vertex_sort=VG, edge_relation="EG")
    details = []
    all_ok = True
    for pattern in _patterns():
        compiled = _compiled(pattern, VG, "EG", f"q_{pattern.name}")
        validate_pred(compiled.predicate, ONE_GRAPH_SIGNATURE, compiled.context)
        query_assignments = set()
        for row in extension(compiled.predicate, compiled.context, model):
            query_assignments.add(tuple(zip(pattern.visible, row)))
        witness_assignments = {
            tuple((label, match.as_dict()[label]) for label in pattern.visible)
            for match in find_matches(pattern, graph)
        }
        if query_assignments != witness_assignments:
            all_ok = False
            details.append(pattern.name)
    rep.check(
        "Phase3 compiled edge, path, fork, diamond, and triangle queries agree with witness enumeration",
        all_ok,
        ", ".join(details),
    )


def test_query_tiles_and_composition(rep: Report) -> None:
    diamond = next(item for item in _patterns() if item.name == "diamond")
    qg, qh, qk = _compiled(diamond, VG, "EG", "g"), _compiled(diamond, VH, "EH", "h"), _compiled(diamond, VK, "EK", "k")
    d_h, d_k = _diagram_for_h(qg, qh), _diagram_for_k(qh, qk)
    t_h, t_k = Tile(qg.predicate, d_h, qh.predicate), Tile(qh.predicate, d_k, qk.predicate)
    model = _chain_model()

    static_ok = True
    try:
        checked_diagram(CHAIN_SIGNATURE, d_h)
        checked_diagram(CHAIN_SIGNATURE, d_k)
        checked_tile(CHAIN_SIGNATURE, t_h)
        checked_tile(CHAIN_SIGNATURE, t_k)
        validate_finite_model(model, CHAIN_SIGNATURE)
    except Exception as exc:  # pragma: no cover - diagnostic path
        static_ok = False
        detail = str(exc)
    else:
        detail = ""

    direct_ok = valid_in(t_h, model).valid and valid_in(t_k, model).valid
    composed = compose(t_h, t_k)
    composition_ok = valid_in(composed, model).valid
    rep.check("Phase3 diamond-query tiles pass static checks in the graph-chain signature", static_ok, detail)
    rep.check("Phase3 graph homomorphisms preserve the compiled diamond query", direct_ok)
    rep.check("Phase3 query-preservation tiles compose through an intermediate graph", composition_ok)

    # A deliberately non-homomorphic operation is allowed in a raw finite model
    # only to demonstrate a concrete failing query-preservation tile.
    bad_table = {0: "a", 1: "b", 2: "c", 3: "b"}
    g, h = _source_graph(), _target_graph()
    bad_model = FiniteModel(
        carriers={VG: g.vertices, VH: h.vertices, VK: _third_graph().vertices},
        ops={"h": lambda x: bad_table[x], "k": _hom_chain()[1].apply},
        rels={"EG": g.edges, "EH": h.edges, "EK": _third_graph().edges},
    )
    bad_result = valid_in(t_h, bad_model)
    rep.check(
        "Phase3 a non-homomorphic graph map breaks the diamond-query tile with a witness",
        (not bad_result.valid) and bad_result.counterexample is not None,
        f"counterexample={bad_result.counterexample}",
    )


def test_witness_transport_coherence(rep: Report) -> None:
    diamond = next(item for item in _patterns() if item.name == "diamond")
    g = _source_graph()
    match = PatternMatch(diamond, g, (("s", 0), ("l", 1), ("r", 2), ("t", 3)))
    h, k = _hom_chain()
    cell = make_query_transport_coherence_cell(match, h, k)

    expected_visible = {"s": "A", "t": "D"}
    rep.check("Phase3 direct and sequential witness transport have an explicit validated 3-cell", cell.validate())
    rep.check("Phase3 coherence cell preserves the visible query assignment", cell.target.visible_assignment() == expected_visible, f"got={cell.target.visible_assignment()}")
    rep.check("Phase3 noninjective transport remains a valid conjunctive-query witness", cell.target.as_dict()["l"] == cell.target.as_dict()["r"] == "B")


def test_invalid_graph_homomorphism_is_rejected(rep: Report) -> None:
    rejected = False
    try:
        GraphHomomorphism(
            "bad",
            _source_graph(),
            _target_graph(),
            ((0, "a"), (1, "b"), (2, "c"), (3, "a")),
        )
    except ValueError:
        rejected = True
    rep.check("Phase3 graph-homomorphism constructor rejects a non-edge-preserving map", rejected)


def run() -> int:
    rep = Report()
    test_checked_public_boundary_and_model_validation(rep)
    test_nested_hygiene_under_simultaneous_substitution(rep)
    test_pattern_compilation_matches_witness_enumeration(rep)
    test_query_tiles_and_composition(rep)
    test_witness_transport_coherence(rep)
    test_invalid_graph_homomorphism_is_rejected(rep)

    print("=" * 72)
    print("Metasketch-0 Phase 3 test report (conjunctive-query transport)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
