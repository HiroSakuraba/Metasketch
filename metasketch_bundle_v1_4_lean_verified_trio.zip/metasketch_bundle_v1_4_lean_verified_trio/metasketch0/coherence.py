"""
Metasketch-0 Phase 2: a convergent monoid rewriting presentation.

The oriented rules are:

  alpha : m(m(x, y), z) -> m(x, m(y, z))
  lam   : m(e, x)       -> x
  rho   : m(x, e)       -> x

The kernel stores rewrite traces and explicit confluence fillers. The resulting
objects are directed rewrite-theoretic analogues of the familiar associator
pentagon and unit coherence diagrams. They are not yet invertible monoidal
associators, so this module does not claim full Mac Lane coherence.

Termination has a short paper proof. With I(atom)=I(e)=1 and
I(m(a,b))=2 I(a)+I(b):

  I(m(m(a,b),c)) - I(m(a,m(b,c))) = 2 I(a) > 0,
  I(m(e,x)) - I(x) = 2,
  I(m(x,e)) - I(x) = 1.

Thus every directed rule strictly decreases I on ground terms.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Tuple

from .rewriting import (
    CriticalPair,
    RewriteStep,
    RewriteTrace,
    Term,
    Var,
    Atom,
    App,
    Rule,
    normalize,
    is_atom,
    is_app,
    args_of,
    pretty,
    rewrite_at_with_step,
    validate_rewrite_trace,
)


# ---------------------------------------------------------------------------
# signature helpers
# ---------------------------------------------------------------------------

def m(a: Term, b: Term) -> Term:
    return App("m", a, b)


E: Term = App("e")
a, b, c, d = Atom("a"), Atom("b"), Atom("c"), Atom("d")
X, Y, Z = Var("x"), Var("y"), Var("z")


# ---------------------------------------------------------------------------
# the rules
# ---------------------------------------------------------------------------

alpha = Rule("alpha", m(m(X, Y), Z), m(X, m(Y, Z)))
lam = Rule("lam", m(E, X), X)
rho = Rule("rho", m(X, E), X)
MONOID_RULES: List[Rule] = [alpha, lam, rho]


# ---------------------------------------------------------------------------
# termination interpretation
# ---------------------------------------------------------------------------

def interp(t: Term) -> int:
    """I(atom)=I(e)=1 and I(m(a,b))=2 I(a)+I(b) on ground monoid terms."""
    if is_atom(t):
        return 1
    if is_app(t) and t[0] == "e":
        return 1
    if is_app(t) and t[0] == "m":
        aa, bb = args_of(t)
        return 2 * interp(aa) + interp(bb)
    raise ValueError(f"interp is defined on ground monoid terms only: {pretty(t)}")


def termination_argument() -> str:
    return (
        "alpha decreases by 2I(a)>0; lam decreases by 2; rho decreases by 1. "
        "Therefore the polynomial interpretation is a strict reduction order."
    )


# ---------------------------------------------------------------------------
# explicit directed confluence fillers
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CoherenceCell3:
    """A stored confluence filler between parallel directed rewrite traces."""

    name: str
    left: RewriteTrace
    right: RewriteTrace

    def __post_init__(self):
        if self.left.source != self.right.source:
            raise ValueError("3-cell traces must have the same source")
        if self.left.target != self.right.target:
            raise ValueError("3-cell traces must have the same target")

    @property
    def source(self) -> Term:
        return self.left.source

    @property
    def target(self) -> Term:
        return self.left.target

    def validate(self, rules: Iterable[Rule]) -> bool:
        return (
            self.left.source == self.right.source
            and self.left.target == self.right.target
            and validate_rewrite_trace(self.left, rules)
            and validate_rewrite_trace(self.right, rules)
        )


def _trace_from_steps(source: Term, steps: List[RewriteStep]) -> RewriteTrace:
    trace = RewriteTrace(source, tuple(steps))
    if not trace.is_composable():
        raise ValueError("rewrite trace is not composable")
    return trace


def _append_traces(first: RewriteTrace, second: RewriteTrace) -> RewriteTrace:
    if first.target != second.source:
        raise ValueError("cannot append traces with mismatched boundary")
    return RewriteTrace(first.source, first.steps + second.steps)


# ---------------------------------------------------------------------------
# pentagon-shaped confluence cell
# ---------------------------------------------------------------------------

def pentagon_source_term() -> Term:
    return m(m(m(a, b), c), d)


def pentagon_target_term() -> Term:
    return m(a, m(b, m(c, d)))


def pentagon_route_short() -> RewriteTrace:
    """Two directed alpha steps from ((ab)c)d to a(b(cd))."""
    t0 = pentagon_source_term()
    s1 = rewrite_at_with_step(t0, (), alpha)
    if s1 is None:
        raise AssertionError("expected alpha redex at the root")
    s2 = rewrite_at_with_step(s1.target, (), alpha)
    if s2 is None:
        raise AssertionError("expected second alpha redex at the root")
    return _trace_from_steps(t0, [s1, s2])


def pentagon_route_long() -> RewriteTrace:
    """Three directed alpha steps from ((ab)c)d to a(b(cd))."""
    t0 = pentagon_source_term()
    s1 = rewrite_at_with_step(t0, (0,), alpha)
    if s1 is None:
        raise AssertionError("expected alpha redex at position (0,)")
    s2 = rewrite_at_with_step(s1.target, (), alpha)
    if s2 is None:
        raise AssertionError("expected alpha redex at the root")
    s3 = rewrite_at_with_step(s2.target, (1,), alpha)
    if s3 is None:
        raise AssertionError("expected alpha redex at position (1,)")
    return _trace_from_steps(t0, [s1, s2, s3])


def pentagon_cell() -> CoherenceCell3:
    return CoherenceCell3("directed_associator_pentagon", pentagon_route_short(), pentagon_route_long())


def critical_pair_filler(cp: CriticalPair, rules: List[Rule]) -> CoherenceCell3:
    """Build a normal-form confluence filler for one enumerated critical pair."""
    rule_by_name = {rule.name: rule for rule in rules}
    outer_rule = rule_by_name[cp.rule1]
    inner_rule = rule_by_name[cp.rule2]
    outer_first = rewrite_at_with_step(cp.overlap, (), outer_rule)
    inner_first = rewrite_at_with_step(cp.overlap, cp.position, inner_rule)
    if outer_first is None or inner_first is None:
        raise ValueError("critical-pair boundary does not replay under the declared rules")
    if outer_first.target != cp.outer or inner_first.target != cp.inner:
        raise ValueError("critical-pair replay disagrees with recorded pair")
    normal_outer, tail_outer = normalize(cp.outer, rules)
    normal_inner, tail_inner = normalize(cp.inner, rules)
    if normal_outer != normal_inner:
        raise ValueError("non-joinable critical pair has no confluence filler")
    left = _append_traces(_trace_from_steps(cp.overlap, [outer_first]), tail_outer)
    right = _append_traces(_trace_from_steps(cp.overlap, [inner_first]), tail_inner)
    return CoherenceCell3(
        f"critical_pair_{cp.rule1}_{cp.rule2}_{cp.position}", left, right
    )
