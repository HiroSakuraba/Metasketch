"""Raw relational certificate reconstruction with pointed boundaries.

Phase 5 certificates stored a :class:`RelationalMatch` directly.  Phase 6
removed that stored semantic map and reconstructed it from:

* one concrete fact leaf for each pattern atom;
* one explicit existential witness binder for each hidden pattern variable; and
* conjunction structure joining the leaves.

Phase 7 closes the remaining pointed-query boundary.  A visible variable that
never occurs in a relation atom is semantically free in the query matrix, so no
fact leaf can recover its concrete input value.  A raw certificate may now carry
an explicit :class:`BoundaryAssignmentProof` for exactly those unanchored visible
variables.  Boundary assignments are sequent-context evidence, not matrix
formula nodes: they fix the visible input at which the certificate is checked.

There is still no ``RelationalMatch`` field.  A checked reconstruction procedure
reads fact leaves, existential binders, and boundary-assignment nodes, verifies
all local evidence in one finite model, and recovers the unique typed match.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

from .proofs import (
    AtomFactProof,
    ExistsWitnessProof,
    PatternWitnessProof,
    ProofValidationError,
    QueryProofNode,
    WitnessNormalForm,
    _proof_atoms,
    _proof_binders,
    build_pattern_witness_proof,
    normalize_pattern_witness_proof,
    validate_pattern_witness_proof,
)
from .relational import (
    RelationalMatch,
    RelationalPattern,
    find_relational_matches,
)
from .semantics import FiniteModel, validate_finite_model


class RawCertificateError(ProofValidationError):
    """Raised when a raw certificate cannot be reconstructed uniquely."""


@dataclass(frozen=True)
class BoundaryAssignmentProof:
    """A typed assignment to one unanchored visible query variable.

    The node belongs to the external visible boundary of a pointed certificate,
    not to the existential-conjunctive matrix.  ``variable`` names a canonical
    visible pattern variable.  ``display_label`` is optional presentation data
    and does not affect reconstruction or normal form.
    """

    variable: str
    value: object
    display_label: str = ""


@dataclass(frozen=True)
class RawPatternCertificate:
    """A raw finite proof tree with no stored semantic match.

    ``root`` uses ordinary existential-conjunctive proof nodes.  Atom leaves
    carry concrete tuples, existential nodes carry concrete hidden witnesses,
    conjunction nodes determine only presentation, and ``boundary`` carries
    concrete values only for visible variables absent from every relation atom.
    The certificate becomes trusted only after :func:`reconstruct_raw_match`
    succeeds.
    """

    pattern: RelationalPattern
    model: FiniteModel
    root: QueryProofNode
    boundary: Tuple[BoundaryAssignmentProof, ...] = ()

    def has_explicit_match_field(self) -> bool:
        """A small audit helper used by tests and documentation."""

        return hasattr(self, "match")


@dataclass(frozen=True)
class RawReconstruction:
    """The checked semantic content reconstructed from one raw certificate."""

    certificate: RawPatternCertificate
    match: RelationalMatch
    normal_form: WitnessNormalForm
    evidence: Tuple[Tuple[str, Tuple[Tuple[str, object], ...]], ...]

    def evidence_for(self, variable: str) -> Tuple[Tuple[str, object], ...]:
        return dict(self.evidence)[variable]


@dataclass(frozen=True)
class RawCertificateAdequacyReport:
    """Finite audit of unique reconstruction for one certificate instance."""

    pattern: str
    reconstructed_mapping: Tuple[Tuple[str, object], ...]
    evidence_match_count: int
    boundary_assignment_count: int
    unanchored_visible: Tuple[str, ...]
    build_erase_identity: bool
    normalized_round_trip: bool

    @property
    def valid(self) -> bool:
        return (
            self.evidence_match_count == 1
            and self.boundary_assignment_count == len(self.unanchored_visible)
            and self.build_erase_identity
            and self.normalized_round_trip
        )


def _unanchored_visible_variables(pattern: RelationalPattern) -> Tuple[str, ...]:
    """Return visible variables that never occur in a relation atom."""

    used = {label for atom in pattern.atoms for label in atom.args}
    return tuple(label for label in pattern.visible if label not in used)


def _outer_binder_spine(root: QueryProofNode) -> Tuple[Tuple[ExistsWitnessProof, ...], QueryProofNode]:
    """Split a raw certificate into its outer existential prefix and matrix.

    Every hidden-variable witness must scope over the full conjunction matrix.
    Merely finding binders below a conjunction would accept a different formula,
    such as ``(exists z. A(z)) and B(z)``, when the intended query is
    ``exists z. (A(z) and B(z))``.
    """

    binders = []
    current = root
    while isinstance(current, ExistsWitnessProof):
        binders.append(current)
        current = current.body
    if _proof_binders(current):
        raise RawCertificateError(
            "raw certificate existential binders must form one outer prefix over the full conjunction matrix"
        )
    return tuple(binders), current


def _validate_boundary_assignments(
    certificate: RawPatternCertificate,
) -> Tuple[BoundaryAssignmentProof, ...]:
    """Check the explicit pointed boundary for unanchored visible variables.

    Boundary assignments are required exactly for visible variables with no atom
    occurrence.  Allowing them for anchored variables would create redundant
    evidence and blur the narrow Phase-7 contract.  A future general pointed
    proof format may permit optional assignments for every visible variable.
    """

    pattern = certificate.pattern
    model = certificate.model
    variables = pattern.variable_table()
    expected = _unanchored_visible_variables(pattern)
    assignments = tuple(certificate.boundary)
    names = [assignment.variable for assignment in assignments]

    if len(names) != len(set(names)):
        raise RawCertificateError("boundary assignments must name each variable at most once")
    unexpected = tuple(name for name in names if name not in set(expected))
    if unexpected:
        raise RawCertificateError(
            "boundary assignments are permitted only for unanchored visible variables; "
            f"unexpected={unexpected!r}, required={expected!r}"
        )
    missing = tuple(name for name in expected if name not in set(names))
    if missing:
        raise RawCertificateError(
            "raw certificate needs an explicit boundary assignment for every "
            f"unanchored visible variable; missing={missing!r}"
        )

    for assignment in assignments:
        variable = variables[assignment.variable]
        if assignment.value not in model.carrier(variable.sort):
            raise RawCertificateError(
                f"boundary assignment {assignment.variable!r} uses {assignment.value!r} "
                f"outside carrier {variable.sort}"
            )
    return assignments


def _validate_shape(
    certificate: RawPatternCertificate,
) -> Tuple[Tuple[AtomFactProof, ...], Tuple[ExistsWitnessProof, ...], Tuple[BoundaryAssignmentProof, ...]]:
    """Check finite proof-tree and pointed-boundary shape before reading values."""

    pattern = certificate.pattern
    validate_finite_model(certificate.model, pattern.signature)
    boundary = _validate_boundary_assignments(certificate)

    binders, matrix = _outer_binder_spine(certificate.root)
    atoms = _proof_atoms(matrix)
    expected_indices = set(range(len(pattern.atoms)))
    actual_indices = [atom.atom_index for atom in atoms]
    if len(actual_indices) != len(set(actual_indices)) or set(actual_indices) != expected_indices:
        raise RawCertificateError(
            "raw certificate must contain every pattern atom exactly once, "
            "up to conjunction order and bracketing"
        )

    expected_hidden = set(pattern.hidden)
    actual_hidden = [binder.variable for binder in binders]
    if len(actual_hidden) != len(set(actual_hidden)) or set(actual_hidden) != expected_hidden:
        raise RawCertificateError(
            "raw certificate must bind every hidden pattern variable exactly once"
        )
    return atoms, binders, boundary


def _add_evidence(
    evidence: Dict[str, List[Tuple[str, object]]],
    label: str,
    source: str,
    value: object,
) -> None:
    if label not in evidence:
        raise RawCertificateError(f"proof evidence refers to unknown pattern variable {label!r}")
    evidence[label].append((source, value))


def _evidence_map(certificate: RawPatternCertificate) -> Dict[str, List[Tuple[str, object]]]:
    """Collect values forced by facts, hidden binders, and boundary nodes."""

    pattern = certificate.pattern
    model = certificate.model
    variables = pattern.variable_table()
    atoms, binders, boundary = _validate_shape(certificate)
    evidence: Dict[str, List[Tuple[str, object]]] = {label: [] for label in variables}

    for atom_proof in atoms:
        atom = pattern.atoms[atom_proof.atom_index]
        expected_sorts = pattern.signature.rel_sig(atom.relation)
        if len(atom_proof.values) != len(expected_sorts):
            raise RawCertificateError(
                f"atom {atom_proof.atom_index} for {atom.relation!r} has arity "
                f"{len(atom_proof.values)}, expected {len(expected_sorts)}"
            )
        if atom_proof.values not in model.rels[atom.relation]:
            raise RawCertificateError(
                f"atom fact {atom.relation}{atom_proof.values!r} is absent from the model"
            )
        for label, sort, value in zip(atom.args, expected_sorts, atom_proof.values):
            if value not in model.carrier(sort):
                raise RawCertificateError(
                    f"atom {atom_proof.atom_index} assigns {value!r} outside carrier {sort}"
                )
            _add_evidence(evidence, label, f"atom[{atom_proof.atom_index}]", value)

    for binder in binders:
        variable = variables[binder.variable]
        if binder.witness not in model.carrier(variable.sort):
            raise RawCertificateError(
                f"binder {binder.variable!r} uses {binder.witness!r} outside carrier {variable.sort}"
            )
        _add_evidence(evidence, binder.variable, f"binder[{binder.variable}]", binder.witness)

    for assignment in boundary:
        _add_evidence(
            evidence,
            assignment.variable,
            f"boundary[{assignment.variable}]",
            assignment.value,
        )

    return evidence


def reconstruct_raw_match(certificate: RawPatternCertificate) -> RelationalMatch:
    """Recover the unique relational match forced by a raw certificate.

    Fact leaves fix their occurring variables, existential binders fix hidden
    witnesses, and boundary-assignment nodes fix visible variables that do not
    occur in the matrix.  Validation requires all evidence for a variable to
    agree.  The resulting total mapping is checked by ``RelationalMatch`` against
    the complete finite model.
    """

    pattern = certificate.pattern
    evidence = _evidence_map(certificate)
    assignments: List[Tuple[str, object]] = []
    for variable in pattern.variables:
        entries = evidence[variable.name]
        if not entries:
            raise RawCertificateError(
                f"raw certificate contains no evidence for pattern variable {variable.name!r}"
            )
        value = entries[0][1]
        inconsistent = [(source, other) for source, other in entries if other != value]
        if inconsistent:
            details = ", ".join(f"{source}={other!r}" for source, other in entries)
            raise RawCertificateError(
                f"inconsistent evidence for variable {variable.name!r}: {details}"
            )
        assignments.append((variable.name, value))

    try:
        return RelationalMatch(pattern, certificate.model, tuple(assignments))
    except ValueError as exc:
        raise RawCertificateError(
            f"raw certificate reconstruction does not yield a relational match: {exc}"
        ) from exc


def validate_raw_certificate(certificate: RawPatternCertificate) -> RawReconstruction:
    """Check a raw certificate and return its reconstructed semantic witness."""

    match = reconstruct_raw_match(certificate)
    canonical = build_pattern_witness_proof(match)
    normal_form = normalize_pattern_witness_proof(canonical)
    evidence = _evidence_map(certificate)
    frozen_evidence = tuple(
        (label, tuple(entries))
        for label, entries in ((variable.name, evidence[variable.name]) for variable in certificate.pattern.variables)
    )
    return RawReconstruction(certificate, match, normal_form, frozen_evidence)


def checked_raw_certificate(
    pattern: RelationalPattern,
    model: FiniteModel,
    root: QueryProofNode,
    *,
    boundary: Sequence[BoundaryAssignmentProof] = (),
) -> RawReconstruction:
    """Public checked constructor for a raw certificate with pointed boundary.

    The returned object contains the raw proof tree, declared visible-boundary
    assignments, and its independently reconstructed match.  Trusted callers
    should retain this result rather than a bare ``RawPatternCertificate``.
    """

    return validate_raw_certificate(RawPatternCertificate(pattern, model, root, tuple(boundary)))


def raw_certificate_from_proof(proof: PatternWitnessProof) -> RawPatternCertificate:
    """Erase the stored match field while retaining needed pointed boundaries."""

    validate_pattern_witness_proof(proof)
    pattern = proof.match.pattern
    mapping = proof.match.as_dict()
    boundary = tuple(
        BoundaryAssignmentProof(label, mapping[label], label)
        for label in _unanchored_visible_variables(pattern)
    )
    raw = RawPatternCertificate(pattern, proof.match.model, proof.root, boundary)
    reconstructed = reconstruct_raw_match(raw)
    if reconstructed != proof.match:
        raise RawCertificateError("erasing a checked proof changed its reconstructed witness")
    return raw


def canonical_proof_from_raw(certificate: RawPatternCertificate) -> PatternWitnessProof:
    """Rebuild the fixed-order Phase-5 certificate from a raw proof tree."""

    return build_pattern_witness_proof(reconstruct_raw_match(certificate))


def normalize_raw_certificate(certificate: RawPatternCertificate) -> WitnessNormalForm:
    """Canonical witness normal form reconstructed from raw syntax."""

    return normalize_pattern_witness_proof(canonical_proof_from_raw(certificate))


def _match_agrees_with_raw_evidence(match: RelationalMatch, certificate: RawPatternCertificate) -> bool:
    """Whether an existing semantic match realizes all raw certificate evidence."""

    if match.pattern != certificate.pattern or match.model is not certificate.model:
        return False
    mapping = match.as_dict()
    evidence = _evidence_map(certificate)
    return all(
        all(mapping[label] == value for _, value in entries)
        for label, entries in evidence.items()
    )


def matches_realizing_raw_certificate(certificate: RawPatternCertificate) -> Tuple[RelationalMatch, ...]:
    """Enumerate finite semantic matches that realize all raw evidence."""

    _validate_shape(certificate)
    return tuple(
        match
        for match in find_relational_matches(certificate.pattern, certificate.model)
        if _match_agrees_with_raw_evidence(match, certificate)
    )


def audit_raw_certificate_reconstruction(certificate: RawPatternCertificate) -> RawCertificateAdequacyReport:
    """Finite audit of unique reconstruction for one pointed raw certificate."""

    reconstructed = validate_raw_certificate(certificate)
    realizing = matches_realizing_raw_certificate(certificate)
    canonical = canonical_proof_from_raw(certificate)
    round_trip_raw = raw_certificate_from_proof(canonical)
    unanchored = _unanchored_visible_variables(certificate.pattern)
    return RawCertificateAdequacyReport(
        pattern=certificate.pattern.name,
        reconstructed_mapping=reconstructed.match.mapping,
        evidence_match_count=len(realizing),
        boundary_assignment_count=len(certificate.boundary),
        unanchored_visible=unanchored,
        build_erase_identity=(len(realizing) == 1 and realizing[0] == reconstructed.match),
        normalized_round_trip=(
            normalize_raw_certificate(round_trip_raw) == reconstructed.normal_form
        ),
    )


__all__ = [
    "RawCertificateError",
    "BoundaryAssignmentProof",
    "RawPatternCertificate",
    "RawReconstruction",
    "RawCertificateAdequacyReport",
    "reconstruct_raw_match",
    "validate_raw_certificate",
    "checked_raw_certificate",
    "raw_certificate_from_proof",
    "canonical_proof_from_raw",
    "normalize_raw_certificate",
    "matches_realizing_raw_certificate",
    "audit_raw_certificate_reconstruction",
]
