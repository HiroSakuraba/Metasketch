"""Tests for the minimal Program E audit on real proof certificates."""

from __future__ import annotations

from .proofs import build_pattern_witness_proof
from .reflection_audit import audit_reflective_fragment
from .relational import find_relational_matches
from .tests import Report
from .tests_phase4 import commuter_friend_pattern, source_model


def test_real_proof_object_audit(rep: Report) -> None:
    match = find_relational_matches(commuter_friend_pattern(), source_model())[0]
    proof = build_pattern_witness_proof(match)
    audit = audit_reflective_fragment(proof)
    rep.check("Program E audit quotes a real witness proof one level higher", audit.quote_level_raising and audit.code_level == audit.source_level + 1)
    rep.check("Program E audit separates syntactic higher-level checking from semantic truth", audit.higher_level_checker_permitted and audit.checker_is_syntactic_not_truth)
    rep.check("Program E audit does not misclassify resource exhaustion as semantic divergence", audit.bounded_evaluator_status == "resource_exhausted" and not audit.bounded_evaluator_is_semantic_partiality)
    rep.check("Program E audit identifies absent universal evaluation and the missing point-surjectivity bridge", audit.safe_by_design and not audit.universal_evaluator_present and "not derivable" in audit.weak_point_surjectivity_bridge)
    rep.check("Program E audit records stratification and representation incompleteness as explicit escape routes", set(audit.escape_routes) >= {"stratification", "representation incompleteness"})


def run() -> int:
    rep = Report()
    test_real_proof_object_audit(rep)
    print("=" * 72)
    print("Metasketch-0 Program E reflection-audit test report")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
