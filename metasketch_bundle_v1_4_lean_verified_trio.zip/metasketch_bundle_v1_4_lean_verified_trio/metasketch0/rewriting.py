"""
Metasketch-0 Phase 2: a small first-order term rewriting engine.

This is the 2-cell / 3-cell layer of the design. Terms are 1-cells (structural
diagrams as trees), rewrite rules are 2-cells, and critical pairs between rules
are where 3-cells (coherence cells) are forced. The engine provides:

  - terms with metavariables, ground atoms, and function symbols;
  - one-way matching (for applying a rule) and unification (for overlaps);
  - subterm positions, replacement, and rule application at a position;
  - normalization under a chosen redex-selection order; and
  - critical-pair enumeration a la Knuth-Bendix / Squier.

Term encoding (tuples, hashable and immutable):
  ("var", name)          a metavariable (matches anything)
  ("atom", name)         a ground atom (a distinct leaf constant)
  (symbol, arg1, ...)    a function application; symbol is any string except
                         "var" or "atom"; a nullary symbol is (symbol,).

No em dashes anywhere, per project convention.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Iterable

Term = tuple


# ---------------------------------------------------------------------------
# constructors and predicates
# ---------------------------------------------------------------------------

def Var(name: str) -> Term:
    return ("var", name)


def Atom(name: str) -> Term:
    return ("atom", name)


def App(symbol: str, *args: Term) -> Term:
    assert symbol not in ("var", "atom"), "reserved head"
    return (symbol,) + tuple(args)


def is_var(t: Term) -> bool:
    return t[0] == "var"


def is_atom(t: Term) -> bool:
    return t[0] == "atom"


def is_app(t: Term) -> bool:
    return t[0] not in ("var", "atom")


def args_of(t: Term) -> Tuple[Term, ...]:
    return t[1:]


def vars_of(t: Term) -> set:
    if is_var(t):
        return {t[1]}
    if is_atom(t):
        return set()
    out = set()
    for a in args_of(t):
        out |= vars_of(a)
    return out


def pretty(t: Term) -> str:
    if is_var(t):
        return t[1]
    if is_atom(t):
        return t[1]
    if len(t) == 1:
        return t[0]
    return f"{t[0]}(" + ", ".join(pretty(a) for a in args_of(t)) + ")"


# ---------------------------------------------------------------------------
# substitutions
# ---------------------------------------------------------------------------

Subst = Dict[str, Term]


def apply_subst(t: Term, s: Subst) -> Term:
    """
    Simultaneous single-pass substitution. A variable is replaced by its image
    in s, and the image is NOT re-processed. This is the correct semantics for
    applying a match or an idempotent unifier, and it avoids capture loops when
    an object term happens to share a variable name with a rule pattern.
    """
    if is_var(t):
        return s.get(t[1], t)
    if is_atom(t):
        return t
    return (t[0],) + tuple(apply_subst(a, s) for a in args_of(t))


def _resolve(t: Term, s: Subst) -> Term:
    """Fully resolve a term through a (possibly chained) substitution. Used only
    to make a unifier idempotent. Terminates because unify keeps s acyclic."""
    if is_var(t):
        return _resolve(s[t[1]], s) if t[1] in s else t
    if is_atom(t):
        return t
    return (t[0],) + tuple(_resolve(a, s) for a in args_of(t))


def rename_apart(t: Term, suffix: str) -> Term:
    if is_var(t):
        return ("var", t[1] + suffix)
    if is_atom(t):
        return t
    return (t[0],) + tuple(rename_apart(a, suffix) for a in args_of(t))


# ---------------------------------------------------------------------------
# matching (one-way: pattern has variables, subject is matched against it)
# ---------------------------------------------------------------------------

def match(pattern: Term, subject: Term, s: Optional[Subst] = None) -> Optional[Subst]:
    if s is None:
        s = {}
    if is_var(pattern):
        name = pattern[1]
        if name in s:
            return s if s[name] == subject else None
        s = dict(s)
        s[name] = subject
        return s
    if is_atom(pattern):
        return s if pattern == subject else None
    # pattern is an application
    if not is_app(subject) or subject[0] != pattern[0] or len(subject) != len(pattern):
        return None
    for p, q in zip(args_of(pattern), args_of(subject)):
        s = match(p, q, s)
        if s is None:
            return None
    return s


# ---------------------------------------------------------------------------
# unification (two-way, with occurs check)
# ---------------------------------------------------------------------------

def _walk(t: Term, s: Subst) -> Term:
    while is_var(t) and t[1] in s:
        t = s[t[1]]
    return t


def _occurs(name: str, t: Term, s: Subst) -> bool:
    t = _walk(t, s)
    if is_var(t):
        return t[1] == name
    if is_atom(t):
        return False
    return any(_occurs(name, a, s) for a in args_of(t))


def unify(a: Term, b: Term) -> Optional[Subst]:
    s: Subst = {}
    stack = [(a, b)]
    while stack:
        x, y = stack.pop()
        x = _walk(x, s)
        y = _walk(y, s)
        if x == y:
            continue
        if is_var(x):
            if _occurs(x[1], y, s):
                return None
            s[x[1]] = y
        elif is_var(y):
            if _occurs(y[1], x, s):
                return None
            s[y[1]] = x
        elif is_atom(x) or is_atom(y):
            return None  # distinct atoms, or atom vs application
        else:
            if x[0] != y[0] or len(x) != len(y):
                return None
            for p, q in zip(args_of(x), args_of(y)):
                stack.append((p, q))
    # resolve to an idempotent substitution
    return {k: _resolve(v, s) for k, v in s.items()}


# ---------------------------------------------------------------------------
# positions
# ---------------------------------------------------------------------------

Pos = Tuple[int, ...]


def subterm_at(t: Term, pos: Pos) -> Term:
    for i in pos:
        t = t[1 + i]
    return t


def replace_at(t: Term, pos: Pos, new: Term) -> Term:
    if not pos:
        return new
    i = pos[0]
    child = replace_at(t[1 + i], pos[1:], new)
    return t[: 1 + i] + (child,) + t[2 + i:]


def all_positions(t: Term, prefix: Pos = ()) -> List[Pos]:
    res = [prefix]
    if is_app(t):
        for i in range(len(t) - 1):
            res += all_positions(t[1 + i], prefix + (i,))
    return res


def nonvar_positions(t: Term, prefix: Pos = ()) -> List[Pos]:
    res: List[Pos] = []
    if not is_var(t):
        res.append(prefix)
    if is_app(t):
        for i in range(len(t) - 1):
            res += nonvar_positions(t[1 + i], prefix + (i,))
    return res


# ---------------------------------------------------------------------------
# rules and rewriting
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Rule:
    name: str
    lhs: Term
    rhs: Term


@dataclass(frozen=True)
class RewriteStep:
    """One validated directed rewrite in the structural presentation."""

    source: Term
    position: Pos
    rule_name: str
    target: Term


@dataclass(frozen=True)
class RewriteTrace:
    """A composable sequence of rewrite steps with fixed source and target."""

    source: Term
    steps: Tuple[RewriteStep, ...]

    @property
    def target(self) -> Term:
        return self.steps[-1].target if self.steps else self.source

    def __len__(self) -> int:
        return len(self.steps)

    def is_composable(self) -> bool:
        cur = self.source
        for step in self.steps:
            if step.source != cur:
                return False
            cur = step.target
        return True


def rewrite_at_with_step(t: Term, pos: Pos, rule: Rule) -> Optional[RewriteStep]:
    s = match(rule.lhs, subterm_at(t, pos))
    if s is None:
        return None
    target = replace_at(t, pos, apply_subst(rule.rhs, s))
    return RewriteStep(t, pos, rule.name, target)


def rewrite_at(t: Term, pos: Pos, rule: Rule) -> Optional[Term]:
    """Compatibility wrapper returning only the target term."""
    step = rewrite_at_with_step(t, pos, rule)
    return None if step is None else step.target


def validate_rewrite_step(step: RewriteStep, rules: Iterable[Rule]) -> bool:
    """Check that a stored step is an actual application of its named rule."""
    rule_by_name = {rule.name: rule for rule in rules}
    rule = rule_by_name.get(step.rule_name)
    if rule is None:
        return False
    return rewrite_at(step.source, step.position, rule) == step.target


def validate_rewrite_trace(trace: RewriteTrace, rules: Iterable[Rule]) -> bool:
    return trace.is_composable() and all(
        validate_rewrite_step(step, rules) for step in trace.steps
    )


def redexes(t: Term, rules: Iterable[Rule]) -> List[Tuple[Pos, Rule]]:
    out = []
    for pos in all_positions(t):
        sub = subterm_at(t, pos)
        for rule in rules:
            if match(rule.lhs, sub) is not None:
                out.append((pos, rule))
    return out


def _order_outermost_leftmost(redex_list):
    return sorted(redex_list, key=lambda pr: (len(pr[0]), pr[0], pr[1].name))


def _order_innermost_rightmost(redex_list):
    return sorted(redex_list, key=lambda pr: (-len(pr[0]),
                                              tuple(-i for i in pr[0]),
                                              pr[1].name))


def normalize(t: Term, rules: List[Rule], order=_order_outermost_leftmost,
              cap: int = 100000):
    """Rewrite until no redex remains. Returns (normal_form, RewriteTrace)."""
    source = t
    steps: List[RewriteStep] = []
    count = 0
    while True:
        rl = redexes(t, rules)
        if not rl:
            return t, RewriteTrace(source, tuple(steps))
        pos, rule = order(rl)[0]
        step = rewrite_at_with_step(t, pos, rule)
        if step is None:
            raise RuntimeError(f"selected redex {rule.name}@{pos} did not rewrite")
        t = step.target
        steps.append(step)
        count += 1
        if count > cap:
            raise RuntimeError(f"normalize exceeded {cap} steps; resource limit reached")


# ---------------------------------------------------------------------------
# critical pairs
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CriticalPair:
    overlap: Term            # the minimal term where two rules both apply
    outer: Term              # result of applying rule1 at the root
    inner: Term              # result of applying rule2 at the overlap position
    rule1: str
    rule2: str
    position: Pos            # position in rule1.lhs where rule2 overlaps


def critical_pairs(rules: List[Rule]) -> List[CriticalPair]:
    cps: List[CriticalPair] = []
    for r1 in rules:
        for r2 in rules:
            r2r = Rule(r2.name, rename_apart(r2.lhs, "#2"), rename_apart(r2.rhs, "#2"))
            for pos in nonvar_positions(r1.lhs):
                # exclude the trivial root overlap of a rule with (a copy of) itself
                if pos == () and r1.name == r2.name:
                    continue
                mu = unify(subterm_at(r1.lhs, pos), r2r.lhs)
                if mu is None:
                    continue
                overlap = apply_subst(r1.lhs, mu)
                outer = apply_subst(r1.rhs, mu)
                inner = replace_at(overlap, pos, apply_subst(r2r.rhs, mu))
                cps.append(CriticalPair(overlap, outer, inner, r1.name, r2.name, pos))
    return cps


def joinable(cp: CriticalPair, rules: List[Rule]) -> Tuple[bool, Term, Term]:
    nf_outer, _ = normalize(cp.outer, rules)
    nf_inner, _ = normalize(cp.inner, rules)
    return (nf_outer == nf_inner), nf_outer, nf_inner
