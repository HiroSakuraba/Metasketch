"""Metasketch-0 Phase 4 tests: witness-normalized relational tiles.

Phase 4 generalizes Phase 3 graph patterns to finite relation-only signatures and
adds explicit proof terms.  It tests, by exhaustive finite computation:

  - typed relational pattern compilation;
  - correspondence between existential-conjunctive queries and witness maps;
  - proof normalization modulo alpha-renaming and conjunction order/bracketing;
  - finite universal tile evidence by enumerating all source witnesses;
  - direct versus sequential witness transport as an explicit 3-cell; and
  - concrete diagnostics for relation maps that cannot support a transport proof.

The phase remains finite.  It does not claim a general completeness theorem for
all regular logic or all relational structures.
"""

from __future__ import annotations

from .proofs import (
    AndIntroProof,
    FailedRawTransportAttempt,
    PatternWitnessProof,
    TruthProof,
    build_pattern_witness_proof,
    make_finite_relational_tile_proof,
    make_transport_coherence_cell,
    make_witness_transport_proof,
    normalize_pattern_witness_proof,
    normalize_transport_proof,
    validate_pattern_witness_proof,
)
from .relational import (
    RawRelationalMap,
    RelationalAtom,
    RelationalHomomorphism,
    RelationalPattern,
    checked_relational_homomorphism,
    compile_relational_query,
    find_relational_matches,
)
from .semantics import FiniteModel, extension, validate_finite_model
from .syntax import Signature, Sort, Var, validate_pred
from .tests import Report


PERSON = Sort("Person")
CITY = Sort("City")

REL_SIGNATURE = Signature(
    sorts=(PERSON, CITY),
    ops=(),
    rels=(
        ("Knows", (PERSON, PERSON)),
        ("Lives", (PERSON, CITY)),
        ("Road", (CITY, CITY)),
        ("Open", (CITY,)),
    ),
)


def commuter_friend_pattern() -> RelationalPattern:
    """Two people connected by knowledge and a city-to-city route."""

    s = Var("s", PERSON)
    t = Var("t", PERSON)
    a = Var("a", CITY)
    b = Var("b", CITY)
    return RelationalPattern(
        "commuter_friend",
        REL_SIGNATURE,
        (s, t, a, b),
        ("s", "t"),
        (
            RelationalAtom("Knows", ("s", "t")),
            RelationalAtom("Lives", ("s", "a")),
            RelationalAtom("Lives", ("t", "b")),
            RelationalAtom("Road", ("a", "b")),
        ),
    )


def open_route_pattern() -> RelationalPattern:
    """A one-visible-variable pattern used to exercise a unary relation atom."""

    p = Var("p", PERSON)
    c = Var("c", CITY)
    return RelationalPattern(
        "open_route",
        REL_SIGNATURE,
        (p, c),
        ("p",),
        (
            RelationalAtom("Lives", ("p", "c")),
            RelationalAtom("Open", ("c",)),
        ),
    )


def source_model() -> FiniteModel:
    return FiniteModel(
        carriers={PERSON: ("u", "v", "w"), CITY: (0, 1, 2)},
        ops={},
        rels={
            "Knows": frozenset({("u", "v"), ("v", "w")}),
            "Lives": frozenset({("u", 0), ("v", 1), ("w", 2)}),
            "Road": frozenset({(0, 1), (1, 2), (0, 2)}),
            "Open": frozenset({(1,), (2,)}),
        },
    )


def middle_model() -> FiniteModel:
    return FiniteModel(
        carriers={PERSON: ("A", "B", "C"), CITY: ("x", "y", "z")},
        ops={},
        rels={
            "Knows": frozenset({("A", "B"), ("B", "C")}),
            "Lives": frozenset({("A", "x"), ("B", "y"), ("C", "z")}),
            "Road": frozenset({("x", "y"), ("y", "z"), ("x", "z")}),
            "Open": frozenset({("y",), ("z",)}),
        },
    )


def target_model() -> FiniteModel:
    # B and C merge; y and z merge.  Homomorphisms and witness maps need not be injective.
    return FiniteModel(
        carriers={PERSON: ("P", "Q"), CITY: ("L", "M")},
        ops={},
        rels={
            "Knows": frozenset({("P", "Q"), ("Q", "Q")}),
            "Lives": frozenset({("P", "L"), ("Q", "M")}),
            "Road": frozenset({("L", "M"), ("M", "M")}),
            "Open": frozenset({("M",)}),
        },
    )


def hom_chain():
    source, middle, target = source_model(), middle_model(), target_model()
    first = checked_relational_homomorphism(
        name="h",
        signature=REL_SIGNATURE,
        source=source,
        target=middle,
        mapping={
            PERSON: {"u": "A", "v": "B", "w": "C"},
            CITY: {0: "x", 1: "y", 2: "z"},
        },
    )
    second = checked_relational_homomorphism(
        name="k",
        signature=REL_SIGNATURE,
        source=middle,
        target=target,
        mapping={
            PERSON: {"A": "P", "B": "Q", "C": "Q"},
            CITY: {"x": "L", "y": "M", "z": "M"},
        },
    )
    return source, middle, target, first, second


def compiled(pattern: RelationalPattern, prefix: str):
    visible = {
        label: Var(f"{prefix}_{label}", pattern.variable_table()[label].sort)
        for label in pattern.visible
    }
    return compile_relational_query(pattern, visible_vars=visible, witness_prefix=f"{prefix}_w")


def test_relational_signature_and_pattern_compilation(rep: Report) -> None:
    source = source_model()
    pattern = commuter_friend_pattern()
    query = compiled(pattern, "q")
    static_ok = True
    try:
        validate_finite_model(source, REL_SIGNATURE)
        validate_pred(query.predicate, REL_SIGNATURE, query.context)
    except Exception as exc:  # pragma: no cover - diagnostic path
        static_ok = False
        detail = str(exc)
    else:
        detail = ""
    rep.check("Phase4 relation-only signature and multi-sort pattern pass static checks", static_ok, detail)

    query_assignments = {
        tuple(row)
        for row in extension(query.predicate, query.context, source)
    }
    witness_assignments = {
        tuple(match.as_dict()[label] for label in pattern.visible)
        for match in find_relational_matches(pattern, source)
    }
    rep.check(
        "Phase4 compiled multi-sort conjunctive query agrees with exhaustive witness enumeration",
        query_assignments == witness_assignments,
        f"query={query_assignments}, witnesses={witness_assignments}",
    )


def test_witness_proof_normalization(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    match = find_relational_matches(pattern, source_model())[0]
    canonical = build_pattern_witness_proof(match)
    reordered = build_pattern_witness_proof(
        match,
        atom_order=(3, 1, 2, 0),
        binder_order=("b", "a"),
        binder_display_names={"a": "city_left_alpha", "b": "city_right_alpha"},
    )
    same_normal_form = normalize_pattern_witness_proof(canonical) == normalize_pattern_witness_proof(reordered)
    syntactically_distinct = canonical.root != reordered.root
    rep.check("Phase4 two syntactically distinct proof trees normalize to one witness form", syntactically_distinct and same_normal_form)

    bad = PatternWitnessProof(match, TruthProof())
    rejected = False
    detail = ""
    try:
        validate_pattern_witness_proof(bad)
    except Exception as exc:
        rejected = True
        detail = str(exc)
    rep.check(
        "Phase4 a proposed witness proof missing atom evidence is rejected with a concrete diagnosis",
        rejected and "every pattern atom" in detail,
        detail,
    )


def test_finite_tile_proof_and_rejection(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    source, _, _, first, _ = hom_chain()
    finite_tile = make_finite_relational_tile_proof(pattern, first)
    expected_count = len(find_relational_matches(pattern, source))
    rep.check(
        "Phase4 finite relational tile proof covers every source witness",
        finite_tile.validate() and len(finite_tile.instances) == expected_count,
        f"instances={len(finite_tile.instances)}, expected={expected_count}",
    )

    # This raw map is total and sort-respecting but maps Knows(u,v) to Knows(P,P),
    # which is absent.  It cannot support a relational transport derivation.
    _, _, target, _, _ = hom_chain()
    bad_raw = RawRelationalMap(
        "bad",
        REL_SIGNATURE,
        source,
        target,
        (
            (PERSON, (("u", "P"), ("v", "P"), ("w", "Q"))),
            (CITY, ((0, "L"), (1, "M"), (2, "M"))),
        ),
    )
    proposed = build_pattern_witness_proof(find_relational_matches(pattern, source)[0])
    attempt = FailedRawTransportAttempt(proposed, bad_raw)
    rejected = False
    try:
        RelationalHomomorphism(bad_raw)
    except ValueError:
        rejected = True
    rep.check(
        "Phase4 a non-homomorphic structural map is rejected before witness transport",
        rejected and "Knows" in attempt.diagnostic(),
        attempt.diagnostic(),
    )


def test_transport_and_coherence_normalization(rep: Report) -> None:
    pattern = commuter_friend_pattern()
    source, _, _, first, second = hom_chain()
    match = find_relational_matches(pattern, source)[0]
    proof = build_pattern_witness_proof(match, atom_order=(2, 0, 3, 1), binder_order=("a", "b"))
    cell = make_transport_coherence_cell(proof, first, second)
    direct_nf = normalize_transport_proof(cell.direct)
    sequential_nf = normalize_transport_proof(cell.sequential)
    rep.check("Phase4 direct and sequential relational witness transport have a validated 3-cell", cell.validate())
    rep.check("Phase4 direct and sequential transport normalize to the same net witness trace", direct_nf == sequential_nf)
    rep.check(
        "Phase4 normalized transport records the noninjective target witness canonically",
        dict(direct_nf.target.hidden) == {"a": "L", "b": "M"},
        f"target hidden witnesses={direct_nf.target.hidden}",
    )


def test_unary_relation_and_empty_conjunction_boundary(rep: Report) -> None:
    pattern = open_route_pattern()
    source = source_model()
    query = compiled(pattern, "open")
    query_values = set(extension(query.predicate, query.context, source))
    witness_values = {
        tuple(match.as_dict()[label] for label in pattern.visible)
        for match in find_relational_matches(pattern, source)
    }
    rep.check("Phase4 unary relation atoms compile and enumerate correctly", query_values == witness_values)

    # A zero-atom / zero-hidden pattern is the regular-logic truth object.
    p = Var("p", PERSON)
    truth_pattern = RelationalPattern("truth_pattern", REL_SIGNATURE, (p,), ("p",), ())
    truth_query = compiled(truth_pattern, "truth")
    all_people = set(extension(truth_query.predicate, truth_query.context, source))
    rep.check("Phase4 empty conjunction compiles to truth over every visible assignment", all_people == {("u",), ("v",), ("w",)})


def run() -> int:
    rep = Report()
    test_relational_signature_and_pattern_compilation(rep)
    test_witness_proof_normalization(rep)
    test_finite_tile_proof_and_rejection(rep)
    test_transport_and_coherence_normalization(rep)
    test_unary_relation_and_empty_conjunction_boundary(rep)

    print("=" * 72)
    print("Metasketch-0 Phase 4 test report (witness-normalized relational tiles)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
