"""Tests for the reusable coherence-lifting schema."""

from __future__ import annotations

from dataclasses import replace

from . import tile_coherence as tc
from .coherence_lift import WitnessTransportLiftingAdapter, monoid_reindex_lifting_schema
from .proofs import build_pattern_witness_proof
from .relational import find_relational_matches
from .tests import Report
from .tests_phase4 import commuter_friend_pattern, hom_chain, source_model


def test_monoid_schema_lift(rep: Report) -> None:
    schema = monoid_reindex_lifting_schema()
    diagram = tc.pentagon_tile_diagram()
    predicate = tc.pentagon_tile_predicate()
    cell = schema.lift(diagram, predicate)
    legacy = tc.CoherenceSquare(diagram, predicate).cell
    rep.check("Lift schema constructs a validated monoid reindexing coherence 3-cell", cell.validate())
    rep.check(
        "Lift schema agrees with the Phase2.5 monoid cell on transported boundaries and normal form",
        cell.transport_before == legacy.transport_before
        and cell.transport_after == legacy.transport_after
        and cell.common_normal_form == legacy.common_normal_form,
    )


def test_lift_schema_rejects_forged_boundary(rep: Report) -> None:
    schema = monoid_reindex_lifting_schema()
    cell = schema.lift(tc.pentagon_tile_diagram(), tc.pentagon_tile_predicate())
    forged = replace(cell, structural_target=cell.structural_source)
    rep.check("Lift schema rejects a forged structural target in a purported 3-cell", not forged.validate())


def test_relational_adapter(rep: Report) -> None:
    source, _, _, first, second = hom_chain()
    match = find_relational_matches(commuter_friend_pattern(), source)[0]
    proof = build_pattern_witness_proof(match)
    adapter = WitnessTransportLiftingAdapter()
    cell = adapter.lift(proof, first, second)
    rep.check("Lift adapter validates relational direct-versus-sequential witness transport", adapter.validate(cell) and cell.validate())


def run() -> int:
    rep = Report()
    test_monoid_schema_lift(rep)
    test_lift_schema_rejects_forged_boundary(rep)
    test_relational_adapter(rep)
    print("=" * 72)
    print("Metasketch-0 coherence-lifting schema test report")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
