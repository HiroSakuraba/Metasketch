"""Phase 12: F3 reflection-interface type-safety audit.

F3 is deliberately narrower than a Tarski or Lawvere theorem.  It establishes
three facts about the declared Metasketch interface:

1. supported quote/check/eval/satisfaction interfaces are strictly stratified;
2. the public safe constructors cannot build same-level total, representation-
   complete truth; and
3. finite same-level tables fail representation completeness by a diagonal
   witness, while cross-level predicate codes can represent every predicate of
   a lower finite domain.

The Lean counterpart formalizes the first and third statements at the interface
level.  Python provides finite executable cross-checks and API regression tests.
"""

from __future__ import annotations

from . import reflection as refl
from .api import (
    safe_check_interface,
    safe_eval_interface,
    safe_lower_truth_interface,
    safe_quote_interface,
    safe_satisfaction_interface,
    safe_same_level_incomplete_truth_interface,
    safe_same_level_partial_truth_interface,
)
from .tests import Report


def test_safe_interface_constructors(rep: Report) -> None:
    quote = safe_quote_interface(3)
    check = safe_check_interface(3)
    ev = safe_eval_interface(3)
    sat = safe_satisfaction_interface(3)
    lower_truth = safe_lower_truth_interface(3)

    all_strict = all(i.target_level == i.source_level + 1 for i in (quote, check, ev, sat, lower_truth))
    rep.check(
        "Phase12 safe public interfaces are strictly level-raising where required",
        all_strict,
        str([refl.reflection_interface_summary(i) for i in (quote, check, ev, sat, lower_truth)]),
    )

    partial = safe_same_level_partial_truth_interface(3)
    incomplete = safe_same_level_incomplete_truth_interface(3)
    rep.check(
        "Phase12 same-level truth-shaped interfaces explicitly surrender totality or completeness",
        (not partial.total and partial.representation_complete)
        and (incomplete.total and not incomplete.representation_complete),
        f"partial={refl.reflection_interface_summary(partial)}, incomplete={refl.reflection_interface_summary(incomplete)}",
    )


def test_forbidden_interface_cannot_cross_checked_boundary(rep: Report) -> None:
    forbidden = refl.InterfaceSpec("truth", 2, 2, total=True, representation_complete=True)
    rejected = not refl.membrane_check(forbidden).accepted
    raised = False
    try:
        refl.SafeReflectionInterface(forbidden)
    except ValueError:
        raised = True
    rep.check(
        "Phase12 checked boundary rejects same-level total complete truth",
        rejected and raised,
        refl.membrane_check(forbidden).reason,
    )


def test_typed_cross_level_predicate_evaluation(rep: Report) -> None:
    code = refl.PredicateCode(argument_level=4, bits=(0, 1, 1, 0))
    legal = refl.eval_predicate_code(code, refl.LevelElement(level=4, value=1))
    illegal_rejected = False
    try:
        refl.eval_predicate_code(code, code)  # type: ignore[arg-type]
    except TypeError:
        illegal_rejected = True
    rep.check(
        "Phase12 declared predicate evaluator accepts lower-level arguments and rejects code self-application",
        legal == 1 and illegal_rejected,
        f"legal={legal}, self_application_rejected={illegal_rejected}",
    )


def test_diagonal_and_stratified_completeness(rep: Report) -> None:
    finite_ok = all(
        refl.finite_same_level_representation_is_incomplete(n, exhaustive=True)[0]
        for n in range(0, 4)
    )
    stratified_ok = all(refl.stratified_escape(n)[0] for n in range(0, 5))
    rep.check(
        "Phase12 finite diagonal rejects same-level completeness while typed cross-level codes cover lower predicates",
        finite_ok and stratified_ok,
        f"finite_levels=0..3={finite_ok}, stratified_levels=0..4={stratified_ok}",
    )



def test_f3_lean_source_contract(rep: Report) -> None:
    """The handoff source must expose the stated F3 theorem boundary honestly."""
    from pathlib import Path
    import re

    root = Path(__file__).resolve().parent.parent
    source = root / "formal" / "lean" / "ReflectionSafety.lean"
    verify = root / "formal" / "lean" / "verify.sh"
    text = source.read_text(encoding="utf-8")
    required = (
        "safeInterface_no_sameLevel_total_complete_truth",
        "sameLevel_not_representationComplete",
        "crossLevel_representation_complete",
        "evalPredicate_correct",
    )
    placeholders = (
        r"(?m)^\s*sorry\s*$",
        r"(?m)^\s*admit\s*$",
        r"(?m)^\s*axiom\s+",
        r"(?m)^\s*unsafe\s+",
        r"(?m)^\s*partial\s+def\s+",
    )
    missing = [name for name in required if name not in text]
    forbidden = [pattern for pattern in placeholders if re.search(pattern, text)]
    wired = "ReflectionSafety.lean" in verify.read_text(encoding="utf-8")
    rep.check(
        "Phase12 F3 Lean source exposes the safety theorems without placeholders",
        not missing and not forbidden and wired,
        f"missing={missing}, forbidden={forbidden}, wired_into_verify={wired}",
    )

def run() -> int:
    rep = Report()
    test_safe_interface_constructors(rep)
    test_forbidden_interface_cannot_cross_checked_boundary(rep)
    test_typed_cross_level_predicate_evaluation(rep)
    test_diagonal_and_stratified_completeness(rep)
    test_f3_lean_source_contract(rep)
    print("=" * 72)
    print("Metasketch Phase 12 test report (F3 reflection-interface safety)")
    print("=" * 72)
    print(rep.render())
    return 1 if rep.failures() else 0


if __name__ == "__main__":
    raise SystemExit(run())
