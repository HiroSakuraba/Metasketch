"""First-class coherence witnesses for graph-pattern query transport.

A pattern match is a concrete existential witness.  If a match is transported
through G -> H -> K, direct transport along the composite and sequential
transport give the same labelled witness map.  The equality is stored as an
explicit Phase 3 higher cell, rather than inferred only from a test assertion.
"""

from __future__ import annotations
from dataclasses import dataclass

from .queries import (
    GraphHomomorphism,
    PatternMatch,
    compose_graph_homomorphisms,
    transport_match,
)


@dataclass(frozen=True)
class QueryTransportCoherenceCell3:
    """A witness-level 3-cell for direct versus sequential query transport."""

    initial_match: PatternMatch
    first: GraphHomomorphism
    second: GraphHomomorphism
    composite: GraphHomomorphism
    sequential: PatternMatch
    direct: PatternMatch

    @property
    def source(self) -> PatternMatch:
        return self.initial_match

    @property
    def target(self) -> PatternMatch:
        return self.direct

    def validate(self) -> bool:
        try:
            expected_composite = compose_graph_homomorphisms(self.second, self.first)
            expected_sequential = transport_match(transport_match(self.initial_match, self.first), self.second)
            expected_direct = transport_match(self.initial_match, self.composite)
        except ValueError:
            return False
        return (
            expected_composite == self.composite
            and expected_sequential == self.sequential
            and expected_direct == self.direct
            and self.sequential == self.direct
        )


def make_query_transport_coherence_cell(
    match: PatternMatch,
    first: GraphHomomorphism,
    second: GraphHomomorphism,
) -> QueryTransportCoherenceCell3:
    """Build the canonical direct-versus-sequential witness transport cell."""

    composite = compose_graph_homomorphisms(second, first)
    sequential = transport_match(transport_match(match, first), second)
    direct = transport_match(match, composite)
    cell = QueryTransportCoherenceCell3(match, first, second, composite, sequential, direct)
    if not cell.validate():
        raise RuntimeError("internal error: constructed query-transport cell did not validate")
    return cell
