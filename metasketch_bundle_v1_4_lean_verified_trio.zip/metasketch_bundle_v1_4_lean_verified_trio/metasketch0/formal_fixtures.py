"""Portable JSON fixtures for the Metasketch finite-core formalization target.

These fixtures are not proofs.  They provide a deterministic, language-neutral
corpus that an eventual Lean, Coq, Agda, or Isabelle port can consume as concrete
regression oracles while its general theorems are formalized independently.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import json

from .certified_core import MonoidNormalizationCertificate, PointedReconstructionCertificate
from .rewriting import RewriteStep, RewriteTrace, Term


def term_to_json(term: Term) -> Mapping[str, Any]:
    if term[0] == "atom":
        return {"tag": "atom", "name": term[1]}
    if term[0] == "var":
        return {"tag": "var", "name": term[1]}
    return {"tag": "app", "symbol": term[0], "args": [term_to_json(arg) for arg in term[1:]]}


def monoid_certificate_to_json(certificate: MonoidNormalizationCertificate) -> Mapping[str, Any]:
    certificate.require_valid()
    return {
        "kind": "monoid_normalization",
        "source": term_to_json(certificate.source),
        "word": [term_to_json(item) for item in certificate.word],
        "normal_form": term_to_json(certificate.normal_form),
        "trace": [
            {
                "rule": step.rule_name,
                "position": list(step.position),
                "source": term_to_json(step.source),
                "target": term_to_json(step.target),
            }
            for step in certificate.trace.steps
        ],
        "interpretation_pairs": [list(pair) for pair in certificate.interpretation_pairs],
    }


def pointed_certificate_to_json(certificate: PointedReconstructionCertificate) -> Mapping[str, Any]:
    certificate.require_valid()
    raw = certificate.raw
    return {
        "kind": "pointed_raw_reconstruction",
        "pattern": raw.pattern.name,
        "visible": list(raw.pattern.visible),
        "hidden": list(raw.pattern.hidden),
        "boundary": [
            {"variable": item.variable, "value": item.value, "display_label": item.display_label}
            for item in raw.boundary
        ],
        "reconstructed_mapping": [list(item) for item in certificate.reconstructed_mapping],
        "realizing_mappings": [[list(item) for item in mapping] for mapping in certificate.realizing_mappings],
        "evidence": [
            [label, [[source, value] for source, value in entries]]
            for label, entries in certificate.evidence
        ],
    }


def term_from_json(payload: Mapping[str, Any]) -> Term:
    """Parse one fixture term back into the tuple encoding of the kernel."""

    tag = payload["tag"]
    if tag == "atom":
        return ("atom", payload["name"])
    if tag == "var":
        return ("var", payload["name"])
    if tag == "app":
        return (payload["symbol"],) + tuple(term_from_json(arg) for arg in payload["args"])
    raise ValueError(f"unknown fixture term tag {tag!r}")


def monoid_certificate_from_json(payload: Mapping[str, Any]) -> MonoidNormalizationCertificate:
    """Rebuild a monoid certificate from fixture JSON without replaying it.

    The caller decides whether to replay.  This function performs a pure
    structural parse so the shipped fixture file can be validated by the same
    independent checker that validates freshly generated certificates.
    """

    if payload.get("kind") != "monoid_normalization":
        raise ValueError("fixture entry is not a monoid_normalization certificate")
    source = term_from_json(payload["source"])
    steps = tuple(
        RewriteStep(
            source=term_from_json(step["source"]),
            position=tuple(step["position"]),
            rule_name=step["rule"],
            target=term_from_json(step["target"]),
        )
        for step in payload["trace"]
    )
    return MonoidNormalizationCertificate(
        source=source,
        trace=RewriteTrace(source, steps),
        word=tuple(term_from_json(item) for item in payload["word"]),
        normal_form=term_from_json(payload["normal_form"]),
        interpretation_pairs=tuple(tuple(pair) for pair in payload["interpretation_pairs"]),
    )


def replay_fixture_bundle(path: str | Path) -> Mapping[str, int]:
    """Independently replay every monoid certificate in a shipped fixture file.

    Pointed-reconstruction entries serialize only mappings and evidence, not
    the finite model, so they cannot be replayed from JSON alone; their count
    is reported for structural checks by the caller.
    """

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema") != "metasketch_finite_core_fixture_v1":
        raise ValueError("unknown fixture schema")
    replayed = 0
    for entry in payload["monoid"]:
        monoid_certificate_from_json(entry).require_valid()
        replayed += 1
    return {
        "monoid_replayed": replayed,
        "pointed_entries": len(payload["pointed_reconstruction"]),
    }


def write_fixture_bundle(
    path: str | Path,
    *,
    monoid_certificates: Sequence[MonoidNormalizationCertificate],
    pointed_certificates: Sequence[PointedReconstructionCertificate],
) -> Path:
    """Write deterministic fixtures with no Python-object serialization."""

    destination = Path(path)
    payload = {
        "schema": "metasketch_finite_core_fixture_v1",
        "monoid": [monoid_certificate_to_json(item) for item in monoid_certificates],
        "pointed_reconstruction": [pointed_certificate_to_json(item) for item in pointed_certificates],
    }
    destination.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
    return destination


__all__ = [
    "term_to_json",
    "term_from_json",
    "monoid_certificate_to_json",
    "monoid_certificate_from_json",
    "pointed_certificate_to_json",
    "replay_fixture_bundle",
    "write_fixture_bundle",
]
