"""Supported public API for validated Metasketch construction.

Use this module for code that wants the kernel's checking guarantees.  The raw
AST dataclasses are intentionally not re-exported here.  Experimental users may
import :mod:`metasketch0.unsafe_ast`, but proof checking, rendering, quotation,
and theorem-facing routines should receive checked objects or revalidate raw
objects at their boundary.
"""

from __future__ import annotations

from .checked import (
    CheckedContext,
    CheckedDiagram,
    CheckedModel,
    CheckedPredicate,
    CheckedTerm,
    CheckedTile,
    PublicConstructionError,
    checked_context,
    checked_diagram,
    checked_model,
    checked_predicate,
    checked_term,
    checked_tile,
    model_from_parts,
)
from .raw_certificates import (
    BoundaryAssignmentProof,
    RawReconstruction,
    checked_raw_certificate,
)
from .certified_core import (
    CertificateValidationError,
    FiniteMonoidCorpusAudit,
    MonoidNormalizationCertificate,
    PointedReconstructionCertificate,
    audit_finite_monoid_corpus,
    certify_monoid_normalization,
    certify_pointed_reconstruction,
)


from .reflection import (
    SafeReflectionInterface,
    safe_quote_interface,
    safe_check_interface,
    safe_eval_interface,
    safe_satisfaction_interface,
    safe_lower_truth_interface,
    safe_same_level_partial_truth_interface,
    safe_same_level_incomplete_truth_interface,
)

__all__ = [
    "PublicConstructionError",
    "CheckedContext",
    "CheckedDiagram",
    "CheckedModel",
    "CheckedPredicate",
    "CheckedTerm",
    "CheckedTile",
    "checked_context",
    "checked_diagram",
    "checked_model",
    "checked_predicate",
    "checked_term",
    "checked_tile",
    "model_from_parts",
    "BoundaryAssignmentProof",
    "RawReconstruction",
    "checked_raw_certificate",
    "CertificateValidationError",
    "MonoidNormalizationCertificate",
    "PointedReconstructionCertificate",
    "FiniteMonoidCorpusAudit",
    "certify_monoid_normalization",
    "certify_pointed_reconstruction",
    "audit_finite_monoid_corpus",
    "SafeReflectionInterface",
    "safe_quote_interface",
    "safe_check_interface",
    "safe_eval_interface",
    "safe_satisfaction_interface",
    "safe_lower_truth_interface",
    "safe_same_level_partial_truth_interface",
    "safe_same_level_incomplete_truth_interface",
]
