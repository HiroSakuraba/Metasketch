"""
Metasketch-0 syntax and static-validation layer.

The kernel uses a small regular-logic fragment:

  - typed sorts and variables;
  - first-order terms over a declared signature;
  - contexts with unique variable names;
  - structural diagrams as target-indexed term substitutions; and
  - predicates built from truth, equality, relation atoms, conjunction, and
    existential quantification.

Two design choices matter for correctness.

1. Generic syntax constructors remain lightweight so examples can be written
   compactly. The explicit validate_* functions provide the static checker for a
   declared signature and context.
2. Predicate substitution is capture-avoiding. When an existential binder would
   capture a free variable in a replacement term, the binder is alpha-renamed.

This is still a finite first-order prototype, not a full dependent type system.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Sorts, variables, and signatures
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Sort:
    name: str

    def __repr__(self) -> str:
        return self.name


@dataclass(frozen=True)
class Var:
    """A named, sorted first-order variable.

    Contexts require distinct names. Bound variables are alpha-renamed during
    substitution when necessary, so name-based environments remain hygienic in
    this finite prototype.
    """

    name: str
    sort: Sort

    def __repr__(self) -> str:
        return f"{self.name}:{self.sort.name}"


@dataclass(frozen=True)
class Signature:
    sorts: Tuple[Sort, ...]
    # operation name -> (input sorts, output sort)
    ops: Tuple[Tuple[str, Tuple[Sort, ...], Sort], ...]
    # relation name -> argument sorts
    rels: Tuple[Tuple[str, Tuple[Sort, ...]], ...]

    def __post_init__(self):
        if len({s.name for s in self.sorts}) != len(self.sorts):
            raise ValueError("signature has duplicate sort names")
        if len({name for name, _, _ in self.ops}) != len(self.ops):
            raise ValueError("signature has duplicate operation names")
        if len({name for name, _ in self.rels}) != len(self.rels):
            raise ValueError("signature has duplicate relation names")

    def op_sig(self, name: str) -> Tuple[Tuple[Sort, ...], Sort]:
        for n, ins, out in self.ops:
            if n == name:
                return ins, out
        raise KeyError(f"unknown operation {name}")

    def rel_sig(self, name: str) -> Tuple[Sort, ...]:
        for n, args in self.rels:
            if n == name:
                return args
        raise KeyError(f"unknown relation {name}")


# ---------------------------------------------------------------------------
# Terms and capture-avoiding substitution
# ---------------------------------------------------------------------------

class Term:
    """Base class for terms. Terms are VarTerm or OpTerm."""


@dataclass(frozen=True)
class VarTerm(Term):
    var: Var

    def __repr__(self) -> str:
        return self.var.name


@dataclass(frozen=True)
class OpTerm(Term):
    op: str
    args: Tuple[Term, ...]

    def __repr__(self) -> str:
        return f"{self.op}({', '.join(map(repr, self.args))})"


def v(var: Var) -> VarTerm:
    return VarTerm(var)


def op(name: str, *args: Term) -> OpTerm:
    return OpTerm(name, tuple(args))


def free_var_names_term(t: Term) -> Set[str]:
    if isinstance(t, VarTerm):
        return {t.var.name}
    if isinstance(t, OpTerm):
        out: Set[str] = set()
        for arg in t.args:
            out |= free_var_names_term(arg)
        return out
    raise TypeError(f"not a term: {t!r}")


def subst_term(t: Term, mapping: Mapping[str, Term]) -> Term:
    """Simultaneous substitution of free variable names in a term."""
    if isinstance(t, VarTerm):
        return mapping.get(t.var.name, t)
    if isinstance(t, OpTerm):
        return OpTerm(t.op, tuple(subst_term(a, mapping) for a in t.args))
    raise TypeError(f"not a term: {t!r}")


def _rename_term_var(t: Term, old: Var, new: Var) -> Term:
    if isinstance(t, VarTerm):
        return VarTerm(new) if t.var == old else t
    if isinstance(t, OpTerm):
        return OpTerm(t.op, tuple(_rename_term_var(a, old, new) for a in t.args))
    raise TypeError(f"not a term: {t!r}")


def _fresh_var_like(var: Var, forbidden_names: Iterable[str]) -> Var:
    forbidden = set(forbidden_names)
    stem = var.name
    i = 0
    candidate = f"{stem}__{i}"
    while candidate in forbidden:
        i += 1
        candidate = f"{stem}__{i}"
    return Var(candidate, var.sort)


# ---------------------------------------------------------------------------
# Contexts and structural diagrams
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Context:
    vars: Tuple[Var, ...]

    def __post_init__(self):
        names = [x.name for x in self.vars]
        if len(set(names)) != len(names):
            raise ValueError("context variables must have distinct names")

    def names(self) -> Tuple[str, ...]:
        return tuple(x.name for x in self.vars)

    def by_name(self) -> Dict[str, Var]:
        return {x.name: x for x in self.vars}

    def __repr__(self) -> str:
        return "(" + ", ".join(map(repr, self.vars)) + ")"


@dataclass(frozen=True)
class Diagram:
    """A structural diagram d : source -> target as a target-indexed substitution."""

    source: Context
    target: Context
    mapping: Tuple[Tuple[str, Term], ...]

    def __post_init__(self):
        names = [n for n, _ in self.mapping]
        if len(set(names)) != len(names):
            raise ValueError("diagram mapping has duplicate target variables")
        if set(names) != set(self.target.names()):
            raise ValueError(
                "diagram mapping must assign exactly the target-context variables"
            )

    def as_dict(self) -> Dict[str, Term]:
        return {n: t for n, t in self.mapping}

    def __repr__(self) -> str:
        body = ", ".join(f"{n} := {t!r}" for n, t in self.mapping)
        return f"[{body}] : {self.source} -> {self.target}"


def compose_diagrams(e: Diagram, d: Diagram) -> Diagram:
    """Compose e after d by capture-free term substitution."""
    if e.source != d.target:
        raise ValueError("compose_diagrams: e.source must equal d.target")
    dmap = d.as_dict()
    new_mapping = tuple(
        (theta_name, subst_term(term, dmap)) for theta_name, term in e.mapping
    )
    return Diagram(source=d.source, target=e.target, mapping=new_mapping)


# ---------------------------------------------------------------------------
# Regular-logic predicates and hygienic substitution
# ---------------------------------------------------------------------------

class Pred:
    """Base class for predicates in a declared context."""


@dataclass(frozen=True)
class Top(Pred):
    def __repr__(self) -> str:
        return "T"


@dataclass(frozen=True)
class Eq(Pred):
    left: Term
    right: Term

    def __repr__(self) -> str:
        return f"({self.left!r} = {self.right!r})"


@dataclass(frozen=True)
class Rel(Pred):
    name: str
    args: Tuple[Term, ...]

    def __repr__(self) -> str:
        return f"{self.name}({', '.join(map(repr, self.args))})"


@dataclass(frozen=True)
class And(Pred):
    left: Pred
    right: Pred

    def __repr__(self) -> str:
        return f"({self.left!r} & {self.right!r})"


@dataclass(frozen=True)
class Exists(Pred):
    var: Var
    body: Pred

    def __repr__(self) -> str:
        return f"(exists {self.var!r}. {self.body!r})"


def free_var_names_pred(p: Pred) -> Set[str]:
    if isinstance(p, Top):
        return set()
    if isinstance(p, Eq):
        return free_var_names_term(p.left) | free_var_names_term(p.right)
    if isinstance(p, Rel):
        out: Set[str] = set()
        for arg in p.args:
            out |= free_var_names_term(arg)
        return out
    if isinstance(p, And):
        return free_var_names_pred(p.left) | free_var_names_pred(p.right)
    if isinstance(p, Exists):
        return free_var_names_pred(p.body) - {p.var.name}
    raise TypeError(f"not a predicate: {p!r}")


def _rename_free_pred_var(p: Pred, old: Var, new: Var) -> Pred:
    """Rename free occurrences of old, stopping beneath a shadowing binder."""
    if isinstance(p, Top):
        return p
    if isinstance(p, Eq):
        return Eq(_rename_term_var(p.left, old, new), _rename_term_var(p.right, old, new))
    if isinstance(p, Rel):
        return Rel(p.name, tuple(_rename_term_var(a, old, new) for a in p.args))
    if isinstance(p, And):
        return And(_rename_free_pred_var(p.left, old, new),
                   _rename_free_pred_var(p.right, old, new))
    if isinstance(p, Exists):
        if p.var == old:
            return p
        return Exists(p.var, _rename_free_pred_var(p.body, old, new))
    raise TypeError(f"not a predicate: {p!r}")


def subst_pred(p: Pred, mapping: Mapping[str, Term]) -> Pred:
    """Capture-avoiding simultaneous substitution of free variables in a predicate."""
    if isinstance(p, Top):
        return p
    if isinstance(p, Eq):
        return Eq(subst_term(p.left, mapping), subst_term(p.right, mapping))
    if isinstance(p, Rel):
        return Rel(p.name, tuple(subst_term(a, mapping) for a in p.args))
    if isinstance(p, And):
        return And(subst_pred(p.left, mapping), subst_pred(p.right, mapping))
    if isinstance(p, Exists):
        original = p.var
        body = p.body
        inner = {k: t for k, t in mapping.items() if k != original.name}
        replacement_names = set().union(
            *(free_var_names_term(t) for t in inner.values())
        ) if inner else set()
        if original.name in replacement_names:
            forbidden = (
                free_var_names_pred(body)
                | replacement_names
                | set(inner.keys())
                | {original.name}
            )
            fresh = _fresh_var_like(original, forbidden)
            body = _rename_free_pred_var(body, original, fresh)
            return Exists(fresh, subst_pred(body, inner))
        return Exists(original, subst_pred(body, inner))
    raise TypeError(f"not a predicate: {p!r}")


def reindex(d: Diagram, q: Pred) -> Pred:
    """Pull a target predicate back along d using capture-avoiding substitution."""
    return subst_pred(q, d.as_dict())


# ---------------------------------------------------------------------------
# Static validation for a declared signature
# ---------------------------------------------------------------------------

class StaticCheckError(ValueError):
    """Raised when a typed syntax object is ill-formed for its declaration."""


def _context_env(ctx: Context, extra: Optional[Mapping[str, Var]] = None) -> Dict[str, Var]:
    env = ctx.by_name()
    if extra:
        for name, var in extra.items():
            if name in env and env[name] != var:
                raise StaticCheckError(f"variable name {name!r} has conflicting sorts")
            env[name] = var
    return env


def infer_term_sort(t: Term, signature: Signature, ctx: Context,
                    bound: Optional[Mapping[str, Var]] = None) -> Sort:
    env = _context_env(ctx, bound)
    if isinstance(t, VarTerm):
        declared = env.get(t.var.name)
        if declared is None:
            raise StaticCheckError(f"free variable {t.var!r} is not declared in context")
        if declared.sort != t.var.sort:
            raise StaticCheckError(
                f"variable {t.var.name!r} has sort {t.var.sort}, expected {declared.sort}"
            )
        return declared.sort
    if isinstance(t, OpTerm):
        try:
            inputs, output = signature.op_sig(t.op)
        except KeyError as exc:
            raise StaticCheckError(str(exc)) from exc
        if len(inputs) != len(t.args):
            raise StaticCheckError(
                f"operation {t.op!r} expects {len(inputs)} arguments, got {len(t.args)}"
            )
        for i, (arg, expected) in enumerate(zip(t.args, inputs)):
            got = infer_term_sort(arg, signature, ctx, bound)
            if got != expected:
                raise StaticCheckError(
                    f"argument {i} of {t.op!r} has sort {got}, expected {expected}"
                )
        return output
    raise StaticCheckError(f"not a term: {t!r}")


def validate_pred(p: Pred, signature: Signature, ctx: Context,
                  bound: Optional[Mapping[str, Var]] = None) -> None:
    if isinstance(p, Top):
        return
    if isinstance(p, Eq):
        left = infer_term_sort(p.left, signature, ctx, bound)
        right = infer_term_sort(p.right, signature, ctx, bound)
        if left != right:
            raise StaticCheckError(f"equality compares mismatched sorts {left} and {right}")
        return
    if isinstance(p, Rel):
        try:
            expected = signature.rel_sig(p.name)
        except KeyError as exc:
            raise StaticCheckError(str(exc)) from exc
        if len(expected) != len(p.args):
            raise StaticCheckError(
                f"relation {p.name!r} expects {len(expected)} arguments, got {len(p.args)}"
            )
        for i, (arg, sort) in enumerate(zip(p.args, expected)):
            got = infer_term_sort(arg, signature, ctx, bound)
            if got != sort:
                raise StaticCheckError(
                    f"argument {i} of relation {p.name!r} has sort {got}, expected {sort}"
                )
        return
    if isinstance(p, And):
        validate_pred(p.left, signature, ctx, bound)
        validate_pred(p.right, signature, ctx, bound)
        return
    if isinstance(p, Exists):
        merged = _context_env(ctx, bound)
        if p.var.name in merged:
            raise StaticCheckError(
                f"existential binder {p.var.name!r} shadows an active variable; alpha-rename first"
            )
        merged[p.var.name] = p.var
        validate_pred(p.body, signature, ctx, merged)
        return
    raise StaticCheckError(f"not a predicate: {p!r}")


def validate_diagram(d: Diagram, signature: Signature) -> None:
    target_vars = d.target.by_name()
    for name, term in d.mapping:
        expected = target_vars[name].sort
        got = infer_term_sort(term, signature, d.source)
        if got != expected:
            raise StaticCheckError(
                f"diagram component {name!r} has sort {got}, expected {expected}"
            )


def validate_tile_syntax(p: Pred, d: Diagram, q: Pred, signature: Signature) -> None:
    validate_diagram(d, signature)
    validate_pred(p, signature, d.source)
    validate_pred(q, signature, d.target)
