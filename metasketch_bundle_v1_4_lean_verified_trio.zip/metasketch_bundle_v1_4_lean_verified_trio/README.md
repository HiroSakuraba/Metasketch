# Metasketch-0 v1.4

Metasketch is a finite prototype for a stratified diagrammatic calculus in which
structural diagrams, existential-conjunctive predicates, proof certificates, and
selected coherence cells are checked together.

## Current scope

The current fragment supports:

- checked public construction of typed finite syntax and models;
- directed monoid rewriting with confluence fillers;
- finite relational patterns and existential-conjunctive queries;
- witness certificates, normalization, and transport coherence;
- raw certificate reconstruction with no stored semantic match;
- pointed boundary assignments for visible variables absent from any relation
  atom;
- level-raising quotation and higher-level syntactic checking;
- audited one-way SVG rendering of checked proof objects;
- independently replayable **finite instance certificates** for monoid
  normalization and pointed raw-certificate reconstruction; and
- **machine-checked Lean 4 proofs** of all three declared finite-core targets
  (`formal/lean/`): F1 monoid normalization (strict descent, right-comb normal
  forms, soundness, uniqueness, confluence), F2 evidence reconstruction
  (unique realization and erasure round trip), and F3 reflection-interface
  safety (safe grammar, same-level Boolean diagonal, typed cross-level
  predicate codes).

The regression suite contains **150 checks**. Run it with:

```bash
python run_all_tests.py
```

## Trusted public surface

Use `metasketch0.api` for supported construction:

```text
checked_context, checked_term, checked_predicate
checked_diagram, checked_tile, checked_model
model_from_parts
BoundaryAssignmentProof
checked_raw_certificate
certify_monoid_normalization
certify_pointed_reconstruction
audit_finite_monoid_corpus
```

Raw abstract syntax remains explicitly experimental under `metasketch0.unsafe_ast`.
Proof checking, rendering, quotation, and theorem-facing routines validate at
their own boundary.

## Proof-carrying finite core

`metasketch0.certified_core` provides two replayable instance-level checks:

```text
MonoidNormalizationCertificate
  validates a concrete rewrite trace, polynomial descent,
  and the right-comb normal form.

PointedReconstructionCertificate
  recomputes the unique finite match forced by a raw certificate's
  fact leaves, outer hidden binders, and visible-boundary evidence.
```

The certificates are executable finite validation. As of v1.4, all three
finite-core formalization targets are machine-checked in Lean 4 (v4.31.0,
core only, no dependencies, no `sorry`): F1 in
`formal/lean/MonoidNormalization.lean`, the F2 evidence core in
`formal/lean/PointedRawReconstruction.lean`, and F3 in
`formal/lean/ReflectionSafety.lean`. Theorem lists and axiom footprints are in
`formal/lean/VERIFICATION.txt`; `formal/lean/verify.sh` reproduces the check.
Deterministic translation fixtures are in
`formal/fixtures/finite_core_v1.json` and are re-parsed and replayed by the
regression suite on every run.

## Pointed raw certificates

A raw certificate contains no stored `RelationalMatch`. It reconstructs a unique
finite match from relation-fact leaves, hidden existential binders, and, when
needed, boundary assignments for visible variables absent from the matrix.

```text
RawPatternCertificate(
  pattern,
  model,
  root,
  boundary=(BoundaryAssignmentProof("p", "u"),),
)
```

Boundary assignments are input-context evidence. They are not relation-fact
leaves and do not create a semantic truth predicate.

## Important limits

- The relational proof layer is finite, equality-free, and relation-only.
- Certificate replay is not a proof-assistant theorem. The Lean verifications
  have declared scopes: F2 is verified at the evidence-reconstruction layer
  only, with the relation/model front end remaining a Python premise, and F3
  is a grammar/typing theorem, not Tarski's or Lawvere's theorem.
- Raw reconstruction is not recovery from arbitrary unannotated proofs.
- `resource_exhausted` is not semantic divergence.
- The Program E audit is not Tarski's theorem or Lawvere's theorem.
- The renderer projects checked proof objects to SVG. It is not a general visual
  proof editor or a parser for arbitrary SVG.

## File map

```text
metasketch0/
  api.py                   supported checked public API
  certified_core.py        independent finite certificate checkers
  formal_fixtures.py       deterministic JSON fixture writer
  raw_certificates.py      raw proofs and pointed-boundary reconstruction
  proofs.py                witness proof syntax, normal forms, transport cells
  adequacy.py              Phase 5 certificate/match correspondence
  coherence_lift.py        generic finite coherence-lifting schema
  reflection_audit.py      Program E interface audit
  render.py                semantic scene graph and SVG serializer
  tests_phase10.py         v1.1 finite-core, fixture-replay, and boundary-renderer tests
  tests_phase11.py         F2 evidence-core finite audit and handoff integrity tests
  tests_phase12.py         F3 reflection-interface safety tests

formal/
  README.md                formalization theorem signatures and scope
  lean/MonoidNormalization.lean         machine-checked F1 proof (Lean 4)
  lean/PointedRawReconstruction.lean    machine-checked F2 evidence core (Lean 4)
  lean/ReflectionSafety.lean            machine-checked F3 proof (Lean 4)
  lean/VERIFICATION.txt                  three-file verification record
  lean/F2_STATUS.txt                     exact F2 claim, repairs, and status
  lean/F3_STATUS.txt                     exact F3 claim and status
  lean/verify.sh                         one-command F1+F2+F3 recheck
  fixtures/finite_core_v1.json

tools/
  generate_v1_artifacts.py

rendered_examples/
  directed_pentagon.svg
  relational_witness.svg
  transport_coherence.svg
  quoted_proof_membrane.svg
  pointed_boundary.svg

design/
  metasketch_reflective_diagrammatic_calculus_design_v1_4.md
  metasketch_reflective_diagrammatic_calculus_design_v1_3.md
  earlier design lineage
```


## F3 reflection-interface safety

The checked public API exports safe level-indexed reflection-interface
constructors.  The accompanying machine-checked Lean proof shows the safe
grammar excludes same-level total representation-complete truth, proves the
Boolean diagonal obstruction for an arbitrary same-level evaluator, and proves
predicate-code completeness across one level gap.  See
`design/metasketch_f3_reflection_interface_formalization_note_v0_1.md`.
