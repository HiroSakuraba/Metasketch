"""Generate deterministic v1.0 fixtures and the semantic-renderer gallery."""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from metasketch0.certified_core import certify_monoid_normalization, certify_pointed_reconstruction
from metasketch0.coherence import E, a, b, m, pentagon_source_term
from metasketch0.formal_fixtures import write_fixture_bundle
from metasketch0.proofs import TruthProof
from metasketch0.raw_certificates import BoundaryAssignmentProof, RawPatternCertificate
from metasketch0.showcases import write_showcase_gallery
from metasketch0.tests_phase4 import source_model
from metasketch0.tests_phase7 import pointed_truth_pattern


def main() -> int:
    root = ROOT
    pointed = RawPatternCertificate(
        pointed_truth_pattern(),
        source_model(),
        TruthProof(),
        (BoundaryAssignmentProof("p", "u", "selected_person"),),
    )
    monoid = (
        certify_monoid_normalization(pentagon_source_term()),
        certify_monoid_normalization(m(m(a, b), E)),
    )
    raw = (certify_pointed_reconstruction(pointed),)
    fixture_path = write_fixture_bundle(
        root / "formal" / "fixtures" / "finite_core_v1.json",
        monoid_certificates=monoid,
        pointed_certificates=raw,
    )
    outputs = write_showcase_gallery(root / "rendered_examples")
    print(f"fixtures: {fixture_path}")
    for name, path in outputs.items():
        print(f"{name}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
