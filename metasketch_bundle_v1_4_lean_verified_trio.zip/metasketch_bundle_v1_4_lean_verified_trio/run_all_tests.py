"""Run every Metasketch-0 regression phase, through the v1.3 F3 reflection-interface handoff."""

from __future__ import annotations

from metasketch0 import (
    tests,
    tests_phase_api,
    tests_phase2,
    tests_phase25,
    tests_phase3,
    tests_phase4,
    tests_phase5,
    tests_phase6,
    tests_phase7,
    tests_phase10,
    tests_phase11,
    tests_phase12,
    tests_phase_lift,
    tests_phase_reflection_audit,
    tests_phase_renderer,
)


def main() -> int:
    codes = [
        tests_phase_api.run(),
        tests.run(),
        tests_phase2.run(),
        tests_phase25.run(),
        tests_phase3.run(),
        tests_phase4.run(),
        tests_phase5.run(),
        tests_phase6.run(),
        tests_phase7.run(),
        tests_phase10.run(),
        tests_phase11.run(),
        tests_phase12.run(),
        tests_phase_lift.run(),
        tests_phase_reflection_audit.run(),
        tests_phase_renderer.run(),
    ]
    if any(codes):
        print("=" * 72)
        print("OVERALL: FAILURE")
        print("=" * 72)
        return 1
    print("=" * 72)
    print("OVERALL: ALL PASS")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
